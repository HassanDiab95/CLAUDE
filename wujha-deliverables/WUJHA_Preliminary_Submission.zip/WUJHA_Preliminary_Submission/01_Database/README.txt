WUJHA - Database (Cloud Firestore)
قاعدة بيانات مشروع وِجهة

The project uses Google Cloud Firestore (a NoSQL document database), so there are
no SQL tables. Collections are created on first write; access is controlled by
the security rules in firestore.rules.

Files:
  firestore.rules             Security rules (who may read / write each collection)
  storage.rules               Rules for Cloud Storage (not used: images are stored inside documents)
  wujha_database_export.json  Export of the demo library: 153 documents in 10 collections
                              (image fields are omitted to keep the file small)
  Database_Structure.png      Logical structure of the collections and their relations
  Loan_Lifecycle.png          Loan states and transitions
  Class_Diagram.png           Main classes of the system

Collections:
  books       books, shelf code, copies, copies on loan
  shelves     bookcases: floor, block, aisle, position, side, capacity
  floors      floors with their grid of blocks and aisles
  categories  book categories
  loans       loans: status, dates, member details, ID photo
  members     library members registered at the desk
  users       visitor accounts and their favourites
  admins      admin rights (owner / admin)
  activity    activity log (append only)
  meta        loan policy and the one-time setup lock

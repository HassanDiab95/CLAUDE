package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.auth.AuthProviderHolder
import com.wujha.admin.data.auth.AuthResult
import com.wujha.admin.data.auth.AuthValidator
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.AuthScreenColumn
import com.wujha.admin.ui.components.FormErrorBanner
import com.wujha.admin.ui.components.WujhaLockup
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.AccentGold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenWash
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextOnBackdrop
import com.wujha.admin.ui.theme.TextOnBackdropMuted
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * The way in.
 *
 * Laid out as the brand sheet shows it: the lockup on cream, a short
 * tagline, then one white card holding the whole form. Everything the person
 * has to touch is inside that card, so the eye never has to hunt across the
 * page for the next step.
 */
@Composable
fun LoginScreen(
    onSignedIn: () -> Unit,
    onNavigateToSignUp: () -> Unit
) {
    val repository = AuthProviderHolder.repository
    val scope = rememberCoroutineScope()

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    /** Runs an auth call, showing the spinner and surfacing any failure. */
    fun attempt(block: suspend () -> AuthResult) {
        if (loading) return
        formError = null
        notice = null
        loading = true
        scope.launch {
            when (val result = block()) {
                is AuthResult.Success -> {
                    loading = false
                    onSignedIn()
                }
                is AuthResult.Failure -> {
                    loading = false
                    formError = result.message
                }
            }
        }
    }

    fun submit() {
        emailError = AuthValidator.emailError(email)
        passwordError = AuthValidator.passwordError(password)
        if (emailError != null || passwordError != null) return
        attempt { repository.signInWithEmail(email, password) }
    }

    AuthScreenColumn {
        Spacer(Modifier.height(36.dp))
        WujhaLockup(
            tagline = t("لوحة تحكم المكتبة"),
            taglineColor = TextOnBackdrop
        )
        Spacer(Modifier.height(26.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = SurfaceWhite,
            border = BorderStroke(1.dp, BorderLight)
        ) {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) {
                Text(
                    text = t("تسجيل دخول المشرف"),
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(16.dp))

                WujhaTextField(
                    value = email,
                    onValueChange = { email = it; emailError = null; formError = null },
                    placeholder = t("البريد الإلكتروني"),
                    leadingIcon = Icons.Outlined.Email,
                    keyboardType = KeyboardType.Email,
                    enabled = !loading,
                    errorText = emailError
                )
                Spacer(Modifier.height(12.dp))
                WujhaTextField(
                    value = password,
                    onValueChange = { password = it; passwordError = null; formError = null },
                    placeholder = t("كلمة المرور"),
                    leadingIcon = Icons.Outlined.Lock,
                    isPassword = true,
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done,
                    enabled = !loading,
                    errorText = passwordError
                )

                if (formError != null) {
                    Spacer(Modifier.height(12.dp))
                    FormErrorBanner(message = formError.orEmpty())
                }
                val currentNotice = notice
                if (currentNotice != null) {
                    Spacer(Modifier.height(12.dp))
                    Surface(shape = RoundedCornerShape(12.dp), color = ForestGreenWash) {
                        Text(
                            text = currentNotice,
                            color = ForestGreen,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))
                SignInButton(loading = loading, onClick = { submit() })

                Spacer(Modifier.height(6.dp))
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    TextButton(
                        onClick = {
                            val error = AuthValidator.emailError(email)
                            if (error != null) {
                                emailError = error
                            } else {
                                loading = true
                                scope.launch {
                                    val result = repository.sendPasswordReset(email)
                                    loading = false
                                    notice = (result as? AuthResult.Failure)?.message
                                }
                            }
                        },
                        enabled = !loading
                    ) {
                        Text(t("نسيت كلمة المرور؟"), color = AccentGold, fontSize = 12.sp)
                    }
                }

            }
        }

        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("ليس لديك حساب؟"), color = TextOnBackdropMuted, fontSize = 13.sp)
            TextButton(onClick = onNavigateToSignUp, enabled = !loading) {
                Text(
                    text = t("إنشاء حساب جديد"),
                    color = ForestGreen,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            text = t("الدخول هنا بالبريد الإلكتروني فقط. أول حساب يسجّل الدخول إلى قاعدة بيانات فارغة يصبح مالك المكتبة تلقائياً، ويمنح بقية المشرفين صلاحياتهم من داخل التطبيق."),
            color = TextSecondary,
            fontSize = 11.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = 10.dp)
        )

        Spacer(Modifier.height(32.dp))
    }
}

/**
 * The primary action, drawn as the brand sheet shows it: a full-width dark
 * green pill with a chevron pointing the way forward.
 */
@Composable
private fun SignInButton(loading: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        enabled = !loading,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = ForestGreen
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = SurfaceWhite,
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = Icons.Outlined.ChevronLeft,
                    contentDescription = null,
                    tint = SurfaceWhite,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = t("تسجيل الدخول"),
                    color = SurfaceWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 6.dp)
                )
            }
        }
    }
}

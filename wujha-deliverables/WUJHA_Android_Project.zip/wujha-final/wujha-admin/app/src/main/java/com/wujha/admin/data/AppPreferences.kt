package com.wujha.admin.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** A single on/off app setting. */
data class ToggleSetting(val key: String, val label: String, val detail: String, val enabled: Boolean)

/**
 * Device-local app settings — the notification switches and similar.
 *
 * These are per-device preferences rather than library data, so they live in
 * SharedPreferences rather than Firestore.
 */
class AppPreferences(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("wujha_admin_prefs", Context.MODE_PRIVATE)

    private val state = MutableStateFlow(load())
    val settings: StateFlow<List<ToggleSetting>> = state.asStateFlow()

    private fun load(): List<ToggleSetting> = DEFAULTS.map { d ->
        d.copy(enabled = prefs.getBoolean(d.key, d.enabled))
    }

    fun toggle(key: String) {
        val updated = state.value.map { s ->
            if (s.key == key) s.copy(enabled = !s.enabled) else s
        }
        state.value = updated
        updated.firstOrNull { it.key == key }?.let {
            prefs.edit().putBoolean(it.key, it.enabled).apply()
        }
    }

    private companion object {
        val DEFAULTS = listOf(
            ToggleSetting("notify_loan_requests", "طلبات الإعارة الواردة",
                "تنبيه عند وصول طلب إعارة جديد أو طلب تجديد من تطبيق الزائر", true),
            ToggleSetting("notify_low_stock", "تنبيه نفاد النسخ",
                "إشعار عندما يصل عدد نسخ كتاب إلى صفر", true),
            ToggleSetting("notify_lost", "تنبيه الكتب المفقودة",
                "إشعار عند تغيير حالة كتاب إلى مفقود", true),
            ToggleSetting("notify_new_member", "تنبيه عضوية جديدة",
                "إشعار عند إضافة مستخدم جديد للمكتبة", false),
            ToggleSetting("notify_overdue", "تنبيه التأخير",
                "إشعار عند تجاوز موعد إرجاع كتاب", true)
        )
    }
}

object PreferencesProvider {

    @Volatile
    private var instance: AppPreferences? = null

    fun init(context: Context) {
        if (instance == null) instance = AppPreferences(context)
    }

    val preferences: AppPreferences
        get() = instance ?: error("PreferencesProvider.init(context) must be called first")
}

package com.wujha.admin.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.LibraryPlan
import com.wujha.admin.data.Localization
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.BookCover
import com.wujha.admin.ui.components.BookStatusBadge
import com.wujha.admin.ui.components.LoadingView
import com.wujha.admin.ui.components.LoanRow
import com.wujha.admin.ui.components.SectionHeader
import com.wujha.admin.ui.theme.AccentGold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackground
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenMid
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.StatusLostText
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun BookDetailScreen(
    bookId: String,
    repository: LibraryRepository,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    onDeleted: () -> Unit,
    onLendBook: (String) -> Unit,
    onOpenLoan: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val allBooks by repository.books.collectAsState()
    val categories by repository.categories.collectAsState()
    val shelves by repository.shelves.collectAsState()
    val floors by repository.floors.collectAsState()
    // Collected so the availability line and the loan list below follow the
    // borrowing cycle without a refresh.
    val loans by repository.loans.collectAsState()
    val policy by repository.loanPolicy.collectAsState()
    val english = Localization.isEnglish
    val book = allBooks.find { it.id == bookId }

    var showDeleteDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    if (book == null) {
        LoadingView(message = t("جارٍ تحميل الكتاب..."), modifier = Modifier.background(CreamBackground))
        return
    }

    val categoryName = categories.firstOrNull { it.id == book.category }?.name ?: book.category

    // The bookcase is the source of truth for where a book is, so the address
    // below is resolved from it rather than read off the book's own copy.
    val location = remember(book, shelves, floors) {
        LibraryPlan.locate(
            shelfCode = book.shelf,
            level = book.section,
            floors = floors,
            shelves = shelves,
            floorFallback = book.floor
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Outlined.ArrowForward, contentDescription = t("رجوع"), tint = TextPrimary)
                }
                Text(t("تفاصيل الكتاب"), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextPrimary)
                IconButton(onClick = {
                    val summary = t("%s — %s\nالرف %s • %s\nالحالة: %s").format(book.title, book.author, book.shelf, book.floor, t(book.status.labelAr))
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, summary)
                    }
                    context.startActivity(Intent.createChooser(sendIntent, t("مشاركة بيانات الكتاب")))
                }) {
                    Icon(Icons.Outlined.Share, contentDescription = t("مشاركة"), tint = TextPrimary)
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                verticalAlignment = Alignment.Top
            ) {
                BookCover(
                    title = book.title,
                    colorHex = book.coverColor,
                    coverBase64 = book.coverBase64,
                    modifier = Modifier.width(90.dp).aspectRatio(0.72f)
                )
                Column(modifier = Modifier.padding(start = 14.dp).weight(1f)) {
                    Text(book.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                    Text(
                        book.author,
                        color = TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(categoryName.ifBlank { t("غير مصنّف") }, color = AccentGold, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    BookStatusBadge(status = book.status)
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ActionButton(
                    icon = Icons.Outlined.Edit,
                    label = t("تعديل"),
                    onClick = { onEdit(book.id) },
                    modifier = Modifier.weight(1f)
                )
                ActionButton(
                    icon = Icons.Outlined.Delete,
                    label = t("حذف"),
                    onClick = { showDeleteDialog = true },
                    tint = StatusLostText,
                    modifier = Modifier.weight(1f)
                )
                ActionButton(
                    icon = Icons.Outlined.SwapHoriz,
                    label = t("إعارة"),
                    onClick = { onLendBook(book.id) },
                    tint = if (book.isBorrowable) ForestGreen else TextSecondary,
                    modifier = Modifier.weight(1f)
                )
                ActionButton(
                    icon = Icons.Outlined.Add,
                    label = t("نسخة جديدة"),
                    onClick = {
                        scope.launch {
                            errorMessage = repository.updateBook(book.copy(copies = book.copies + 1))
                        }
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        if (book.description.isNotBlank()) {
            item {
                Text(
                    text = book.description,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 21.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
                Spacer(Modifier.height(12.dp))
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                shape = RoundedCornerShape(16.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    MetaRow(t("الرقم التسلسلي"), book.serial.ifBlank { "—" })
                    MetaRow(t("الدور"), location.floorName(english).ifBlank { t("غير محدد") })
                    MetaRow(t("البلوك"), location.block?.displayName(english) ?: t("غير محدد"))
                    MetaRow(t("الممر"), location.aisle?.displayName(english) ?: t("غير محدد"))
                    MetaRow(t("الرف"), location.shelfCode().ifBlank { t("غير محدد") })
                    MetaRow(t("المستوى"), location.level.ifBlank { t("غير محدد") }.let { t(it) })
                    MetaRow(t("الجهة"), location.shelf?.side?.takeIf { it.isNotBlank() }?.let { t(it) } ?: "—")
                    MetaRow(t("عدد النسخ"), book.copies.toString())
                    MetaRow(
                        t("متاحة للإعارة"),
                        t("%s من %s").format(book.availableCopies, book.copies)
                    )
                    if (book.onLoan > 0) {
                        MetaRow(t("مُعارة أو محجوزة"), book.onLoan.toString())
                    }
                    MetaRow(t("عدد الصفحات"), if (book.pageCount > 0) book.pageCount.toString() else "—")
                    MetaRow(t("اللغة"), book.language)
                    MetaRow(t("دار النشر"), book.publisher.ifBlank { "—" })
                    MetaRow(t("تاريخ الإضافة"), book.dateAdded.ifBlank { "—" })
                    if (book.notes.isNotBlank()) MetaRow(t("ملاحظات"), book.notes)
                }
            }
        }

        // ---- Who has it, and who had it --------------------------------
        val bookLoans = loans.filter { it.bookId == book.id }
        if (bookLoans.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 22.dp)) {
                    SectionHeader(
                        title = t("إعارات هذا الكتاب"),
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )
                    Spacer(Modifier.height(4.dp))
                    val out = bookLoans.count { it.holdsCopy }
                    val late = bookLoans.count { it.isOverdue }
                    Text(
                        text = buildString {
                            append(t("%s نسخة خارج الرف").format(out))
                            if (late > 0) append(" • ").append(t("%s متأخرة").format(late))
                        },
                        color = if (late > 0) SignalRed else TextSecondary,
                        fontSize = 11.5.sp,
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                }
            }
            items(bookLoans.take(6)) { loan ->
                LoanRow(loan = loan, onClick = { onOpenLoan(loan.id) })
            }
        } else {
            item {
                Text(
                    text = if (book.isBorrowable) {
                        t("لم يُعَر هذا الكتاب من قبل. مدة الإعارة الحالية %s يوماً.")
                            .format(policy.loanDays)
                    } else {
                        t("لا توجد نسخة متاحة من هذا الكتاب حالياً.")
                    },
                    color = if (book.isBorrowable) TextSecondary else ForestGreenMid,
                    fontSize = 11.5.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp)
                )
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = SurfaceWhite,
            title = { Text(t("حذف الكتاب"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Text(
                    t("سيتم حذف \"%s\" نهائياً من الفهرس. هل أنت متأكد؟").format(book.title),
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    scope.launch {
                        val error = repository.deleteBook(book.id)
                        if (error == null) onDeleted() else errorMessage = error
                    }
                }) { Text(t("حذف"), color = StatusLostText, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(t("إلغاء"), color = TextSecondary)
                }
            }
        )
    }

    val err = errorMessage
    if (err != null) {
        AlertDialog(
            onDismissRequest = { errorMessage = null },
            containerColor = SurfaceWhite,
            title = { Text(t("تعذّر الحفظ"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = { Text(err, color = TextSecondary) },
            confirmButton = {
                TextButton(onClick = { errorMessage = null }) {
                    Text(t("حسناً"), color = ForestGreen, fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}

@Composable
private fun MetaRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 11.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 12.sp)
        Text(value, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ActionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    tint: Color = ForestGreen,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(onClick = onClick, shape = CircleShape, color = tint.copy(alpha = 0.1f)) {
            Box(modifier = Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = tint)
            }
        }
        Text(label, fontSize = 11.sp, color = TextSecondary, modifier = Modifier.padding(top = 6.dp))
    }
}

package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.model.ActivityEntry
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenLight
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

/**
 * سجل النشاط — every catalog change, newest first.
 *
 * Entries are written by the repository on each successful write, so the log
 * reflects what actually reached Firestore rather than what was attempted.
 */
@Composable
fun ActivityLogScreen(repository: LibraryRepository, onBack: () -> Unit) {
    val entries by repository.activity.collectAsState()

    ScreenScaffold(title = t("سجل النشاط"), onBack = onBack) {
        if (entries.isEmpty()) {
            EmptyView(
                icon = Icons.Outlined.History,
                title = t("لا يوجد نشاط مسجّل"),
                detail = t("ستظهر هنا كل عملية إضافة أو تعديل أو حذف تتم على الفهرس.")
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(
                        text = t("%s عملية مسجّلة").format(entries.size),
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
                items(entries) { entry -> ActivityRow(entry) }
            }
        }
    }
}

@Composable
private fun ActivityRow(entry: ActivityEntry) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(36.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(shape = CircleShape, color = ForestGreenLight) {
                    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Outlined.History,
                            contentDescription = null,
                            tint = ForestGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    // The verb was stored in Arabic when the change was made;
                    // it is translated here, at the moment it is read.
                    text = "${t(entry.action)} ${entry.target}".trim(),
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = entry.actorName.ifBlank { t("مشرف") },
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
            Text(
                text = formatWhen(entry.atMillis),
                color = TextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

/** Relative Arabic time, falling back to a date for anything older than a week. */
private fun formatWhen(millis: Long): String {
    if (millis <= 0L) return t("الآن")
    val diff = System.currentTimeMillis() - millis
    val minutes = diff / 60_000
    val hours = minutes / 60
    val days = hours / 24
    return when {
        minutes < 1 -> t("الآن")
        minutes < 60 -> t("قبل %s د").format(minutes)
        hours < 24 -> t("قبل %s س").format(hours)
        days < 7 -> t("قبل %s ي").format(days)
        else -> {
            val cal = java.util.Calendar.getInstance()
            cal.timeInMillis = millis
            "%04d-%02d-%02d".format(
                cal.get(java.util.Calendar.YEAR),
                cal.get(java.util.Calendar.MONTH) + 1,
                cal.get(java.util.Calendar.DAY_OF_MONTH)
            )
        }
    }
}

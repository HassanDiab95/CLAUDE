package com.wujha.admin.data.model

/** A labelled count, used for every bar and ranked row in the app. */
data class CategoryCount(val label: String, val count: Int)

/**
 * Dashboard figures.
 *
 * Every number here is derived from the live catalog rather than stored, so
 * the dashboard can never drift out of sync with the books collection.
 */
data class DashboardStats(
    val totalBooks: Int = 0,
    val availableBooks: Int = 0,
    val borrowedBooks: Int = 0,
    val lostBooks: Int = 0,
    /** Book count per category, largest first — drives the dashboard chart. */
    val byCategory: List<CategoryCount> = emptyList()
)

/** Reports screen figures, also derived from the live collections. */
data class ReportStats(
    val totalBooks: Int = 0,
    val totalShelves: Int = 0,
    val totalMembers: Int = 0,
    val activeMembers: Int = 0,
    /** Available / borrowed / lost counts. */
    val statusBreakdown: List<CategoryCount> = emptyList(),
    /** Categories ranked by how many books they hold. */
    val topCategories: List<CategoryCount> = emptyList(),
    /** Book count per shelf, largest first. */
    val byShelf: List<CategoryCount> = emptyList()
)

/**
 * Loan figures for the dashboard and the reports screen.
 *
 * Like every other count in this file these are derived from the live
 * `loans` collection rather than stored, so they cannot drift — and
 * "overdue" in particular has to be derived, because nothing writes to a
 * loan on the night it falls due.
 */
data class LoanStats(
    /** Requests from the app waiting for a librarian to review. */
    val pendingRequests: Int = 0,
    /** Approved and waiting to be collected. */
    val awaitingPickup: Int = 0,
    /** Out with a borrower right now. */
    val activeLoans: Int = 0,
    /** Out and past the due date. */
    val overdueLoans: Int = 0,
    /** Falling due within three days. */
    val dueSoon: Int = 0,
    /** Borrowers who asked for more time. */
    val renewalRequests: Int = 0,
    /** Returned in the last 30 days. */
    val returnedRecently: Int = 0,
    /** Declared lost, all time. */
    val lostLoans: Int = 0,
    /** Titles ranked by how often they have been borrowed. */
    val topBorrowed: List<CategoryCount> = emptyList()
)

/** A browsable library section. */
data class Category(
    val id: String = "",
    val name: String = "",
    val iconKey: String = "book"
) {
    fun toMap(): Map<String, Any> = mapOf("name" to name, "iconKey" to iconKey)
}

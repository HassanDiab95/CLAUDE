package com.wujha.admin.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.Catalogs
import com.wujha.admin.data.LoanDates
import com.wujha.admin.data.model.Book
import com.wujha.admin.data.model.LibraryUser
import com.wujha.admin.data.model.UserStatus
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.storage.ImageCodec
import com.wujha.admin.data.storage.PhotoKind
import com.wujha.admin.data.storage.UploadResult
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.FormErrorBanner
import com.wujha.admin.ui.components.IdPhotoView
import com.wujha.admin.ui.components.DropdownField
import com.wujha.admin.ui.components.PickerOption
import com.wujha.admin.ui.components.PrimaryButton
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.components.SearchField
import com.wujha.admin.ui.components.SecondaryButton
import com.wujha.admin.ui.components.UserStatusDot
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackgroundAlt
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenMid
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Lending a book to somebody standing at the desk.
 *
 * This is the path for a borrower with no app — which, in a college library,
 * is most of them. It asks for the two things the loan cannot be written
 * without, the member and the book, and nothing else is required: the card
 * is in the librarian's hand, so there is nobody to verify and nothing to
 * wait for. The loan it writes is already issued and already has a due date.
 *
 * The one piece of cleverness is in the member search. Typing a number that
 * belongs to nobody offers to register that number as a new membership,
 * because a librarian holding an unfamiliar card should not have to abandon
 * a half-filled loan, go to another screen, and come back.
 */
@Composable
fun NewLoanScreen(
    repository: LibraryRepository,
    onBack: () -> Unit,
    onDone: () -> Unit,
    initialMemberId: String = "",
    initialBookId: String = ""
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val members by repository.members.collectAsState()
    val books by repository.books.collectAsState()
    val policy by repository.loanPolicy.collectAsState()

    var memberQuery by remember { mutableStateOf("") }
    var bookQuery by remember { mutableStateOf("") }
    var memberId by remember { mutableStateOf(initialMemberId) }
    var bookId by remember { mutableStateOf(initialBookId) }
    var notes by remember { mutableStateOf("") }
    var idPhoto by remember { mutableStateOf("") }
    var photoBusy by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // Set while a brand-new membership is being written, so the screen can
    // select it the moment it appears in the live members list.
    var awaitingIdNumber by remember { mutableStateOf("") }
    var showNewMember by remember { mutableStateOf(false) }

    val member = members.firstOrNull { it.id == memberId }
    val book = books.firstOrNull { it.id == bookId }

    LaunchedEffect(members, awaitingIdNumber) {
        if (awaitingIdNumber.isNotBlank()) {
            members.firstOrNull { it.idNumber == awaitingIdNumber }?.let {
                memberId = it.id
                memberQuery = ""
                awaitingIdNumber = ""
            }
        }
    }

    val memberMatches = remember(memberQuery, members, memberId) {
        val q = memberQuery.trim()
        if (q.isBlank() || memberId.isNotBlank()) {
            emptyList()
        } else {
            members.filter { it.name.contains(q, true) || it.idNumber.contains(q) }.take(6)
        }
    }

    val bookMatches = remember(bookQuery, books, bookId) {
        val q = bookQuery.trim()
        if (q.isBlank() || bookId.isNotBlank()) {
            emptyList()
        } else {
            books.filter {
                it.title.contains(q, true) ||
                    it.author.contains(q, true) ||
                    it.serial.contains(q, true) ||
                    it.shelf.contains(q, true)
            }.take(6)
        }
    }

    /** True when the typed search is a bare number nobody holds. */
    val unknownNumber = memberQuery.trim().let { q ->
        q.length >= 6 && q.all { it.isDigit() } && members.none { it.idNumber == q }
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null && !photoBusy) {
            photoBusy = true
            error = null
            scope.launch {
                when (val result = ImageCodec.encode(context, uri, PhotoKind.DOCUMENT)) {
                    is UploadResult.Success -> idPhoto = result.base64
                    is UploadResult.Failure -> error = result.message
                }
                photoBusy = false
            }
        }
    }

    ScreenScaffold(title = t("إعارة يدوية"), onBack = onBack) {
        // The scaffold above already paints the page; this just takes the
        // space left under the title bar.
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // ---- Step one: who ------------------------------------------
            item {
                StepCard(number = "1", title = t("العضو المستعير")) {
                    if (member == null) {
                        SearchField(
                            value = memberQuery,
                            onValueChange = { memberQuery = it },
                            placeholder = t("ابحث بالاسم أو رقم الهوية...")
                        )
                        if (memberMatches.isEmpty() && memberQuery.isNotBlank() && !unknownNumber) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = t("لا يوجد عضو مطابق. ابحث برقم الهوية لتسجيل عضوية جديدة."),
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        memberMatches.forEach { candidate ->
                            Spacer(Modifier.height(8.dp))
                            PickRow(
                                title = candidate.name,
                                subtitle = candidate.idNumber.ifBlank { t("بلا رقم هوية") },
                                icon = Icons.Outlined.Person,
                                enabled = candidate.status == UserStatus.ACTIVE,
                                disabledNote = t("العضوية موقوفة"),
                                onClick = { memberId = candidate.id; memberQuery = "" },
                                trailing = { UserStatusDot(status = candidate.status) }
                            )
                        }
                        if (unknownNumber) {
                            Spacer(Modifier.height(10.dp))
                            SecondaryButton(
                                text = t("تسجيل عضوية جديدة برقم %s").format(memberQuery.trim()),
                                onClick = { showNewMember = true },
                                leadingIcon = Icons.Outlined.PersonAdd,
                                iconTint = ForestGreenMid
                            )
                        }
                    } else {
                        ChosenRow(
                            title = member.name,
                            subtitle = listOfNotNull(
                                member.idNumber.takeIf { it.isNotBlank() },
                                member.phone.takeIf { it.isNotBlank() }
                            ).joinToString(" • ").ifBlank { t("بلا رقم هوية") },
                            icon = Icons.Outlined.Person,
                            onClear = { memberId = ""; memberQuery = "" }
                        )
                        val open = repository.loansForMember(member).count { it.holdsCopy }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = t("لديه %s إعارة مفتوحة من %s مسموحة.")
                                .format(open, policy.maxActivePerMember),
                            color = if (open >= policy.maxActivePerMember) SignalRed else TextSecondary,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }

            // ---- Step two: what -----------------------------------------
            item {
                StepCard(number = "2", title = t("الكتاب")) {
                    if (book == null) {
                        SearchField(
                            value = bookQuery,
                            onValueChange = { bookQuery = it },
                            placeholder = t("ابحث بالعنوان أو المؤلف أو الرقم التسلسلي...")
                        )
                        if (bookMatches.isEmpty() && bookQuery.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = t("لا يوجد كتاب مطابق لهذا البحث."),
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        bookMatches.forEach { candidate ->
                            Spacer(Modifier.height(8.dp))
                            PickRow(
                                title = candidate.title,
                                subtitle = listOfNotNull(
                                    candidate.serial.takeIf { it.isNotBlank() },
                                    candidate.shelf.takeIf { it.isNotBlank() }
                                ).joinToString(" • "),
                                icon = Icons.Outlined.MenuBook,
                                enabled = candidate.isBorrowable,
                                disabledNote = t("لا توجد نسخة متاحة"),
                                onClick = { bookId = candidate.id; bookQuery = "" },
                                trailing = { CopiesLabel(candidate) }
                            )
                        }
                    } else {
                        ChosenRow(
                            title = book.title,
                            subtitle = listOfNotNull(
                                book.serial.takeIf { it.isNotBlank() },
                                book.shelf.takeIf { it.isNotBlank() }
                            ).joinToString(" • "),
                            icon = Icons.Outlined.MenuBook,
                            onClear = { bookId = ""; bookQuery = "" }
                        )
                        Spacer(Modifier.height(6.dp))
                        CopiesLabel(book)
                    }
                }
            }

            // ---- Step three: the paperwork ------------------------------
            item {
                StepCard(number = "3", title = t("تفاصيل إضافية (اختيارية)")) {
                    Text(
                        text = t("صورة الهوية ليست مطلوبة هنا لأن البطاقة بين يديك. أضفها إن أردت توثيق الاستلام."),
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    if (idPhoto.isNotBlank()) {
                        IdPhotoView(base64 = idPhoto)
                        Spacer(Modifier.height(8.dp))
                        SecondaryButton(
                            text = t("إزالة الصورة"),
                            onClick = { idPhoto = "" },
                            iconTint = SignalRed
                        )
                    } else {
                        SecondaryButton(
                            text = if (photoBusy) t("جارٍ المعالجة...") else t("إضافة صورة الهوية"),
                            onClick = {
                                picker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            leadingIcon = Icons.Outlined.AddAPhoto,
                            iconTint = ForestGreenMid,
                            enabled = !photoBusy
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    WujhaTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        placeholder = t("ملاحظات داخلية (اختياري)"),
                        singleLine = false,
                        fieldHeight = 76
                    )
                }
            }

            // ---- The summary, then the one button -----------------------
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = CreamBackgroundAlt
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = t("ملخّص الإعارة"),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                        Spacer(Modifier.height(8.dp))
                        SummaryLine(t("تاريخ التسليم"), LoanDates.today())
                        SummaryLine(
                            t("تاريخ الإرجاع"),
                            LoanDates.format(LoanDates.dueDate(policy.loanDays))
                        )
                        SummaryLine(t("المدة"), t("%s يوماً").format(policy.loanDays))
                        SummaryLine(
                            t("التجديد"),
                            if (policy.maxRenewals > 0) {
                                t("مسموح %s مرة بـ %s يوماً").format(policy.maxRenewals, policy.renewDays)
                            } else {
                                t("غير مسموح")
                            }
                        )
                    }
                }
            }

            val currentError = error
            if (currentError != null) {
                item {
                    FormErrorBanner(
                        message = currentError,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                }
            }

            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                    PrimaryButton(
                        text = t("تسجيل الإعارة"),
                        onClick = {
                            val chosenMember = member
                            val chosenBook = book
                            when {
                                chosenMember == null -> error = t("اختر العضو المستعير.")
                                chosenBook == null -> error = t("اختر الكتاب المُعار.")
                                else -> {
                                    busy = true
                                    error = null
                                    scope.launch {
                                        val failure = repository.createDeskLoan(
                                            book = chosenBook,
                                            member = chosenMember,
                                            notes = notes,
                                            idPhotoBase64 = idPhoto
                                        )
                                        busy = false
                                        if (failure == null) onDone() else error = failure
                                    }
                                }
                            }
                        },
                        loading = busy,
                        enabled = !photoBusy
                    )
                }
            }
        }
    }

    if (showNewMember) {
        NewMemberDialog(
            idNumber = memberQuery.trim(),
            onDismiss = { showNewMember = false },
            onCreate = { name, phone, type ->
                showNewMember = false
                val number = memberQuery.trim()
                busy = true
                error = null
                scope.launch {
                    val failure = repository.addMember(
                        LibraryUser(
                            name = name,
                            idNumber = number,
                            status = UserStatus.ACTIVE,
                            phone = phone,
                            joinDate = LoanDates.today(),
                            memberType = type
                        )
                    )
                    busy = false
                    if (failure == null) {
                        // The write is done; the live listener will deliver
                        // the document a moment later, and the effect above
                        // selects it then.
                        awaitingIdNumber = number
                    } else {
                        error = failure
                    }
                }
            }
        )
    }
}

/** Registers a membership from the number the librarian just typed. */
@Composable
private fun NewMemberDialog(
    idNumber: String,
    onDismiss: () -> Unit,
    onCreate: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(Catalogs.memberTypes.first()) }
    var nameError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = { Text(t("عضوية جديدة"), fontWeight = FontWeight.Bold, color = TextPrimary) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Outlined.Badge,
                        contentDescription = null,
                        tint = ForestGreenMid,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = t("رقم الهوية: %s").format(idNumber),
                        color = TextSecondary,
                        fontSize = 12.5.sp
                    )
                }
                Spacer(Modifier.height(12.dp))
                WujhaTextField(
                    value = name,
                    onValueChange = { name = it; nameError = null },
                    placeholder = t("الاسم الكامل"),
                    errorText = nameError
                )
                Spacer(Modifier.height(10.dp))
                WujhaTextField(
                    value = phone,
                    onValueChange = { input -> phone = input.filter { it.isDigit() }.take(10) },
                    placeholder = t("رقم الجوال"),
                    keyboardType = KeyboardType.Phone
                )
                Spacer(Modifier.height(10.dp))
                DropdownField(
                    label = t("نوع العضوية"),
                    options = Catalogs.memberTypes.map { PickerOption(it, t(it)) },
                    selectedValue = type,
                    onSelect = { type = it }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) {
                    nameError = t("الرجاء إدخال الاسم")
                } else {
                    onCreate(name.trim(), phone.trim(), type)
                }
            }) {
                Text(t("تسجيل العضوية"), color = ForestGreen, fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(t("إلغاء"), color = TextSecondary) }
        }
    )
}

/** A numbered section, so the screen reads as three steps rather than a form. */
@Composable
private fun StepCard(number: String, title: String, content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(22.dp).clip(CircleShape).background(ForestGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Text(number, color = SurfaceWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = TextPrimary)
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

/** A candidate in a search result list. */
@Composable
private fun PickRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    disabledNote: String,
    onClick: () -> Unit,
    trailing: @Composable () -> Unit
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = if (enabled) SurfaceWhite else CreamBackgroundAlt,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (enabled) ForestGreenMid else TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (enabled) TextPrimary else TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (enabled) subtitle else "$subtitle • $disabledNote",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            trailing()
        }
    }
}

/** What has been chosen, with a way to change it. */
@Composable
private fun ChosenRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClear: () -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.size(34.dp).clip(CircleShape).background(ForestGreen.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(17.dp))
        }
        Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(text = subtitle, fontSize = 11.sp, color = TextSecondary)
        }
        TextButton(onClick = onClear) {
            Text(t("تغيير"), color = ForestGreenMid, fontSize = 12.sp)
        }
    }
}

/** How many copies are free, in the colour that says whether that is good. */
@Composable
private fun CopiesLabel(book: Book) {
    val free = book.availableCopies
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (free > 0) {
            Icon(
                Icons.Outlined.CheckCircle,
                contentDescription = null,
                tint = ForestGreenMid,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(4.dp))
        }
        Text(
            text = t("%s متاحة من %s").format(free, book.copies),
            fontSize = 11.sp,
            color = if (free > 0) ForestGreenMid else SignalRed,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun SummaryLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 12.sp)
        Text(value, color = TextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
    }
}

package com.wujha.admin.data.model

/** What an admin document grants. */
enum class AdminRole(val key: String, val labelAr: String) {
    /** The account that set the library up. Cannot be removed from inside the app. */
    OWNER("owner", "المالك"),

    /** A librarian who can edit everything. */
    ADMIN("admin", "مشرف");

    companion object {
        fun from(raw: String?): AdminRole = entries.firstOrNull { it.key == raw } ?: ADMIN
    }
}

/**
 * A document in the `admins` collection, keyed by the account's user id.
 *
 * Its existence *is* the permission: every security rule that allows a write
 * asks whether `admins/{your uid}` exists. Nothing inside the document grants
 * anything — the name and email are copied in only so the management screen
 * can show who an id belongs to without a second lookup.
 */
data class AdminGrant(
    val uid: String = "",
    val role: AdminRole = AdminRole.ADMIN,
    val name: String = "",
    val email: String = "",
    val grantedByName: String = "",
    val grantedAtMillis: Long = 0L
) {
    val isOwner: Boolean get() = role == AdminRole.OWNER

    val label: String get() = name.ifBlank { email.substringBefore("@") }.ifBlank { uid.take(6) }
}

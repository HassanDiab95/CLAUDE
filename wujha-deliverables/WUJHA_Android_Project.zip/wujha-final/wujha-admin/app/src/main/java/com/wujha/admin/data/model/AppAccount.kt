package com.wujha.admin.data.model

/**
 * One person's app account, stored at `users/{uid}`.
 *
 * Both apps write this the moment someone signs in. It exists for two
 * reasons: it is where a profile photo lives, and it is what lets an admin
 * grant the admin role by picking a name off a list instead of copying a
 * user id out of the Firebase console.
 */
data class AppAccount(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    /** Base64 JPEG profile photo. Empty means none — the UI draws an initial. */
    val photoBase64: String = "",
    /** Which app this account last signed in from: "admin" or "user". */
    val app: String = "",
    /** True for "continue as guest" accounts, which own nothing worth granting. */
    val anonymous: Boolean = false,
    val lastSeenMillis: Long = 0L
) {
    val initial: String get() = name.trim().take(1).ifBlank { email.take(1) }.ifBlank { "؟" }

    val label: String get() = name.ifBlank { email.substringBefore("@") }.ifBlank { uid.take(6) }
}

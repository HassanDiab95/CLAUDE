package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.LoanDates
import com.wujha.admin.data.model.LibraryUser
import com.wujha.admin.data.model.UserStatus
import com.wujha.admin.data.repository.DataStatus
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.ErrorView
import com.wujha.admin.ui.components.FilterChip
import com.wujha.admin.ui.components.LoadingView
import com.wujha.admin.ui.components.LoanRow
import com.wujha.admin.ui.components.SecondaryButton
import com.wujha.admin.ui.components.SearchField
import com.wujha.admin.ui.components.UserStatusDot
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackground
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.StatusLostText
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

private enum class UserFilter(val label: String) {
    ALL("الكل"), ACTIVE("نشط"), SUSPENDED("موقوف")
}

/**
 * The membership register: who is entitled to borrow.
 *
 * It is not the list of app accounts — that is in «المشرفون والصلاحيات»,
 * where an account can be given the admin role. A membership here exists
 * whether or not its holder ever installs anything, which is the whole
 * point: the librarian types a card number at the desk and the person can
 * borrow.
 */
@Composable
fun ManageUsersScreen(
    repository: LibraryRepository,
    onOpenLoan: (String) -> Unit,
    onLendTo: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(UserFilter.ALL) }
    var selected by remember { mutableStateOf<LibraryUser?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    val allUsers by repository.members.collectAsState()
    val status by repository.status.collectAsState()

    val filtered = remember(query, filter, allUsers) {
        allUsers
            .filter { query.isBlank() || it.name.contains(query, true) || it.idNumber.contains(query) }
            .filter {
                when (filter) {
                    UserFilter.ALL -> true
                    UserFilter.ACTIVE -> it.status == UserStatus.ACTIVE
                    UserFilter.SUSPENDED -> it.status == UserStatus.SUSPENDED
                }
            }
    }

    if (status is DataStatus.Error) {
        ErrorView(
            message = (status as DataStatus.Error).message,
            modifier = Modifier.background(CreamBackground)
        )
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = t("إدارة المستخدمين"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    onClick = { showAdd = true },
                    shape = RoundedCornerShape(10.dp),
                    color = ForestGreen
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Add,
                            contentDescription = null,
                            tint = SurfaceWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(t("إضافة"), color = SurfaceWhite, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        if (allUsers.isEmpty() && status is DataStatus.Ready) {
            item {
                EmptyView(
                    icon = Icons.Outlined.People,
                    title = t("لا يوجد مستخدمون"),
                    detail = t("أضف أعضاء المكتبة لتتمكّن من متابعة عضوياتهم."),
                    actionLabel = t("إضافة مستخدم"),
                    onAction = { showAdd = true }
                )
            }
            return@LazyColumn
        }

        if (allUsers.isEmpty()) {
            item { LoadingView(message = t("جارٍ تحميل المستخدمين...")) }
            return@LazyColumn
        }

        item {
            SearchField(
                value = query,
                onValueChange = { query = it },
                placeholder = t("ابحث بالاسم أو رقم الهوية..."),
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                UserFilter.entries.forEach { f ->
                    FilterChip(label = t(f.label), selected = filter == f, onClick = { filter = f })
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (filtered.isEmpty()) {
            item {
                Text(
                    text = t("لا يوجد مستخدمون مطابقون لهذا البحث."),
                    color = TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().padding(32.dp)
                )
            }
        }

        items(filtered) { user ->
            UserRow(user = user, onClick = { selected = user })
        }
    }

    val active = selected
    if (active != null) {
        val suspending = active.status == UserStatus.ACTIVE
        val memberLoans = repository.loansForMember(active)
        val openLoans = memberLoans.filter { it.holdsCopy }
        val overdue = memberLoans.count { it.isOverdue }
        AlertDialog(
            onDismissRequest = { selected = null },
            containerColor = SurfaceWhite,
            title = { Text(active.name, fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Column {
                    Text(t("رقم الهوية: %s").format(active.idNumber), color = TextSecondary, fontSize = 13.sp)
                    if (active.joinDate.isNotBlank()) {
                        Text(t("تاريخ الانضمام: %s").format(active.joinDate), color = TextSecondary, fontSize = 13.sp)
                    }
                    Text(t("الحالة: %s").format(t(active.status.labelAr)), color = TextSecondary, fontSize = 13.sp)
                    Text(
                        text = t("الإعارات المفتوحة: %s").format(openLoans.size),
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    if (overdue > 0) {
                        Text(
                            text = t("متأخرة: %s").format(overdue),
                            color = StatusLostText,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    // The open loans themselves, because "has two books out"
                    // is never the question — "which two" is.
                    openLoans.take(3).forEach { loan ->
                        LoanRow(
                            loan = loan,
                            onClick = { selected = null; onOpenLoan(loan.id) },
                            modifier = Modifier.padding(horizontal = 0.dp)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    SecondaryButton(
                        text = t("إعارة كتاب لهذا العضو"),
                        onClick = { selected = null; onLendTo(active.id) },
                        enabled = active.status == UserStatus.ACTIVE
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    selected = null
                    scope.launch { repository.toggleMemberStatus(active) }
                }) {
                    Text(
                        text = if (suspending) t("إيقاف العضوية") else t("إعادة التفعيل"),
                        color = if (suspending) StatusLostText else ForestGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    selected = null
                    scope.launch { repository.deleteMember(active) }
                }) { Text(t("حذف"), color = StatusLostText) }
            }
        )
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var idNumber by remember { mutableStateOf("") }
        var nameError by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = SurfaceWhite,
            title = { Text(t("مستخدم جديد"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Column {
                    WujhaTextField(
                        value = name,
                        onValueChange = { name = it; nameError = null },
                        placeholder = t("الاسم الكامل"),
                        errorText = nameError
                    )
                    Spacer(Modifier.height(10.dp))
                    WujhaTextField(
                        value = idNumber,
                        onValueChange = { input -> idNumber = input.filter { it.isDigit() }.take(12) },
                        placeholder = t("رقم الهوية"),
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isBlank()) {
                        nameError = t("الرجاء إدخال الاسم")
                    } else {
                        val member = LibraryUser(
                            name = name.trim(),
                            idNumber = idNumber.trim(),
                            status = UserStatus.ACTIVE,
                            joinDate = LoanDates.today()
                        )
                        showAdd = false
                        scope.launch { repository.addMember(member) }
                    }
                }) { Text(t("إضافة"), color = ForestGreen, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false }) { Text(t("إلغاء"), color = TextSecondary) }
            }
        )
    }
}

@Composable
private fun UserRow(user: LibraryUser, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape).background(ForestGreen.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Person, contentDescription = null, tint = ForestGreen)
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(user.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextPrimary)
                Text(user.idNumber.ifBlank { t("بلا رقم هوية") }, fontSize = 11.sp, color = TextSecondary)
            }
            UserStatusDot(status = user.status)
        }
    }
}

package com.wujha.admin.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.auth.AuthProviderHolder
import com.wujha.admin.data.auth.AuthResult
import com.wujha.admin.data.auth.AuthValidator
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.AuthScreenColumn
import com.wujha.admin.ui.components.FormErrorBanner
import com.wujha.admin.ui.components.PrimaryButton
import com.wujha.admin.ui.components.WujhaLockup
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.TextOnBackdrop
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/** Creates a new email/password account, then drops straight into the app. */
@Composable
fun SignUpScreen(
    onSignedUp: () -> Unit,
    onBackToLogin: () -> Unit
) {
    val repository = AuthProviderHolder.repository
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    var nameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    fun submit() {
        if (loading) return
        nameError = AuthValidator.nameError(name)
        emailError = AuthValidator.emailError(email)
        passwordError = AuthValidator.passwordError(password)
        confirmError = AuthValidator.confirmError(password, confirm)
        if (nameError != null || emailError != null ||
            passwordError != null || confirmError != null
        ) {
            return
        }

        formError = null
        loading = true
        scope.launch {
            when (val result = repository.signUpWithEmail(name, email, password)) {
                is AuthResult.Success -> {
                    loading = false
                    onSignedUp()
                }
                is AuthResult.Failure -> {
                    loading = false
                    formError = result.message
                }
            }
        }
    }

    AuthScreenColumn(
        horizontalPadding = 24.dp,
        verticalPadding = 24.dp,
        horizontalAlignment = Alignment.Start
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBackToLogin, enabled = !loading) {
                Icon(
                    imageVector = Icons.Outlined.ChevronLeft,
                    contentDescription = t("رجوع"),
                    tint = TextOnBackdrop
                )
            }
        }

        WujhaLockup(
            height = 86.dp,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(18.dp))
        Text(text = t("إنشاء حساب جديد"), color = TextOnBackdrop, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            text = t("أنشئ حساب مشرف للوصول إلى لوحة تحكم المكتبة"),
            color = TextSecondary,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(24.dp))

        WujhaTextField(
            value = name,
            onValueChange = { name = it; nameError = null; formError = null },
            placeholder = t("الاسم الكامل"),
            leadingIcon = Icons.Outlined.PersonOutline,
            enabled = !loading,
            errorText = nameError
        )
        Spacer(Modifier.height(12.dp))

        WujhaTextField(
            value = email,
            onValueChange = { email = it; emailError = null; formError = null },
            placeholder = t("البريد الإلكتروني"),
            leadingIcon = Icons.Outlined.Email,
            keyboardType = KeyboardType.Email,
            enabled = !loading,
            errorText = emailError
        )
        Spacer(Modifier.height(12.dp))

        WujhaTextField(
            value = password,
            onValueChange = { password = it; passwordError = null; formError = null },
            placeholder = t("كلمة المرور (6 أحرف على الأقل)"),
            leadingIcon = Icons.Outlined.Lock,
            isPassword = true,
            keyboardType = KeyboardType.Password,
            enabled = !loading,
            errorText = passwordError
        )
        Spacer(Modifier.height(12.dp))

        WujhaTextField(
            value = confirm,
            onValueChange = { confirm = it; confirmError = null; formError = null },
            placeholder = t("تأكيد كلمة المرور"),
            leadingIcon = Icons.Outlined.Lock,
            isPassword = true,
            keyboardType = KeyboardType.Password,
            imeAction = ImeAction.Done,
            enabled = !loading,
            errorText = confirmError
        )

        Spacer(Modifier.height(20.dp))

        if (formError != null) {
            FormErrorBanner(message = formError.orEmpty())
            Spacer(Modifier.height(12.dp))
        }

        PrimaryButton(
            text = t("إنشاء الحساب"),
            onClick = { submit() },
            loading = loading
        )

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(t("لديك حساب بالفعل؟"), color = TextSecondary, fontSize = 13.sp)
            TextButton(onClick = onBackToLogin, enabled = !loading) {
                Text(t("تسجيل الدخول"), color = ForestGreen, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

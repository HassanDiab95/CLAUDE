package com.wujha.admin.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import com.wujha.admin.data.Localization
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

/**
 * Built on every call because the palette values are getters: each one
 * answers with its light or dark value, so the same mapping serves both.
 */
private fun wujhaColors(dark: Boolean) =
    if (dark) darkColorScheme(
        primary = ForestGreen,
        onPrimary = TextOnPrimary,
        primaryContainer = ForestGreenLight,
        onPrimaryContainer = TextPrimary,
        secondary = AccentGold,
        onSecondary = TextOnPrimary,
        secondaryContainer = AccentGoldWash,
        onSecondaryContainer = AccentGoldDark,
        background = CreamBackground,
        onBackground = TextPrimary,
        surface = SurfaceWhite,
        onSurface = TextPrimary,
        surfaceVariant = CreamBackgroundAlt,
        onSurfaceVariant = TextSecondary,
        outline = BorderLight,
        error = StatusLostText,
        onError = TextOnPrimary,
        errorContainer = StatusLostBg,
        onErrorContainer = StatusLostText
    ) else lightColorScheme(
        primary = ForestGreen,
        onPrimary = TextOnPrimary,
        primaryContainer = ForestGreenLight,
        onPrimaryContainer = ForestGreenDark,
        secondary = AccentGold,
        onSecondary = TextOnPrimary,
        secondaryContainer = AccentGoldLight,
        onSecondaryContainer = AccentGoldDark,
        background = CreamBackground,
        onBackground = TextPrimary,
        surface = SurfaceWhite,
        onSurface = TextPrimary,
        surfaceVariant = CreamBackgroundAlt,
        onSurfaceVariant = TextSecondary,
        outline = BorderLight,
        error = StatusLostText,
        onError = TextOnPrimary,
        errorContainer = StatusLostBg,
        onErrorContainer = StatusLostText
    )

/**
 * App-wide theme for WUJHA Admin. The interface is Arabic-first, so layout
 * direction defaults to RTL regardless of the device locale — this mirrors
 * the approved mockups where every screen reads right-to-left.
 */
@Composable
fun WujhaTheme(
    content: @Composable () -> Unit
) {
    // Light, dark or "same as the phone" — chosen on the appearance screen.
    val darkTheme = WujhaThemeState.isDark
    val direction = if (Localization.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        MaterialTheme(
            colorScheme = wujhaColors(darkTheme),
            typography = WujhaTypography,
            content = content
        )
    }
}

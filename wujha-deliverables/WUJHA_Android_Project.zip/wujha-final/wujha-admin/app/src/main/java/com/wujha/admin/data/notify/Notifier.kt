package com.wujha.admin.data.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.wujha.admin.MainActivity
import com.wujha.admin.R
import com.wujha.admin.data.t

/**
 * The librarian's notification tray.
 *
 * Posted by the app itself from the live `loans` listener while it is
 * running — there is no push server in this project, so a request that
 * arrives overnight is waiting in the الإعارة tab in the morning rather
 * than buzzing at three a.m. The counters on that tab are the record; this
 * is the nudge while the app is open.
 */
object Notifier {

    private const val CHANNEL_ID = "wujha_loans"

    /** Android 13 and up refuse to show anything without the user's consent. */
    val permission: String = Manifest.permission.POST_NOTIFICATIONS

    fun needsPermission(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    fun hasPermission(context: Context): Boolean =
        !needsPermission() || ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Creates the channel. Safe to call on every launch — Android keeps the
     * first definition and ignores the rest, which is why the name is set
     * from the current language each time rather than once ever.
     */
    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            t("الإعارة"),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = t("طلبات الإعارة الواردة والإعارات المتأخرة")
        }
        manager.createNotificationChannel(channel)
    }

    /**
     * Posts one event, and opens the app on «إعاراتي» when it is tapped.
     *
     * The notification id is derived from the event's own key, so the same
     * event can never stack up twice in the tray.
     */
    // The permission is checked on the line below, but lint cannot follow a
    // check that lives in another function — hence the suppression rather
    // than a second, redundant check here.
    @SuppressLint("MissingPermission")
    fun post(context: Context, event: LoanEvent) {
        if (!hasPermission(context)) return
        ensureChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_OPEN_LOANS, true)
        }
        val pending = PendingIntent.getActivity(
            context,
            event.key.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(event.title)
            .setContentText(event.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(event.body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()

        // A refused post is not worth crashing over: the event is still in
        // the in-app list, which is the copy that matters.
        runCatching {
            NotificationManagerCompat.from(context).notify(event.key.hashCode(), notification)
        }
    }

    const val EXTRA_OPEN_LOANS = "com.wujha.admin.OPEN_LOANS"
}

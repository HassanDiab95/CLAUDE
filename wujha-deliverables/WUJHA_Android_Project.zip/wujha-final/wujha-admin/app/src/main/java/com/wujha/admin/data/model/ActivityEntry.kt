package com.wujha.admin.data.model

/**
 * One line in the admin activity log — written every time a librarian
 * changes the catalog, so سجل النشاط shows who did what and when.
 */
data class ActivityEntry(
    val id: String = "",
    /** Arabic description of the action, e.g. "أضاف كتاباً". */
    val action: String = "",
    /** What was acted on, e.g. the book title. */
    val target: String = "",
    val actorName: String = "",
    val actorUid: String = "",
    /** Epoch millis; 0 while the server timestamp is still resolving. */
    val atMillis: Long = 0L
)

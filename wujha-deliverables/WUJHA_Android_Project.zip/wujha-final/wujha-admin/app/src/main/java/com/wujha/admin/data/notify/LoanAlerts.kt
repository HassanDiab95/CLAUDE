package com.wujha.admin.data.notify

import com.wujha.admin.data.LoanDates
import com.wujha.admin.data.model.Loan
import com.wujha.admin.data.model.LoanStatus
import com.wujha.admin.data.t

/** What the desk needs to know about, in the order it needs to know it. */
enum class LoanAlertKind { REQUEST, RENEWAL, OVERDUE, PICKUP_EXPIRED }

/**
 * One nudge for the librarian.
 *
 * Same shape and the same reasoning as the visitor's events: [key] is built
 * from the loan and the stamp behind the alert, so «طلب جديد» is announced
 * once and not again on every launch.
 */
data class LoanEvent(
    val key: String,
    val loanId: String,
    val kind: LoanAlertKind,
    val atMillis: Long,
    val title: String,
    val body: String
)

/**
 * Works out what the desk should be told, from the loans themselves.
 *
 * Derived rather than delivered, for the same reason as on the visitor's
 * side: nothing in this project can send a push, but the admin app is
 * already streaming every loan — so a request that arrives while the app is
 * open becomes a notification, and one that arrives while it is closed is
 * counted on the الإعارة tab when it opens.
 */
object LoanAlerts {

    fun from(loans: List<Loan>, pickupWindowDays: Int): List<LoanEvent> {
        val out = mutableListOf<LoanEvent>()

        loans.forEach { loan ->
            when {
                loan.status == LoanStatus.REQUESTED -> out += LoanEvent(
                    key = "${loan.id}:REQUEST:${loan.requestedAt}",
                    loanId = loan.id,
                    kind = LoanAlertKind.REQUEST,
                    atMillis = loan.requestedAt,
                    title = t("طلب إعارة جديد"),
                    body = t("«%s» — %s").format(loan.bookTitle, loan.borrowerLabel)
                )

                loan.status == LoanStatus.ACTIVE && loan.renewRequested -> out += LoanEvent(
                    key = "${loan.id}:RENEWAL:${loan.dueAt}",
                    loanId = loan.id,
                    kind = LoanAlertKind.RENEWAL,
                    atMillis = loan.dueAt,
                    title = t("طلب تجديد مدة"),
                    body = t("«%s» — %s").format(loan.bookTitle, loan.borrowerLabel)
                )

                loan.isOverdue -> out += LoanEvent(
                    key = "${loan.id}:OVERDUE:${loan.dueAt}",
                    loanId = loan.id,
                    kind = LoanAlertKind.OVERDUE,
                    atMillis = loan.dueAt,
                    title = t("إعارة متأخرة"),
                    body = t("«%s» — %s — %s").format(
                        loan.bookTitle,
                        loan.borrowerLabel,
                        LoanDates.overdueLabel(loan.daysLate)
                    )
                )

                // A hold nobody collected: the copy is sitting behind the
                // desk doing nothing, and only the librarian can free it.
                loan.status == LoanStatus.APPROVED &&
                    LoanDates.dueDate(pickupWindowDays, loan.decidedAt) < LoanDates.now() ->
                    out += LoanEvent(
                        key = "${loan.id}:PICKUP:${loan.decidedAt}",
                        loanId = loan.id,
                        kind = LoanAlertKind.PICKUP_EXPIRED,
                        atMillis = loan.decidedAt,
                        title = t("انتهت مدة حجز نسخة"),
                        body = t("«%s» — %s — لم تُستلم في موعدها").format(
                            loan.bookTitle,
                            loan.borrowerLabel
                        )
                    )
            }
        }

        return out.filter { it.atMillis > 0L }.sortedByDescending { it.atMillis }
    }
}

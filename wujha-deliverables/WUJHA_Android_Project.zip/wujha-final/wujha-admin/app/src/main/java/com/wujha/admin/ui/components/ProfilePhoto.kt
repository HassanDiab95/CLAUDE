package com.wujha.admin.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.repository.AccountRepository
import com.wujha.admin.data.storage.ImageCodec
import com.wujha.admin.data.storage.PhotoKind
import com.wujha.admin.data.storage.UploadResult
import com.wujha.admin.data.t
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenWash
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * A person's photo, or the first letter of their name when they have none.
 *
 * The photo arrives as a Base64 JPEG on their own `users/{uid}` document, so
 * decoding it is cheap and needs no network call — but it is still decoding,
 * so the result is remembered against the string rather than redone on every
 * recomposition.
 */
@Composable
fun ProfileAvatar(
    photoBase64: String,
    initial: String,
    size: Dp,
    modifier: Modifier = Modifier,
    background: Color = ForestGreen,
    foreground: Color = SurfaceWhite
) {
    val bitmap = remember(photoBase64) { ImageCodec.decode(photoBase64) }
    Box(
        modifier = modifier.size(size).clip(CircleShape).background(background),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = t("الصورة الشخصية"),
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size).clip(CircleShape)
            )
        } else {
            Text(
                text = initial,
                color = foreground,
                fontSize = (size.value * 0.38f).sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Pick a profile photo, or clear the one already there.
 *
 * The picked image is downscaled, centre-cropped and compressed before being
 * stored, and it is stored on the account document itself rather than in a
 * storage bucket — which is why the whole app needs no Firebase Storage.
 *
 * `PickVisualMedia` is the modern photo picker: it hands back one image the
 * person chose and nothing else, so the app never asks for permission to
 * read their gallery.
 */
@Composable
fun ProfilePhotoPicker(
    photoBase64: String,
    initial: String,
    accountRepository: AccountRepository,
    modifier: Modifier = Modifier,
    size: Dp = 76.dp
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun store(uri: Uri) {
        if (busy) return
        busy = true
        error = null
        scope.launch {
            when (val result = ImageCodec.encode(context, uri, PhotoKind.AVATAR)) {
                is UploadResult.Success -> {
                    error = accountRepository.setPhoto(result.base64)
                }
                is UploadResult.Failure -> error = result.message
            }
            busy = false
        }
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) store(uri) }

    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(contentAlignment = Alignment.Center) {
            ProfileAvatar(
                photoBase64 = photoBase64,
                initial = initial,
                size = size,
                background = ForestGreenWash,
                foreground = ForestGreen
            )
            if (busy) {
                Box(
                    modifier = Modifier.size(size).clip(CircleShape).background(Color(0x99000000)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = SurfaceWhite, strokeWidth = 2.dp)
                }
            } else if (photoBase64.isBlank()) {
                Box(
                    modifier = Modifier.size(size).clip(CircleShape),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AddAPhoto,
                        contentDescription = null,
                        tint = ForestGreen,
                        modifier = Modifier.size(16.dp).padding(bottom = 0.dp)
                    )
                }
            }
        }

        Column(modifier = Modifier.padding(start = 14.dp)) {
            Surface(
                onClick = {
                    picker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                enabled = !busy,
                shape = RoundedCornerShape(10.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Text(
                    text = if (photoBase64.isBlank()) t("إضافة صورة شخصية") else t("تغيير الصورة"),
                    color = ForestGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                )
            }
            if (photoBase64.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Surface(
                    onClick = {
                        if (!busy) {
                            busy = true
                            scope.launch {
                                error = accountRepository.clearPhoto()
                                busy = false
                            }
                        }
                    },
                    enabled = !busy,
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Text(
                        text = t("إزالة الصورة"),
                        color = SignalRed,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                    )
                }
            }
            val currentError = error
            if (currentError != null) {
                Spacer(Modifier.height(6.dp))
                Text(currentError, color = SignalRed, fontSize = 11.sp)
            } else if (photoBase64.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = t("محفوظة مع حسابك (%s ك.ب)").format(ImageCodec.storedKilobytes(photoBase64)),
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

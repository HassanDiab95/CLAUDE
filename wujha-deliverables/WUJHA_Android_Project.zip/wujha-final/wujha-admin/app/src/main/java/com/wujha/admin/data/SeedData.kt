package com.wujha.admin.data

import com.wujha.admin.data.model.Aisle
import com.wujha.admin.data.model.Block
import com.wujha.admin.data.model.Book
import com.wujha.admin.data.model.BookStatus
import com.wujha.admin.data.model.Category
import com.wujha.admin.data.model.Floor
import com.wujha.admin.data.model.LibraryUser
import com.wujha.admin.data.model.Loan
import com.wujha.admin.data.model.LoanChannel
import com.wujha.admin.data.model.LoanStatus
import com.wujha.admin.data.model.Shelf
import com.wujha.admin.data.model.UserStatus

/**
 * The starter library, written to Firestore **once**.
 *
 * The first account to sign in to an empty database claims it, and the
 * repository writes everything below in one pass. A flag on `meta/setup` is
 * set the moment that finishes, and every admin on every device reads that
 * same flag — so the button that runs this can never appear a second time,
 * for anyone.
 *
 * The apps never read this file at runtime; they read Firestore. Every id is
 * fixed rather than auto-generated, so an interrupted run that resumes
 * overwrites the same documents instead of doubling them.
 *
 * ## What is real and what is filler
 *
 * Titles, authors and the one-line descriptions are real. The fields a
 * library assigns itself — serial number, number of copies, which bookcase,
 * which level, the date it was catalogued — are generated, because they only
 * mean anything inside this particular library.
 *
 * Publisher, page count and rating are deliberately left empty. They are
 * edition-specific facts, and a catalog that quietly invents them is worse
 * than one that shows a blank waiting to be filled in.
 *
 * ## The building
 *
 * Four floors holding 14 blocks and 25 aisles — see [floors] for the
 * exact shape. Each floor holds blocks laid out on a grid; the gaps between
 * them are the corridors the map draws, and each block holds aisles of
 * bookcases. A code such as `2-B1-1` reads: second floor, aisle B1, first
 * bookcase along it.
 */
object SeedData {

    /** Bump when the content below changes; stored on `meta/setup`. */
    const val VERSION = 4

    // ---------------------------------------------------------------------
    // The building: 4 floors, 14 blocks, 25 aisles
    // ---------------------------------------------------------------------

    val floors = listOf(
        Floor(
            id = "ground",
            name = "الدور الأرضي",
            nameEn = "Ground Floor",
            order = 0,
            blocks = listOf(
                Block(
                    code = "A",
                    name = "بلوك الأدب العربي",
                    nameEn = "Arabic Literature Block",
                    row = 0,
                    column = 0,
                    aisles = listOf(
                        Aisle("A1", "ممر الروايات العربية", "Arabic Novels Aisle", 0),
                        Aisle("A2", "ممر القصة القصيرة", "Short Story Aisle", 1)
                    )
                ),
                Block(
                    code = "B",
                    name = "بلوك الأدب المترجم",
                    nameEn = "Translated Literature Block",
                    row = 0,
                    column = 1,
                    aisles = listOf(
                        Aisle("B1", "ممر الروايات المترجمة", "Translated Novels Aisle", 0),
                        Aisle("B2", "ممر المسرح", "Drama Aisle", 1)
                    )
                ),
                Block(
                    code = "C",
                    name = "بلوك الشعر",
                    nameEn = "Poetry Block",
                    row = 1,
                    column = 0,
                    aisles = listOf(
                        Aisle("C1", "ممر الشعر العربي", "Arabic Poetry Aisle", 0)
                    )
                ),
                Block(
                    code = "D",
                    name = "بلوك الرحلات والجغرافيا",
                    nameEn = "Travel & Geography Block",
                    row = 1,
                    column = 1,
                    aisles = listOf(
                        Aisle("D1", "ممر أدب الرحلات", "Travel Writing Aisle", 0)
                    )
                )
            )
        ),
        Floor(
            id = "first",
            name = "الدور الأول",
            nameEn = "First Floor",
            order = 1,
            blocks = listOf(
                Block(
                    code = "A",
                    name = "بلوك التنمية الذاتية",
                    nameEn = "Self-Development Block",
                    row = 0,
                    column = 0,
                    aisles = listOf(
                        Aisle("A1", "ممر بناء العادات", "Habit Building Aisle", 0),
                        Aisle("A2", "ممر المهارات الشخصية", "Personal Skills Aisle", 1)
                    )
                ),
                Block(
                    code = "B",
                    name = "بلوك علم النفس",
                    nameEn = "Psychology Block",
                    row = 0,
                    column = 1,
                    aisles = listOf(
                        Aisle("B1", "ممر علم النفس العام", "General Psychology Aisle", 0),
                        Aisle("B2", "ممر علم النفس التطبيقي", "Applied Psychology Aisle", 1)
                    )
                ),
                Block(
                    code = "C",
                    name = "بلوك الإدارة والأعمال",
                    nameEn = "Business & Management Block",
                    row = 1,
                    column = 0,
                    aisles = listOf(
                        Aisle("C1", "ممر الإدارة", "Management Aisle", 0),
                        Aisle("C2", "ممر ريادة الأعمال", "Entrepreneurship Aisle", 1)
                    )
                )
            )
        ),
        Floor(
            id = "second",
            name = "الدور الثاني",
            nameEn = "Second Floor",
            order = 2,
            blocks = listOf(
                Block(
                    code = "A",
                    name = "بلوك العلوم",
                    nameEn = "Science Block",
                    row = 0,
                    column = 0,
                    aisles = listOf(
                        Aisle("A1", "ممر الفيزياء والفلك", "Physics & Astronomy Aisle", 0),
                        Aisle("A2", "ممر الأحياء والطب", "Biology & Medicine Aisle", 1)
                    )
                ),
                Block(
                    code = "B",
                    name = "بلوك التقنية والحاسب",
                    nameEn = "Computing Block",
                    row = 0,
                    column = 1,
                    aisles = listOf(
                        Aisle("B1", "ممر البرمجة", "Programming Aisle", 0),
                        Aisle("B2", "ممر الخوارزميات والذكاء الاصطناعي", "Algorithms & AI Aisle", 1)
                    )
                ),
                Block(
                    code = "C",
                    name = "بلوك الرياضيات",
                    nameEn = "Mathematics Block",
                    row = 1,
                    column = 0,
                    aisles = listOf(
                        Aisle("C1", "ممر الرياضيات", "Mathematics Aisle", 0)
                    )
                ),
                Block(
                    code = "D",
                    name = "بلوك التاريخ",
                    nameEn = "History Block",
                    row = 1,
                    column = 1,
                    aisles = listOf(
                        Aisle("D1", "ممر التاريخ الإسلامي", "Islamic History Aisle", 0),
                        Aisle("D2", "ممر التاريخ الحديث", "Modern History Aisle", 1)
                    )
                )
            )
        ),
        Floor(
            id = "third",
            name = "الدور الثالث",
            nameEn = "Third Floor",
            order = 3,
            blocks = listOf(
                Block(
                    code = "A",
                    name = "بلوك المراجع والموسوعات",
                    nameEn = "Reference Block",
                    row = 0,
                    column = 0,
                    aisles = listOf(
                        Aisle("A1", "ممر الموسوعات", "Encyclopaedias Aisle", 0),
                        Aisle("A2", "ممر المعاجم", "Dictionaries Aisle", 1)
                    )
                ),
                Block(
                    code = "B",
                    name = "بلوك الدين والفلسفة",
                    nameEn = "Religion & Philosophy Block",
                    row = 0,
                    column = 1,
                    aisles = listOf(
                        Aisle("B1", "ممر الدراسات الإسلامية", "Islamic Studies Aisle", 0),
                        Aisle("B2", "ممر الفلسفة", "Philosophy Aisle", 1)
                    )
                ),
                Block(
                    code = "C",
                    name = "بلوك الأطفال والناشئة",
                    nameEn = "Children & Young Adults Block",
                    row = 1,
                    column = 0,
                    aisles = listOf(
                        Aisle("C1", "ممر الأطفال", "Children's Aisle", 0),
                        Aisle("C2", "ممر الناشئة", "Young Adults Aisle", 1)
                    )
                )
            )
        )
    )

    // ---------------------------------------------------------------------
    // Categories
    // ---------------------------------------------------------------------

    val categories = listOf(
        Category("lit", "الأدب والروايات", "book"),
        Category("poetry", "الشعر", "book"),
        Category("self_dev", "التنمية الذاتية", "growth"),
        Category("psychology", "علم النفس", "growth"),
        Category("business", "الإدارة والأعمال", "growth"),
        Category("science", "العلوم", "science"),
        Category("tech", "التقنية والحاسب", "science"),
        Category("history", "التاريخ", "history"),
        Category("geography", "الجغرافيا والرحلات", "history"),
        Category("philosophy", "الدين والفلسفة", "book"),
        Category("kids", "الأطفال والناشئة", "book"),
        Category("reference", "المراجع والموسوعات", "book")
    )

    // ---------------------------------------------------------------------
    // Bookcases — 2 along every aisle, alternating sides
    // ---------------------------------------------------------------------

    val shelves = listOf(
        Shelf(
            id = "sh_g_a1_1",
            code = "G-A1-1",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الروايات العربية",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_a1_2",
            code = "G-A1-2",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الروايات العربية",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_a2_1",
            code = "G-A2-1",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "القصة القصيرة",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_a2_2",
            code = "G-A2-2",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "القصة القصيرة",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_b1_1",
            code = "G-B1-1",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الروايات المترجمة",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_b1_2",
            code = "G-B1-2",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الروايات المترجمة",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_b2_1",
            code = "G-B2-1",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "المسرح",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_b2_2",
            code = "G-B2-2",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "المسرح",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_c1_1",
            code = "G-C1-1",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "C",
            aisle = "C1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الشعر العربي",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_c1_2",
            code = "G-C1-2",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "C",
            aisle = "C1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الشعر العربي",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_d1_1",
            code = "G-D1-1",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "D",
            aisle = "D1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "أدب الرحلات",
            capacity = 120
        ),
        Shelf(
            id = "sh_g_d1_2",
            code = "G-D1-2",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "D",
            aisle = "D1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "أدب الرحلات",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_a1_1",
            code = "1-A1-1",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "بناء العادات",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_a1_2",
            code = "1-A1-2",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "بناء العادات",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_a2_1",
            code = "1-A2-1",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "المهارات الشخصية",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_a2_2",
            code = "1-A2-2",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "المهارات الشخصية",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_b1_1",
            code = "1-B1-1",
            floorId = "first",
            floor = "الدور الأول",
            block = "B",
            aisle = "B1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "علم النفس العام",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_b1_2",
            code = "1-B1-2",
            floorId = "first",
            floor = "الدور الأول",
            block = "B",
            aisle = "B1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "علم النفس العام",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_b2_1",
            code = "1-B2-1",
            floorId = "first",
            floor = "الدور الأول",
            block = "B",
            aisle = "B2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "علم النفس التطبيقي",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_b2_2",
            code = "1-B2-2",
            floorId = "first",
            floor = "الدور الأول",
            block = "B",
            aisle = "B2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "علم النفس التطبيقي",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_c1_1",
            code = "1-C1-1",
            floorId = "first",
            floor = "الدور الأول",
            block = "C",
            aisle = "C1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الإدارة",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_c1_2",
            code = "1-C1-2",
            floorId = "first",
            floor = "الدور الأول",
            block = "C",
            aisle = "C1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الإدارة",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_c2_1",
            code = "1-C2-1",
            floorId = "first",
            floor = "الدور الأول",
            block = "C",
            aisle = "C2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "ريادة الأعمال",
            capacity = 120
        ),
        Shelf(
            id = "sh_1_c2_2",
            code = "1-C2-2",
            floorId = "first",
            floor = "الدور الأول",
            block = "C",
            aisle = "C2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "ريادة الأعمال",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_a1_1",
            code = "2-A1-1",
            floorId = "second",
            floor = "الدور الثاني",
            block = "A",
            aisle = "A1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الفيزياء والفلك",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_a1_2",
            code = "2-A1-2",
            floorId = "second",
            floor = "الدور الثاني",
            block = "A",
            aisle = "A1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الفيزياء والفلك",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_a2_1",
            code = "2-A2-1",
            floorId = "second",
            floor = "الدور الثاني",
            block = "A",
            aisle = "A2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الأحياء والطب",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_a2_2",
            code = "2-A2-2",
            floorId = "second",
            floor = "الدور الثاني",
            block = "A",
            aisle = "A2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الأحياء والطب",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_b1_1",
            code = "2-B1-1",
            floorId = "second",
            floor = "الدور الثاني",
            block = "B",
            aisle = "B1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "البرمجة",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_b1_2",
            code = "2-B1-2",
            floorId = "second",
            floor = "الدور الثاني",
            block = "B",
            aisle = "B1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "البرمجة",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_b2_1",
            code = "2-B2-1",
            floorId = "second",
            floor = "الدور الثاني",
            block = "B",
            aisle = "B2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الخوارزميات والذكاء الاصطناعي",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_b2_2",
            code = "2-B2-2",
            floorId = "second",
            floor = "الدور الثاني",
            block = "B",
            aisle = "B2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الخوارزميات والذكاء الاصطناعي",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_c1_1",
            code = "2-C1-1",
            floorId = "second",
            floor = "الدور الثاني",
            block = "C",
            aisle = "C1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الرياضيات",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_c1_2",
            code = "2-C1-2",
            floorId = "second",
            floor = "الدور الثاني",
            block = "C",
            aisle = "C1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الرياضيات",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_d1_1",
            code = "2-D1-1",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "التاريخ الإسلامي",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_d1_2",
            code = "2-D1-2",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "التاريخ الإسلامي",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_d2_1",
            code = "2-D2-1",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "التاريخ الحديث",
            capacity = 120
        ),
        Shelf(
            id = "sh_2_d2_2",
            code = "2-D2-2",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "التاريخ الحديث",
            capacity = 120
        ),
        Shelf(
            id = "sh_3_a1_1",
            code = "3-A1-1",
            floorId = "third",
            floor = "الدور الثالث",
            block = "A",
            aisle = "A1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الموسوعات",
            capacity = 90
        ),
        Shelf(
            id = "sh_3_a1_2",
            code = "3-A1-2",
            floorId = "third",
            floor = "الدور الثالث",
            block = "A",
            aisle = "A1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الموسوعات",
            capacity = 90
        ),
        Shelf(
            id = "sh_3_a2_1",
            code = "3-A2-1",
            floorId = "third",
            floor = "الدور الثالث",
            block = "A",
            aisle = "A2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "المعاجم",
            capacity = 90
        ),
        Shelf(
            id = "sh_3_a2_2",
            code = "3-A2-2",
            floorId = "third",
            floor = "الدور الثالث",
            block = "A",
            aisle = "A2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "المعاجم",
            capacity = 90
        ),
        Shelf(
            id = "sh_3_b1_1",
            code = "3-B1-1",
            floorId = "third",
            floor = "الدور الثالث",
            block = "B",
            aisle = "B1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الدراسات الإسلامية",
            capacity = 120
        ),
        Shelf(
            id = "sh_3_b1_2",
            code = "3-B1-2",
            floorId = "third",
            floor = "الدور الثالث",
            block = "B",
            aisle = "B1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الدراسات الإسلامية",
            capacity = 120
        ),
        Shelf(
            id = "sh_3_b2_1",
            code = "3-B2-1",
            floorId = "third",
            floor = "الدور الثالث",
            block = "B",
            aisle = "B2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "الفلسفة",
            capacity = 120
        ),
        Shelf(
            id = "sh_3_b2_2",
            code = "3-B2-2",
            floorId = "third",
            floor = "الدور الثالث",
            block = "B",
            aisle = "B2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "الفلسفة",
            capacity = 120
        ),
        Shelf(
            id = "sh_3_c1_1",
            code = "3-C1-1",
            floorId = "third",
            floor = "الدور الثالث",
            block = "C",
            aisle = "C1",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "كتب الأطفال",
            capacity = 120
        ),
        Shelf(
            id = "sh_3_c1_2",
            code = "3-C1-2",
            floorId = "third",
            floor = "الدور الثالث",
            block = "C",
            aisle = "C1",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "كتب الأطفال",
            capacity = 120
        ),
        Shelf(
            id = "sh_3_c2_1",
            code = "3-C2-1",
            floorId = "third",
            floor = "الدور الثالث",
            block = "C",
            aisle = "C2",
            position = 1,
            side = "يمين الممر",
            levels = 3,
            zone = "كتب الناشئة",
            capacity = 120
        ),
        Shelf(
            id = "sh_3_c2_2",
            code = "3-C2-2",
            floorId = "third",
            floor = "الدور الثالث",
            block = "C",
            aisle = "C2",
            position = 2,
            side = "يسار الممر",
            levels = 3,
            zone = "كتب الناشئة",
            capacity = 120
        )
    )

    // ---------------------------------------------------------------------
    // Memberships — the library's own records, not app accounts
    // ---------------------------------------------------------------------

    val members = listOf(
        LibraryUser(
            id = "m01",
            name = "عبدالله محمد الزهراني",
            idNumber = "1098234771",
            status = UserStatus.ACTIVE,
            phone = "0551234567",
            joinDate = "2024-09-14",
            memberType = "طالب"
        ),
        LibraryUser(
            id = "m02",
            name = "نورة سعد القحطاني",
            idNumber = "1077451209",
            status = UserStatus.ACTIVE,
            phone = "0553344221",
            joinDate = "2024-09-21",
            memberType = "طالبة"
        ),
        LibraryUser(
            id = "m03",
            name = "فهد إبراهيم العتيبي",
            idNumber = "1065872340",
            status = UserStatus.ACTIVE,
            phone = "0556677889",
            joinDate = "2024-10-02",
            memberType = "طالب"
        ),
        LibraryUser(
            id = "m04",
            name = "ريم خالد الشمري",
            idNumber = "1043298776",
            status = UserStatus.ACTIVE,
            phone = "0559988776",
            joinDate = "2024-10-11",
            memberType = "طالبة"
        ),
        LibraryUser(
            id = "m05",
            name = "سلطان ناصر الدوسري",
            idNumber = "1032114598",
            status = UserStatus.ACTIVE,
            phone = "0554455667",
            joinDate = "2024-11-05",
            memberType = "طالب"
        ),
        LibraryUser(
            id = "m06",
            name = "مها عبدالرحمن الحربي",
            idNumber = "1021887654",
            status = UserStatus.ACTIVE,
            phone = "0552233445",
            joinDate = "2024-11-19",
            memberType = "طالبة"
        ),
        LibraryUser(
            id = "m07",
            name = "د. سعيد علي الغامدي",
            idNumber = "1010223344",
            status = UserStatus.ACTIVE,
            phone = "0505566778",
            joinDate = "2023-02-08",
            memberType = "عضو هيئة تدريس"
        ),
        LibraryUser(
            id = "m08",
            name = "د. هند فيصل المالكي",
            idNumber = "1009887766",
            status = UserStatus.ACTIVE,
            phone = "0507788990",
            joinDate = "2023-03-17",
            memberType = "عضو هيئة تدريس"
        ),
        LibraryUser(
            id = "m09",
            name = "أ. ماجد تركي السبيعي",
            idNumber = "1008776655",
            status = UserStatus.ACTIVE,
            phone = "0501122334",
            joinDate = "2023-09-01",
            memberType = "عضو هيئة تدريس"
        ),
        LibraryUser(
            id = "m10",
            name = "بندر عوض البقمي",
            idNumber = "1087665544",
            status = UserStatus.ACTIVE,
            phone = "0566778899",
            joinDate = "2023-05-23",
            memberType = "موظف"
        ),
        LibraryUser(
            id = "m11",
            name = "أمل صالح العنزي",
            idNumber = "1086554433",
            status = UserStatus.ACTIVE,
            phone = "0563344556",
            joinDate = "2023-06-14",
            memberType = "موظفة"
        ),
        LibraryUser(
            id = "m12",
            name = "ياسر حمد الرشيدي",
            idNumber = "1085443322",
            status = UserStatus.ACTIVE,
            phone = "0568899001",
            joinDate = "2024-01-09",
            memberType = "موظف"
        ),
        LibraryUser(
            id = "m13",
            name = "لمياء مشعل الجهني",
            idNumber = "1084332211",
            status = UserStatus.ACTIVE,
            phone = "0577788990",
            joinDate = "2025-01-20",
            memberType = "طالبة"
        ),
        LibraryUser(
            id = "m14",
            name = "طلال عايض الشهري",
            idNumber = "1083221100",
            status = UserStatus.ACTIVE,
            phone = "0574455663",
            joinDate = "2025-02-03",
            memberType = "طالب"
        ),
        LibraryUser(
            id = "m15",
            name = "جواهر راشد المطيري",
            idNumber = "1082110099",
            status = UserStatus.ACTIVE,
            phone = "0571122335",
            joinDate = "2025-02-24",
            memberType = "طالبة"
        ),
        LibraryUser(
            id = "m16",
            name = "إبراهيم يوسف باوزير",
            idNumber = "1081009988",
            status = UserStatus.ACTIVE,
            phone = "0598877665",
            joinDate = "2025-03-10",
            memberType = "زائر"
        )
    )

    // ---------------------------------------------------------------------
    // The catalog — 61 titles placed on the bookcases above
    // ---------------------------------------------------------------------

    val books = listOf(
        Book(
            id = "b_thulathiyat",
            title = "ثلاثية غرناطة",
            author = "رضوى عاشور",
            category = "lit",
            coverColor = Catalogs.paletteFor("ثلاثية غرناطة"),
            description = "ثلاثية روائية تتبع أسرة غرناطية عبر ثلاثة أجيال بعد سقوط الأندلس.",
            tags = listOf("أدب", "رواية", "تاريخ"),
            shelf = "G-A1-1",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            serial = "WJ-0001",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_mawsim",
            title = "موسم الهجرة إلى الشمال",
            author = "الطيب صالح",
            category = "lit",
            coverColor = Catalogs.paletteFor("موسم الهجرة إلى الشمال"),
            description = "رواية سودانية عن الصدام بين الشرق والغرب في حياة رجل عائد من أوروبا.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-A1-2",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            serial = "WJ-0002",
            dateAdded = "2025-07-15",
            copies = 3,
            onLoan = 1
        ),
        Book(
            id = "b_dhakirat",
            title = "ذاكرة الجسد",
            author = "أحلام مستغانمي",
            category = "lit",
            coverColor = Catalogs.paletteFor("ذاكرة الجسد"),
            description = "رواية جزائرية عن الحب والذاكرة والوطن، برواية رسّام فقد ذراعه في الثورة.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-A1-1",
            section = "الرف الأوسط",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            serial = "WJ-0003",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_azazeel",
            title = "عزازيل",
            author = "يوسف زيدان",
            category = "lit",
            coverColor = Catalogs.paletteFor("عزازيل"),
            description = "رواية عن راهب مصري في القرن الخامس الميلادي، تقرأ الصراع الديني من داخله.",
            tags = listOf("أدب", "رواية", "تاريخ"),
            shelf = "G-A1-2",
            section = "الرف الأوسط",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            serial = "WJ-0004",
            dateAdded = "2025-01-01",
            copies = 1,
            onLoan = 1,
            status = BookStatus.BORROWED
        ),
        Book(
            id = "b_rijal",
            title = "رجال في الشمس",
            author = "غسان كنفاني",
            category = "lit",
            coverColor = Catalogs.paletteFor("رجال في الشمس"),
            description = "رواية قصيرة عن ثلاثة فلسطينيين يحاولون العبور إلى الكويت في خزان شاحنة.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-A2-1",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A2",
            serial = "WJ-0005",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_mudun",
            title = "مدن الملح",
            author = "عبد الرحمن منيف",
            category = "lit",
            coverColor = Catalogs.paletteFor("مدن الملح"),
            description = "عمل روائي ضخم عن أثر اكتشاف النفط على مجتمع الجزيرة العربية.",
            tags = listOf("أدب", "رواية", "تاريخ"),
            shelf = "G-A1-1",
            section = "الرف السفلي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            serial = "WJ-0006",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_khubz",
            title = "الخبز الحافي",
            author = "محمد شكري",
            category = "lit",
            coverColor = Catalogs.paletteFor("الخبز الحافي"),
            description = "سيرة ذاتية صريحة عن طفولة قاسية في المغرب، وعن تعلّم القراءة متأخراً.",
            tags = listOf("أدب", "سيرة ذاتية"),
            shelf = "G-A2-2",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A2",
            serial = "WJ-0007",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_saq",
            title = "ساق البامبو",
            author = "سعود السنعوسي",
            category = "lit",
            coverColor = Catalogs.paletteFor("ساق البامبو"),
            description = "رواية كويتية عن شاب نصف فلبيني يبحث عن مكانه بين عائلتين ووطنين.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-A1-2",
            section = "الرف السفلي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            serial = "WJ-0008",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_awlad",
            title = "أولاد حارتنا",
            author = "نجيب محفوظ",
            category = "lit",
            coverColor = Catalogs.paletteFor("أولاد حارتنا"),
            description = "رواية رمزية تعيد سرد حكاية الحارة كأنها تاريخ البشرية.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-A1-1",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A1",
            serial = "WJ-0009",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_zuqaq",
            title = "زقاق المدق",
            author = "نجيب محفوظ",
            category = "lit",
            coverColor = Catalogs.paletteFor("زقاق المدق"),
            description = "صورة لحارة قاهرية صغيرة وسكانها في سنوات الحرب العالمية الثانية.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-A2-1",
            section = "الرف الأوسط",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "A",
            aisle = "A2",
            serial = "WJ-0010",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_mi2at",
            title = "مئة عام من العزلة",
            author = "غابرييل غارسيا ماركيز",
            category = "lit",
            coverColor = Catalogs.paletteFor("مئة عام من العزلة"),
            description = "ملحمة عائلة بوينديا في قرية ماكوندو، والعمل الأشهر في الواقعية السحرية.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-B1-1",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B1",
            serial = "WJ-0011",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_jarima",
            title = "الجريمة والعقاب",
            author = "فيودور دوستويفسكي",
            category = "lit",
            coverColor = Catalogs.paletteFor("الجريمة والعقاب"),
            description = "طالب فقير يرتكب جريمة ثم يعيش محاكمته الداخلية قبل محاكمة القانون.",
            tags = listOf("أدب", "رواية", "علم النفس"),
            shelf = "G-B1-2",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B1",
            serial = "WJ-0012",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_ajouz",
            title = "الشيخ والبحر",
            author = "إرنست همنغواي",
            category = "lit",
            coverColor = Catalogs.paletteFor("الشيخ والبحر"),
            description = "صياد عجوز يصارع سمكة ضخمة في عرض البحر، وحيداً وبلا شهود.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-B1-1",
            section = "الرف الأوسط",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B1",
            serial = "WJ-0013",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_1984",
            title = "1984",
            author = "جورج أورويل",
            category = "lit",
            coverColor = Catalogs.paletteFor("1984"),
            description = "رواية عن دولة شمولية تراقب كل شيء، بما في ذلك ما يفكر فيه الناس.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-B1-2",
            section = "الرف الأوسط",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B1",
            serial = "WJ-0014",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_mazraa",
            title = "مزرعة الحيوان",
            author = "جورج أورويل",
            category = "lit",
            coverColor = Catalogs.paletteFor("مزرعة الحيوان"),
            description = "حكاية رمزية قصيرة عن ثورة حيوانات المزرعة وما آلت إليه.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-B2-1",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B2",
            serial = "WJ-0015",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_amir_sagheer",
            title = "الأمير الصغير",
            author = "أنطوان دو سانت إكزوبيري",
            category = "kids",
            coverColor = Catalogs.paletteFor("الأمير الصغير"),
            description = "حكاية طيّار وأمير صغير قادم من كوكب آخر، تُقرأ في كل عمر.",
            tags = listOf("أدب", "رواية"),
            shelf = "G-B2-2",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "B",
            aisle = "B2",
            serial = "WJ-0016",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_mutanabbi",
            title = "ديوان المتنبي",
            author = "أبو الطيب المتنبي",
            category = "poetry",
            coverColor = Catalogs.paletteFor("ديوان المتنبي"),
            description = "ديوان أشهر شعراء العربية، في المديح والحكمة والفخر.",
            tags = listOf("شعر", "أدب"),
            shelf = "G-C1-1",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "C",
            aisle = "C1",
            serial = "WJ-0017",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_shawqi",
            title = "الشوقيات",
            author = "أحمد شوقي",
            category = "poetry",
            coverColor = Catalogs.paletteFor("الشوقيات"),
            description = "ديوان أمير الشعراء، جامعاً قصائده في الوطن والتاريخ والوجدان.",
            tags = listOf("شعر", "أدب"),
            shelf = "G-C1-2",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "C",
            aisle = "C1",
            serial = "WJ-0018",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_darwish",
            title = "لا تعتذر عمّا فعلت",
            author = "محمود درويش",
            category = "poetry",
            coverColor = Catalogs.paletteFor("لا تعتذر عمّا فعلت"),
            description = "مجموعة شعرية متأخرة لمحمود درويش، أهدأ نبرة وأكثر تأملاً.",
            tags = listOf("شعر", "أدب"),
            shelf = "G-C1-1",
            section = "الرف الأوسط",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "C",
            aisle = "C1",
            serial = "WJ-0019",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_qabbani",
            title = "قالت لي السمراء",
            author = "نزار قباني",
            category = "poetry",
            coverColor = Catalogs.paletteFor("قالت لي السمراء"),
            description = "الديوان الأول لنزار قباني، الذي فتح باب اللغة اليومية على الشعر.",
            tags = listOf("شعر", "أدب"),
            shelf = "G-C1-2",
            section = "الرف الأوسط",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "C",
            aisle = "C1",
            serial = "WJ-0020",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_ibnbattuta",
            title = "رحلة ابن بطوطة",
            author = "ابن بطوطة",
            category = "geography",
            coverColor = Catalogs.paletteFor("رحلة ابن بطوطة"),
            description = "تحفة النظّار: سجل رحلة امتدت ثلاثين عاماً عبر ثلاث قارات.",
            tags = listOf("تاريخ", "سيرة ذاتية"),
            shelf = "G-D1-1",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "D",
            aisle = "D1",
            serial = "WJ-0021",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_muajam_buldan",
            title = "معجم البلدان",
            author = "ياقوت الحموي",
            category = "geography",
            coverColor = Catalogs.paletteFor("معجم البلدان"),
            description = "معجم جغرافي كلاسيكي يصف المدن والمواضع بأسمائها وأخبارها.",
            tags = listOf("تاريخ"),
            shelf = "G-D1-2",
            section = "الرف العلوي",
            floorId = "ground",
            floor = "الدور الأرضي",
            block = "D",
            aisle = "D1",
            serial = "WJ-0022",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_atomic",
            title = "العادات الذرية",
            author = "جيمس كلير",
            category = "self_dev",
            coverColor = Catalogs.paletteFor("العادات الذرية"),
            description = "كيف تتراكم التغييرات الصغيرة حتى تصير نتائج كبيرة، ونظام عملي لبنائها.",
            tags = listOf("تطوير الذات", "العادات"),
            shelf = "1-A1-1",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A1",
            serial = "WJ-0023",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_seven",
            title = "العادات السبع للناس الأكثر فعالية",
            author = "ستيفن كوفي",
            category = "self_dev",
            coverColor = Catalogs.paletteFor("العادات السبع للناس الأكثر فعالية"),
            description = "إطار من سبع عادات يبدأ من المبادرة الشخصية وينتهي بالتجديد المستمر.",
            tags = listOf("تطوير الذات", "العادات", "إدارة"),
            shelf = "1-A1-2",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A1",
            serial = "WJ-0024",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_power_habit",
            title = "قوة العادات",
            author = "تشارلز دوهيج",
            category = "self_dev",
            coverColor = Catalogs.paletteFor("قوة العادات"),
            description = "كيف تتكوّن العادات في الدماغ، وكيف يمكن تغييرها عند الأفراد والمؤسسات.",
            tags = listOf("تطوير الذات", "العادات", "علم النفس"),
            shelf = "1-A1-1",
            section = "الرف الأوسط",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A1",
            serial = "WJ-0025",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_subtle",
            title = "فن اللامبالاة",
            author = "مارك مانسون",
            category = "self_dev",
            coverColor = Catalogs.paletteFor("فن اللامبالاة"),
            description = "دعوة لاختيار ما يستحق الاهتمام فعلاً، بدل محاولة الاهتمام بكل شيء.",
            tags = listOf("تطوير الذات"),
            shelf = "1-A2-1",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A2",
            serial = "WJ-0026",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_why",
            title = "ابدأ بالسؤال لماذا",
            author = "سايمون سينك",
            category = "self_dev",
            coverColor = Catalogs.paletteFor("ابدأ بالسؤال لماذا"),
            description = "لماذا تُلهم بعض المؤسسات والقادة غيرهم، بينما يفشل من يملك الموارد نفسها.",
            tags = listOf("تطوير الذات", "إدارة"),
            shelf = "1-A2-2",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "A",
            aisle = "A2",
            serial = "WJ-0027",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_thinking",
            title = "التفكير السريع والبطيء",
            author = "دانيال كانمان",
            category = "psychology",
            coverColor = Catalogs.paletteFor("التفكير السريع والبطيء"),
            description = "نظامان يحكمان تفكيرنا: واحد سريع حدسي، وآخر بطيء تحليلي، وأين يخطئ كل منهما.",
            tags = listOf("علم النفس", "تطوير الذات"),
            shelf = "1-B1-1",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "B",
            aisle = "B1",
            serial = "WJ-0028",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_meaning",
            title = "الإنسان يبحث عن المعنى",
            author = "فيكتور فرانكل",
            category = "psychology",
            coverColor = Catalogs.paletteFor("الإنسان يبحث عن المعنى"),
            description = "طبيب نفسي يروي تجربته في معسكرات الاعتقال، ويبني عليها علاجاً يقوم على المعنى.",
            tags = listOf("علم النفس", "سيرة ذاتية"),
            shelf = "1-B1-2",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "B",
            aisle = "B1",
            serial = "WJ-0029",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_eq",
            title = "الذكاء العاطفي",
            author = "دانيال جولمان",
            category = "psychology",
            coverColor = Catalogs.paletteFor("الذكاء العاطفي"),
            description = "لماذا تتفوق القدرة على فهم المشاعر وإدارتها على معامل الذكاء وحده.",
            tags = listOf("علم النفس", "تطوير الذات"),
            shelf = "1-B2-1",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "B",
            aisle = "B2",
            serial = "WJ-0030",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_idiot_brain",
            title = "المخ الأبله",
            author = "دين برنيت",
            category = "psychology",
            coverColor = Catalogs.paletteFor("المخ الأبله"),
            description = "جولة طريفة في أخطاء الدماغ اليومية، من الذاكرة المشوّشة إلى دوار السفر.",
            tags = listOf("علم النفس", "علوم"),
            shelf = "1-B2-2",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "B",
            aisle = "B2",
            serial = "WJ-0031",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_good_great",
            title = "من جيد إلى عظيم",
            author = "جيم كولينز",
            category = "business",
            coverColor = Catalogs.paletteFor("من جيد إلى عظيم"),
            description = "دراسة لشركات قفزت من الأداء المتوسط إلى التفوق الطويل، وما الذي جمع بينها.",
            tags = listOf("إدارة"),
            shelf = "1-C1-1",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "C",
            aisle = "C1",
            serial = "WJ-0032",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_rich_dad",
            title = "الأب الغني والأب الفقير",
            author = "روبرت كيوساكي",
            category = "business",
            coverColor = Catalogs.paletteFor("الأب الغني والأب الفقير"),
            description = "مقارنة بين طريقتين في التفكير بالمال، من خلال أبوين مختلفين.",
            tags = listOf("إدارة", "تطوير الذات"),
            shelf = "1-C2-1",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "C",
            aisle = "C2",
            serial = "WJ-0033",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_black_swan",
            title = "البجعة السوداء",
            author = "نسيم نيكولاس طالب",
            category = "business",
            coverColor = Catalogs.paletteFor("البجعة السوداء"),
            description = "عن الأحداث النادرة شديدة الأثر، ولماذا نصرّ على تفسيرها بعد وقوعها فقط.",
            tags = listOf("إدارة", "علوم"),
            shelf = "1-C1-2",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "C",
            aisle = "C1",
            serial = "WJ-0034",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_blue_ocean",
            title = "استراتيجية المحيط الأزرق",
            author = "دبليو تشان كيم ورينيه موبورن",
            category = "business",
            coverColor = Catalogs.paletteFor("استراتيجية المحيط الأزرق"),
            description = "كيف تصنع سوقاً جديدة بدل أن تتنافس حتى الإنهاك في سوق قائمة.",
            tags = listOf("إدارة"),
            shelf = "1-C2-2",
            section = "الرف العلوي",
            floorId = "first",
            floor = "الدور الأول",
            block = "C",
            aisle = "C2",
            serial = "WJ-0035",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_brief_time",
            title = "تاريخ موجز للزمن",
            author = "ستيفن هوكينج",
            category = "science",
            coverColor = Catalogs.paletteFor("تاريخ موجز للزمن"),
            description = "شرح للزمن والكون والثقوب السوداء لقارئ غير متخصص.",
            tags = listOf("علوم"),
            shelf = "2-A1-1",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "A",
            aisle = "A1",
            serial = "WJ-0036",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_cosmos",
            title = "الكون",
            author = "كارل ساغان",
            category = "science",
            coverColor = Catalogs.paletteFor("الكون"),
            description = "رحلة في تاريخ الكون والعلم، بلغة كاتب يرى في الفضول أصل المعرفة.",
            tags = listOf("علوم"),
            shelf = "2-A1-2",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "A",
            aisle = "A1",
            serial = "WJ-0037",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_gene",
            title = "الجين: تاريخ حميم",
            author = "سيدهارتا موكرجي",
            category = "science",
            coverColor = Catalogs.paletteFor("الجين: تاريخ حميم"),
            description = "تاريخ فكرة الوراثة، من البازلاء إلى تحرير الجينوم، ممزوجاً بقصة عائلة.",
            tags = listOf("علوم"),
            shelf = "2-A2-1",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "A",
            aisle = "A2",
            serial = "WJ-0038",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_origin",
            title = "أصل الأنواع",
            author = "تشارلز داروين",
            category = "science",
            coverColor = Catalogs.paletteFor("أصل الأنواع"),
            description = "العمل الذي أسّس لنظرية التطور بالانتخاب الطبيعي.",
            tags = listOf("علوم", "تاريخ"),
            shelf = "2-A2-2",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "A",
            aisle = "A2",
            serial = "WJ-0039",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_clean_code",
            title = "الكود النظيف",
            author = "روبرت مارتن",
            category = "tech",
            coverColor = Catalogs.paletteFor("الكود النظيف"),
            description = "قواعد عملية لكتابة شيفرة يفهمها غيرك بعد سنة، بأمثلة قبل وبعد.",
            tags = listOf("تقنية"),
            shelf = "2-B1-1",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "B",
            aisle = "B1",
            serial = "WJ-0040",
            dateAdded = "2025-01-01",
            copies = 1,
            onLoan = 1,
            status = BookStatus.BORROWED
        ),
        Book(
            id = "b_pragmatic",
            title = "المبرمج البارع",
            author = "أندرو هنت وديفيد توماس",
            category = "tech",
            coverColor = Catalogs.paletteFor("المبرمج البارع"),
            description = "عادات مهنية للمبرمج، من أدوات العمل اليومي إلى التعامل مع التغيير.",
            tags = listOf("تقنية"),
            shelf = "2-B1-2",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "B",
            aisle = "B1",
            serial = "WJ-0041",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_clrs",
            title = "مقدمة في الخوارزميات",
            author = "توماس كورمن وزملاؤه",
            category = "tech",
            coverColor = Catalogs.paletteFor("مقدمة في الخوارزميات"),
            description = "المرجع الجامعي الأشهر في تصميم الخوارزميات وتحليل تعقيدها.",
            tags = listOf("تقنية"),
            shelf = "2-B2-1",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "B",
            aisle = "B2",
            serial = "WJ-0042",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_aima",
            title = "الذكاء الاصطناعي: مقاربة حديثة",
            author = "ستيوارت راسل وبيتر نورفيغ",
            category = "tech",
            coverColor = Catalogs.paletteFor("الذكاء الاصطناعي: مقاربة حديثة"),
            description = "المرجع الأوسع انتشاراً في الذكاء الاصطناعي، من البحث إلى التعلّم الآلي.",
            tags = listOf("تقنية", "علوم"),
            shelf = "2-B2-2",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "B",
            aisle = "B2",
            serial = "WJ-0043",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_joy_x",
            title = "متعة الرياضيات",
            author = "ستيفن ستروغاتز",
            category = "science",
            coverColor = Catalogs.paletteFor("متعة الرياضيات"),
            description = "جولة في الرياضيات من العدّ إلى التفاضل، لقارئ يظن أنه لا يحبها.",
            tags = listOf("علوم"),
            shelf = "2-C1-1",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "C",
            aisle = "C1",
            serial = "WJ-0044",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_golden_ratio",
            title = "النسبة الذهبية",
            author = "ماريو ليفيو",
            category = "science",
            coverColor = Catalogs.paletteFor("النسبة الذهبية"),
            description = "سيرة الرقم φ في الرياضيات والفن، وأين انتهت الأسطورة وبدأت الحقيقة.",
            tags = listOf("علوم", "تاريخ"),
            shelf = "2-C1-2",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "C",
            aisle = "C1",
            serial = "WJ-0045",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_muqaddima",
            title = "مقدمة ابن خلدون",
            author = "ابن خلدون",
            category = "history",
            coverColor = Catalogs.paletteFor("مقدمة ابن خلدون"),
            description = "مقدمة كتاب العِبر، وأول محاولة منهجية لتفسير قيام الدول وسقوطها.",
            tags = listOf("تاريخ", "فلسفة"),
            shelf = "2-D1-1",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D1",
            serial = "WJ-0046",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_iqd",
            title = "العقد الفريد",
            author = "ابن عبد ربه",
            category = "history",
            coverColor = Catalogs.paletteFor("العقد الفريد"),
            description = "موسوعة أدبية أندلسية تجمع الأخبار والأشعار في أبواب مرتبة.",
            tags = listOf("تاريخ", "أدب"),
            shelf = "2-D1-2",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D1",
            serial = "WJ-0047",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_hadara",
            title = "قصة الحضارة",
            author = "ويل ديورانت",
            category = "history",
            coverColor = Catalogs.paletteFor("قصة الحضارة"),
            description = "تاريخ عام للحضارات من الشرق القديم إلى العصر الحديث، في أجزاء متتابعة.",
            tags = listOf("تاريخ"),
            shelf = "2-D2-1",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D2",
            serial = "WJ-0048",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_othman",
            title = "تاريخ الدولة العثمانية",
            author = "يلماز أوزتونا",
            category = "history",
            coverColor = Catalogs.paletteFor("تاريخ الدولة العثمانية"),
            description = "عرض متصل لتاريخ الدولة العثمانية من النشأة إلى نهايتها.",
            tags = listOf("تاريخ"),
            shelf = "2-D2-2",
            section = "الرف العلوي",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D2",
            serial = "WJ-0049",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_orientalism",
            title = "الاستشراق",
            author = "إدوارد سعيد",
            category = "history",
            coverColor = Catalogs.paletteFor("الاستشراق"),
            description = "كيف صاغ الغرب صورة الشرق، ولماذا لم تكن تلك الصورة بريئة.",
            tags = listOf("تاريخ", "فلسفة"),
            shelf = "2-D2-1",
            section = "الرف الأوسط",
            floorId = "second",
            floor = "الدور الثاني",
            block = "D",
            aisle = "D2",
            serial = "WJ-0050",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_lisan",
            title = "لسان العرب",
            author = "ابن منظور",
            category = "reference",
            coverColor = Catalogs.paletteFor("لسان العرب"),
            description = "أشهر معاجم العربية وأوسعها، مرتّب على أواخر الحروف.",
            tags = listOf("مراجع"),
            shelf = "3-A2-1",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "A",
            aisle = "A2",
            serial = "WJ-0051",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_waseet",
            title = "المعجم الوسيط",
            author = "مجمع اللغة العربية بالقاهرة",
            category = "reference",
            coverColor = Catalogs.paletteFor("المعجم الوسيط"),
            description = "معجم عصري متوسط الحجم، وضعه مجمع اللغة العربية للاستعمال اليومي.",
            tags = listOf("مراجع"),
            shelf = "3-A2-2",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "A",
            aisle = "A2",
            serial = "WJ-0052",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_mawsuaa",
            title = "الموسوعة العربية العالمية",
            author = "مجموعة مؤلفين",
            category = "reference",
            coverColor = Catalogs.paletteFor("الموسوعة العربية العالمية"),
            description = "موسوعة عامة بالعربية تغطي العلوم والتاريخ والجغرافيا في مجلدات.",
            tags = listOf("مراجع"),
            shelf = "3-A1-1",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "A",
            aisle = "A1",
            serial = "WJ-0053",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_ihya",
            title = "إحياء علوم الدين",
            author = "أبو حامد الغزالي",
            category = "philosophy",
            coverColor = Catalogs.paletteFor("إحياء علوم الدين"),
            description = "أشهر كتب الغزالي، يجمع الفقه والأخلاق والتصوف في أربعة أرباع.",
            tags = listOf("فلسفة", "تاريخ"),
            shelf = "3-B1-1",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "B",
            aisle = "B1",
            serial = "WJ-0054",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_tahafut",
            title = "تهافت الفلاسفة",
            author = "أبو حامد الغزالي",
            category = "philosophy",
            coverColor = Catalogs.paletteFor("تهافت الفلاسفة"),
            description = "نقد الغزالي لمسائل الفلاسفة، وأحد أهم نصوص الجدل الفلسفي الإسلامي.",
            tags = listOf("فلسفة"),
            shelf = "3-B2-1",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "B",
            aisle = "B2",
            serial = "WJ-0055",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_sophie",
            title = "عالم صوفي",
            author = "جوستاين غاردر",
            category = "philosophy",
            coverColor = Catalogs.paletteFor("عالم صوفي"),
            description = "رواية تعلّم تاريخ الفلسفة من خلال فتاة تتلقى رسائل غامضة.",
            tags = listOf("فلسفة", "رواية"),
            shelf = "3-B2-2",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "B",
            aisle = "B2",
            serial = "WJ-0056",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_russell",
            title = "تاريخ الفلسفة الغربية",
            author = "برتراند راسل",
            category = "philosophy",
            coverColor = Catalogs.paletteFor("تاريخ الفلسفة الغربية"),
            description = "عرض راسل لتاريخ الفلسفة من اليونان إلى القرن العشرين، بصوته ورأيه.",
            tags = listOf("فلسفة", "تاريخ"),
            shelf = "3-B2-1",
            section = "الرف الأوسط",
            floorId = "third",
            floor = "الدور الثالث",
            block = "B",
            aisle = "B2",
            serial = "WJ-0057",
            dateAdded = "2025-04-08",
            copies = 2
        ),
        Book(
            id = "b_kalila",
            title = "كليلة ودمنة",
            author = "ابن المقفع",
            category = "kids",
            coverColor = Catalogs.paletteFor("كليلة ودمنة"),
            description = "حكايات على ألسنة الحيوانات، نقلها ابن المقفع إلى العربية عن الفارسية.",
            tags = listOf("أدب", "رواية"),
            shelf = "3-C1-1",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "C",
            aisle = "C1",
            serial = "WJ-0058",
            dateAdded = "2025-07-15",
            copies = 3
        ),
        Book(
            id = "b_kilani",
            title = "حكايات كامل كيلاني",
            author = "كامل كيلاني",
            category = "kids",
            coverColor = Catalogs.paletteFor("حكايات كامل كيلاني"),
            description = "مجموعة من حكايات رائد أدب الطفل العربي، مكتوبة بلغة سهلة.",
            tags = listOf("أدب", "رواية"),
            shelf = "3-C1-2",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "C",
            aisle = "C1",
            serial = "WJ-0059",
            dateAdded = "2025-10-22",
            copies = 4
        ),
        Book(
            id = "b_matilda",
            title = "ماتيلدا",
            author = "رولد دال",
            category = "kids",
            coverColor = Catalogs.paletteFor("ماتيلدا"),
            description = "طفلة شديدة الذكاء تواجه عائلة ومدرسة لا تفهمانها.",
            tags = listOf("أدب", "رواية"),
            shelf = "3-C2-1",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "C",
            aisle = "C2",
            serial = "WJ-0060",
            dateAdded = "2025-01-01",
            copies = 1
        ),
        Book(
            id = "b_harry1",
            title = "هاري بوتر وحجر الفيلسوف",
            author = "ج. ك. رولينج",
            category = "kids",
            coverColor = Catalogs.paletteFor("هاري بوتر وحجر الفيلسوف"),
            description = "الجزء الأول من سلسلة هاري بوتر، ودخوله مدرسة هوجورتس للسحر.",
            tags = listOf("أدب", "رواية"),
            shelf = "3-C2-2",
            section = "الرف العلوي",
            floorId = "third",
            floor = "الدور الثالث",
            block = "C",
            aisle = "C2",
            serial = "WJ-0061",
            dateAdded = "2025-04-08",
            copies = 2
        )
    )
    // ---------------------------------------------------------------------
    // Borrowing: five loans, one for every state a librarian will meet
    // ---------------------------------------------------------------------

    /**
     * The starter loans.
     *
     * Between them they cover the whole cycle as it actually looks on a
     * Sunday morning: a request from the app waiting to be reviewed, a copy
     * held for someone to collect, a loan running normally, a loan that is
     * late, and one already back on the shelf.
     *
     * Dates are computed from the moment the library is first opened rather
     * than written here. A seeded "six days overdue" has to still be six
     * days overdue whenever the project is demonstrated, and a fixed date
     * would have gone stale long before that — the demo would open on a pile
     * of loans overdue by a year.
     *
     * The first request deliberately carries **no** member id, only the ID
     * number typed into the app. That is what a real request looks like, and
     * approving it is what matches it to نورة's membership — or registers a
     * membership for somebody the library has never seen.
     *
     * The three copies these take off the shelf are the same three marked
     * `onLoan = 1` in [books]. The two lists have to agree: at runtime that
     * is what the loan transactions guarantee, and here it is kept by hand
     * because the seed writes the loan and the book in one pass.
     */
    fun sampleLoans(): List<Loan> {
        val now = System.currentTimeMillis()
        fun daysAgo(days: Int): Long = now - days * DAY_MILLIS

        return listOf(
            // Came in from the app last night; nobody has looked at it yet.
            Loan(
                id = "l01",
                bookId = "b_atomic",
                bookTitle = "العادات الذرية",
                bookSerial = "WJ-0023",
                bookShelf = "1-A1-1",
                memberName = "نورة سعد القحطاني",
                memberIdNumber = "1077451209",
                memberPhone = "0553344221",
                status = LoanStatus.REQUESTED,
                channel = LoanChannel.APP,
                requestedAt = daysAgo(1)
            ),
            // Approved yesterday: a copy is being held at the desk.
            Loan(
                id = "l02",
                bookId = "b_mawsim",
                bookTitle = "موسم الهجرة إلى الشمال",
                bookSerial = "WJ-0002",
                bookShelf = "G-A1-2",
                memberId = "m05",
                memberName = "سلطان ناصر الدوسري",
                memberIdNumber = "1032114598",
                memberPhone = "0554455667",
                status = LoanStatus.APPROVED,
                channel = LoanChannel.APP,
                idVerified = true,
                idVerifiedBy = "أمين المكتبة",
                requestedAt = daysAgo(3),
                decidedAt = daysAgo(1),
                decidedBy = "أمين المكتبة"
            ),
            // Running normally, and the borrower has asked for more time.
            Loan(
                id = "l03",
                bookId = "b_clean_code",
                bookTitle = "الكود النظيف",
                bookSerial = "WJ-0040",
                bookShelf = "2-B1-1",
                memberId = "m07",
                memberName = "د. سعيد علي الغامدي",
                memberIdNumber = "1010223344",
                memberPhone = "0505566778",
                status = LoanStatus.ACTIVE,
                channel = LoanChannel.DESK,
                idVerified = true,
                idVerifiedBy = "أمين المكتبة",
                requestedAt = daysAgo(5),
                decidedAt = daysAgo(5),
                issuedAt = daysAgo(5),
                dueAt = LoanDates.dueDate(9, now),
                renewRequested = true,
                decidedBy = "أمين المكتبة",
                issuedBy = "أمين المكتبة"
            ),
            // Six days past its due date — what the متأخرة filter is for.
            Loan(
                id = "l04",
                bookId = "b_azazeel",
                bookTitle = "عزازيل",
                bookSerial = "WJ-0004",
                bookShelf = "G-A1-2",
                memberId = "m03",
                memberName = "فهد إبراهيم العتيبي",
                memberIdNumber = "1065872340",
                memberPhone = "0556677889",
                status = LoanStatus.ACTIVE,
                channel = LoanChannel.DESK,
                idVerified = true,
                idVerifiedBy = "أمين المكتبة",
                requestedAt = daysAgo(20),
                decidedAt = daysAgo(20),
                issuedAt = daysAgo(20),
                dueAt = LoanDates.dueDate(-6, now),
                decidedBy = "أمين المكتبة",
                issuedBy = "أمين المكتبة"
            ),
            // Closed, and in the history where the reports count it.
            Loan(
                id = "l05",
                bookId = "b_matilda",
                bookTitle = "ماتيلدا",
                bookSerial = "WJ-0060",
                bookShelf = "3-C2-1",
                memberId = "m01",
                memberName = "عبدالله محمد الزهراني",
                memberIdNumber = "1098234771",
                memberPhone = "0551234567",
                status = LoanStatus.RETURNED,
                channel = LoanChannel.DESK,
                idVerified = true,
                idVerifiedBy = "أمين المكتبة",
                requestedAt = daysAgo(40),
                decidedAt = daysAgo(40),
                issuedAt = daysAgo(40),
                dueAt = LoanDates.dueDate(-26, now),
                returnedAt = daysAgo(30),
                decidedBy = "أمين المكتبة",
                issuedBy = "أمين المكتبة",
                returnedBy = "أمين المكتبة"
            )
        )
    }

    private const val DAY_MILLIS = 24L * 60L * 60L * 1000L
}

package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.model.Book
import com.wujha.admin.data.model.BookStatus
import com.wujha.admin.data.repository.DataStatus
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.BookCover
import com.wujha.admin.ui.components.BookStatusBadge
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.ErrorView
import com.wujha.admin.ui.components.FilterChip
import com.wujha.admin.ui.components.LoadingView
import com.wujha.admin.ui.components.SearchField
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackground
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

private enum class BookFilter(val label: String) {
    ALL("الكل"), AVAILABLE("متوفر"), BORROWED("مستعار"), LOST("مفقود")
}

@Composable
fun ManageBooksScreen(
    repository: LibraryRepository,
    onBookClick: (String) -> Unit,
    onAddBook: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(BookFilter.ALL) }

    val allBooks by repository.books.collectAsState()
    val categories by repository.categories.collectAsState()
    val status by repository.status.collectAsState()

    val categoryNames = remember(categories) { categories.associate { it.id to it.name } }

    val filtered = remember(query, filter, allBooks) {
        allBooks
            .filter {
                query.isBlank() || it.title.contains(query, true) ||
                    it.author.contains(query, true) || it.serial.contains(query, true)
            }
            .filter {
                when (filter) {
                    BookFilter.ALL -> true
                    BookFilter.AVAILABLE -> it.status == BookStatus.AVAILABLE
                    BookFilter.BORROWED -> it.status == BookStatus.BORROWED
                    BookFilter.LOST -> it.status == BookStatus.LOST
                }
            }
    }

    if (status is DataStatus.Error) {
        ErrorView(
            message = (status as DataStatus.Error).message,
            modifier = Modifier.background(CreamBackground)
        )
        return
    }
    if (status is DataStatus.Loading && allBooks.isEmpty()) {
        LoadingView(message = t("جارٍ تحميل الفهرس..."), modifier = Modifier.background(CreamBackground))
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = t("إدارة الكتب"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = t("%s عنوان").format(allBooks.size),
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Surface(onClick = onAddBook, shape = RoundedCornerShape(10.dp), color = ForestGreen) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Add,
                            contentDescription = null,
                            tint = SurfaceWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(t("إضافة"), color = SurfaceWhite, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        if (allBooks.isEmpty()) {
            item {
                EmptyView(
                    icon = Icons.Outlined.LibraryBooks,
                    title = t("الفهرس فارغ"),
                    detail = t("أضف أول كتاب، أو أدخل بيانات أولية من الإعدادات لتجربة التطبيق."),
                    actionLabel = t("إضافة كتاب"),
                    onAction = onAddBook
                )
            }
            return@LazyColumn
        }

        item {
            SearchField(
                value = query,
                onValueChange = { query = it },
                placeholder = t("ابحث بالعنوان أو المؤلف أو الرقم التسلسلي..."),
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BookFilter.entries.forEach { f ->
                    FilterChip(label = t(f.label), selected = filter == f, onClick = { filter = f })
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (filtered.isEmpty()) {
            item {
                Text(
                    text = t("لا توجد كتب مطابقة لهذا البحث أو التصنيف."),
                    color = TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().padding(32.dp)
                )
            }
        }

        items(filtered) { book ->
            BookRow(
                book = book,
                categoryName = categoryNames[book.category] ?: book.category,
                onClick = { onBookClick(book.id) }
            )
        }
    }
}

@Composable
private fun BookRow(book: Book, categoryName: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            BookCover(
                title = book.title,
                colorHex = book.coverColor,
                coverBase64 = book.coverBase64,
                modifier = Modifier.width(44.dp).aspectRatio(0.72f)
            )
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    book.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    book.author,
                    fontSize = 12.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                    Surface(shape = RoundedCornerShape(6.dp), color = ForestGreen.copy(alpha = 0.08f)) {
                        Text(
                            text = categoryName.ifBlank { t("غير مصنّف") },
                            fontSize = 10.sp,
                            color = ForestGreen,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (book.shelf.isBlank()) t("بلا رف") else t("الرف %s").format(book.shelf),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                BookStatusBadge(status = book.status)
                Spacer(Modifier.height(6.dp))
                Text(t("%s نسخة").format(book.copies), fontSize = 10.sp, color = TextSecondary)
            }
            Icon(Icons.Outlined.ChevronLeft, contentDescription = null, tint = TextSecondary)
        }
    }
}

package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.LibraryPlan
import com.wujha.admin.data.Localization
import com.wujha.admin.data.model.Shelf
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.FilterChip
import com.wujha.admin.ui.components.FloorPlanLegend
import com.wujha.admin.ui.components.FloorPlanView
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.components.SearchField
import com.wujha.admin.ui.theme.AccentGold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenMid
import com.wujha.admin.ui.theme.ForestGreenWash
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

/**
 * The library as a plan, one floor at a time.
 *
 * Everything drawn here is the live `floors` and `shelves` collections, so a
 * block added in إدارة المواقع appears on this map immediately. Searching for
 * a bookcase highlights it and draws the route to it, which is the quickest
 * way to check that a bookcase really is where the catalog says it is.
 */
@Composable
fun LibraryMapScreen(repository: LibraryRepository, onBack: () -> Unit) {
    val floors by repository.floors.collectAsState()
    val shelves by repository.shelves.collectAsState()
    val books by repository.books.collectAsState()

    var query by remember { mutableStateOf("") }
    var selectedFloorId by remember { mutableStateOf("") }

    val ordered = remember(floors) { LibraryPlan.ordered(floors) }
    val activeId = selectedFloorId.ifBlank { ordered.firstOrNull()?.id.orEmpty() }
    val floor = ordered.firstOrNull { it.id == activeId }
    val floorIndex = ordered.indexOfFirst { it.id == activeId }.coerceAtLeast(0)

    val bookCounts = remember(books) {
        books.filter { it.shelf.isNotBlank() }.groupingBy { it.shelf }.eachCount()
    }

    // A search match becomes the map's destination, so the route shows the
    // way to it exactly as a visitor would be sent.
    val match: Shelf? = remember(query, shelves) {
        if (query.isBlank()) null
        else shelves.firstOrNull { it.code.equals(query.trim(), true) }
            ?: shelves.firstOrNull { it.code.contains(query.trim(), true) }
            ?: shelves.firstOrNull { it.zone.contains(query.trim(), true) }
    }
    val targetFloorId = match?.floorId
    val shownId = targetFloorId?.takeIf { id -> ordered.any { it.id == id } } ?: activeId
    val shownFloor = ordered.firstOrNull { it.id == shownId } ?: floor
    val shownIndex = ordered.indexOfFirst { it.id == shownId }.coerceAtLeast(0)

    val english = Localization.isEnglish
    val map = remember(shownFloor, shelves, bookCounts, match, shownIndex, english) {
        LibraryPlan.floorMap(
            floor = shownFloor,
            shelves = shelves,
            bookCounts = bookCounts,
            target = match?.takeIf { it.floorId == shownFloor?.id },
            fromFloorIndex = 0,
            floorIndex = shownIndex,
            english = english
        )
    }

    val onFloor = remember(shelves, shownId) { shelves.filter { it.floorId == shownId } }

    ScreenScaffold(title = t("خريطة المكتبة"), onBack = onBack) {
        if (ordered.isEmpty()) {
            EmptyView(
                icon = Icons.Outlined.Map,
                title = t("لم تُعرَّف أدوار المكتبة بعد"),
                detail = t("أضف الأدوار والبلوكات والممرات من الإعدادات ← إدارة المواقع، ثم ستُرسم الخريطة تلقائياً.")
            )
            return@ScreenScaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                SearchField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = t("ابحث برمز الرف أو القسم...")
                )
                Spacer(Modifier.height(10.dp))
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ordered) { f ->
                        FilterChip(
                            label = f.displayName(english),
                            selected = f.id == shownId,
                            onClick = { selectedFloorId = f.id; query = "" }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            if (match != null && match.floorId != shownId) {
                item {
                    Notice(t("الرف %s موجود في %s، وليس في هذا الدور.").format(match.code, match.floor))
                    Spacer(Modifier.height(10.dp))
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = shownFloor?.displayName(english).orEmpty(),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = t("%s بلوك • %s ممر • %s رف").format(shownFloor?.blocks?.size ?: 0, shownFloor?.blocks?.sumOf { it.aisles.size } ?: 0, onFloor.size),
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        if (map.isEmpty) {
                            Text(
                                text = t("لا توجد بلوكات معرَّفة في هذا الدور بعد."),
                                color = TextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 24.dp)
                            )
                        } else {
                            FloorPlanView(
                                map = map,
                                modifier = Modifier.fillMaxWidth().aspectRatio(0.95f),
                                english = english
                            )
                            Spacer(Modifier.height(10.dp))
                            FloorPlanLegend(
                                shelfLabel = t("رف"),
                                targetLabel = t("الرف المطلوب"),
                                corridorLabel = t("ممر")
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            item {
                Text(
                    text = t("رفوف هذا الدور"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            if (onFloor.isEmpty()) {
                item {
                    Text(
                        text = t("لا توجد رفوف مسجّلة في هذا الدور."),
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }

            items(onFloor) { shelf ->
                ShelfSummaryRow(
                    shelf = shelf,
                    bookCount = bookCounts[shelf.code] ?: 0,
                    isMatch = shelf.code == match?.code
                )
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun Notice(text: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = ForestGreenWash
    ) {
        Text(
            text = text,
            color = ForestGreen,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
        )
    }
}

/** One bookcase: where it is, and how full it is against its capacity. */
@Composable
private fun ShelfSummaryRow(shelf: Shelf, bookCount: Int, isMatch: Boolean) {
    val over = shelf.capacity in 1..bookCount
    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, if (isMatch) AccentGold else BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(46.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(shape = RoundedCornerShape(10.dp), color = ForestGreenWash) {
                    Box(modifier = Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = shelf.code,
                            color = ForestGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    text = shelf.zone.ifBlank { t("بدون قسم") },
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = listOfNotNull(
                        shelf.block.takeIf { it.isNotBlank() }?.let { t("بلوك %s").format(it) },
                        shelf.aisle.takeIf { it.isNotBlank() }?.let { t("ممر %s").format(it) },
                        shelf.side.takeIf { it.isNotBlank() }
                    ).joinToString(" • "),
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
            Text(
                text = if (shelf.capacity > 0) "$bookCount / ${shelf.capacity}" else "$bookCount",
                color = if (over) SignalRed else ForestGreenMid,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

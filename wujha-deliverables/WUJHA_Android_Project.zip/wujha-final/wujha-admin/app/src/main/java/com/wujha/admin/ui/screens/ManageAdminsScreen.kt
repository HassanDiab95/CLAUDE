package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import com.google.firebase.auth.FirebaseAuth
import com.wujha.admin.data.model.AdminGrant
import com.wujha.admin.data.model.AppAccount
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.storage.ImageCodec
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.components.SearchField
import com.wujha.admin.ui.theme.AccentGold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackgroundAlt
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenWash
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * المشرفون والصلاحيات.
 *
 * Permission in this app is one thing and one thing only: whether a document
 * exists at `admins/{your user id}`. The security rules ask that question
 * before every write, so this screen is the only place a person's access
 * actually changes.
 *
 * Nobody has to copy a user id out of the Firebase console. Every sign-in,
 * in either app, records the account at `users/{uid}`, so this screen can
 * list real people with their names and let an admin promote one by tapping
 * it. The library's very first admin is not granted here at all — whoever
 * signs in first to an empty database becomes the owner automatically.
 */
@Composable
fun ManageAdminsScreen(repository: LibraryRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val admins by repository.admins.collectAsState()
    val accounts by repository.accounts.collectAsState()
    val myRole by repository.role.collectAsState()
    val myUid = remember { FirebaseAuth.getInstance().currentUser?.uid.orEmpty() }

    var query by remember { mutableStateOf("") }
    var granting by remember { mutableStateOf<AppAccount?>(null) }
    var revoking by remember { mutableStateOf<AdminGrant?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    val adminUids = remember(admins) { admins.map { it.uid }.toSet() }
    val candidates = remember(accounts, adminUids, query) {
        accounts
            .filterNot { it.uid in adminUids || it.anonymous }
            .filter {
                query.isBlank() || it.name.contains(query, true) ||
                    it.email.contains(query, true)
            }
    }

    ScreenScaffold(title = t("المشرفون والصلاحيات"), onBack = onBack) {
        if (myRole == null) {
            EmptyView(
                icon = Icons.Outlined.AdminPanelSettings,
                title = t("لا تملك صلاحية إدارة المشرفين"),
                detail = t("هذه الصفحة متاحة للمشرفين فقط. اطلب من أحد المشرفين الحاليين أن يمنحك الصلاحية.")
            )
            return@ScreenScaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)
        ) {
            item {
                ExplainerCard()
                Spacer(Modifier.height(16.dp))
            }

            item {
                Text(
                    text = t("المشرفون الحاليون (%s)").format(admins.size),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            items(admins) { grant ->
                AdminRow(
                    grant = grant,
                    isMe = grant.uid == myUid,
                    onRevoke = { revoking = grant }
                )
            }

            item {
                Spacer(Modifier.height(20.dp))
                Text(
                    text = t("الحسابات المسجّلة"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = t("كل من سجّل الدخول لأحد التطبيقين. اختر حساباً لمنحه صلاحية المشرف."),
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                SearchField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = t("ابحث بالاسم أو البريد الإلكتروني...")
                )
                Spacer(Modifier.height(10.dp))
            }

            if (candidates.isEmpty()) {
                item {
                    Text(
                        text = if (accounts.isEmpty()) {
                            t("لم يسجّل أحد الدخول بعد غيرك. اطلب من زميلك تثبيت التطبيق وإنشاء حساب، ثم سيظهر هنا.")
                        } else {
                            t("لا توجد حسابات مطابقة.")
                        },
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(vertical = 20.dp)
                    )
                }
            }

            items(candidates) { account ->
                AccountRow(account = account, onGrant = { granting = account })
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    val toGrant = granting
    if (toGrant != null) {
        AlertDialog(
            onDismissRequest = { granting = null },
            containerColor = SurfaceWhite,
            title = { Text(t("منح صلاحية المشرف"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Text(
                    t("سيتمكّن %s من إضافة الكتب والرفوف والأعضاء وتعديلها وحذفها، ومن منح الصلاحية لغيره. يمكنك سحب الصلاحية في أي وقت.").format(toGrant.label),
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    granting = null
                    scope.launch {
                        message = repository.grantAdmin(toGrant)
                            ?: t("أصبح %s مشرفاً.").format(toGrant.label)
                    }
                }) { Text(t("منح الصلاحية"), color = ForestGreen, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { granting = null }) { Text(t("إلغاء"), color = TextSecondary) }
            }
        )
    }

    val toRevoke = revoking
    if (toRevoke != null) {
        AlertDialog(
            onDismissRequest = { revoking = null },
            containerColor = SurfaceWhite,
            title = { Text(t("سحب الصلاحية"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Text(
                    t("سيفقد %s إمكانية التعديل فوراً، ويبقى حسابه قائماً بصلاحيات القراءة فقط.").format(toRevoke.label),
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    revoking = null
                    scope.launch {
                        message = repository.revokeAdmin(toRevoke)
                            ?: t("سُحبت الصلاحية من %s.").format(toRevoke.label)
                    }
                }) { Text(t("سحب الصلاحية"), color = SignalRed, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { revoking = null }) { Text(t("إلغاء"), color = TextSecondary) }
            }
        )
    }

    ResultDialog(message) { message = null }
}

/**
 * The one thing people get wrong about this app, said plainly.
 *
 * "مشرف" and "عضو" look like the same idea and are not, and the difference
 * decides which screen someone should be on.
 */
@Composable
private fun ExplainerCard() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = CreamBackgroundAlt
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = t("المشرف ليس العضو"),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = TextPrimary
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = t("المشرف هو حساب في التطبيق تُمنح له صلاحية التعديل من هذه الصفحة. الصلاحية مرتبطة بحسابه، وهي ما تسمح له بالكتابة في قاعدة البيانات."),
                color = TextSecondary,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = t("العضو في «إدارة الأعضاء» شيء آخر تماماً: هو سجلّ المكتبة لشخص يحقّ له الاستعارة، معرّفه رقم الهوية المطبوع على بطاقته. يُسجَّل من مكتب الاستعارة حتى لو لم يفتح التطبيق أبداً، ولا يمنحه ذلك أي صلاحية داخل التطبيق."),
                color = TextSecondary,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun AdminRow(grant: AdminGrant, isMe: Boolean, onRevoke: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, if (grant.isOwner) AccentGold else BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(38.dp).clip(CircleShape)
                    .background(if (grant.isOwner) AccentGold else ForestGreen),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = grant.label.take(1),
                    color = SurfaceWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = grant.label,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (isMe) {
                        Text(
                            text = t("(أنت)"),
                            color = TextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(start = 5.dp)
                        )
                    }
                }
                Text(
                    text = grant.email.ifBlank { grant.uid },
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (grant.isOwner) AccentGold.copy(alpha = 0.18f) else ForestGreenWash
            ) {
                Text(
                    text = t(grant.role.labelAr),
                    color = if (grant.isOwner) AccentGold else ForestGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
            if (!grant.isOwner && !isMe) {
                TextButton(onClick = onRevoke) {
                    Text(t("سحب"), color = SignalRed, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun AccountRow(account: AppAccount, onGrant: () -> Unit) {
    val photo = remember(account.photoBase64) { ImageCodec.decode(account.photoBase64) }
    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(38.dp).clip(CircleShape).background(ForestGreenWash),
                contentAlignment = Alignment.Center
            ) {
                if (photo != null) {
                    Image(
                        bitmap = photo.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(38.dp).clip(CircleShape)
                    )
                } else {
                    Text(
                        text = account.initial,
                        color = ForestGreen,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    text = account.label,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = listOfNotNull(
                        account.email.takeIf { it.isNotBlank() },
                        if (account.app == "admin") t("تطبيق المشرف") else t("تطبيق الزوار")
                    ).joinToString(" • "),
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Surface(onClick = onGrant, shape = RoundedCornerShape(10.dp), color = ForestGreen) {
                Text(
                    text = t("منح الصلاحية"),
                    color = SurfaceWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp)
                )
            }
        }
    }
}

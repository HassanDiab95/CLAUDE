package com.wujha.admin.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.wujha.admin.data.PreferencesProvider
import com.wujha.admin.data.notify.LoanAlertKind
import com.wujha.admin.data.notify.LoanAlerts
import com.wujha.admin.data.notify.NotificationStoreProvider
import com.wujha.admin.data.notify.Notifier
import com.wujha.admin.data.repository.LibraryRepositoryProvider

/**
 * Tells the librarian when something lands on the desk.
 *
 * The admin app is already listening to the whole `loans` collection, so a
 * request sent from a visitor's phone is here within a second. This turns
 * that into a notification while the app is open — which is the honest
 * limit of a project with no server behind it.
 */
@Composable
fun LoanAlertWatcher() {
    val context = LocalContext.current
    val repository = LibraryRepositoryProvider.repository
    val loans by repository.loans.collectAsState()
    val policy by repository.loanPolicy.collectAsState()
    val settings by PreferencesProvider.preferences.settings.collectAsState()
    val store = remember { NotificationStoreProvider.store }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* the الإعارة tab counts them either way */ }

    LaunchedEffect(Unit) {
        Notifier.ensureChannel(context)
        if (Notifier.needsPermission() && !Notifier.hasPermission(context)) {
            permissionLauncher.launch(Notifier.permission)
        }
    }

    LaunchedEffect(loans, policy, settings) {
        val alerts = LoanAlerts.from(loans, policy.pickupWindowDays)
        store.refreshUnread(alerts.map { it.key })

        val fresh = alerts.filter { !store.wasPosted(it.key) }

        // First run on this device: take note of what is already open
        // without announcing a backlog.
        if (!store.hasBaseline()) {
            store.markPosted(fresh.map { it.key })
            store.setBaseline()
            return@LaunchedEffect
        }

        val enabled = settings.associate { it.key to it.enabled }
        fresh.forEach { alert ->
            val allowed = when (alert.kind) {
                LoanAlertKind.OVERDUE -> enabled[KEY_OVERDUE] ?: true
                else -> enabled[KEY_REQUESTS] ?: true
            }
            if (allowed) Notifier.post(context, alert)
        }
        store.markPosted(fresh.map { it.key })
    }
}

private const val KEY_REQUESTS = "notify_loan_requests"
private const val KEY_OVERDUE = "notify_overdue"

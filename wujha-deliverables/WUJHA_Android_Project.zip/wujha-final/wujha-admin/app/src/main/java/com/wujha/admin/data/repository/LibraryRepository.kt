package com.wujha.admin.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Transaction
import com.wujha.admin.data.LibraryPlan
import com.wujha.admin.data.LoanDates
import com.wujha.admin.data.SeedData
import com.wujha.admin.data.model.ActivityEntry
import com.wujha.admin.data.model.AdminGrant
import com.wujha.admin.data.model.AdminRole
import com.wujha.admin.data.model.Aisle
import com.wujha.admin.data.model.AppAccount
import com.wujha.admin.data.model.Block
import com.wujha.admin.data.model.Book
import com.wujha.admin.data.model.BookStatus
import com.wujha.admin.data.model.Category
import com.wujha.admin.data.model.CategoryCount
import com.wujha.admin.data.model.DashboardStats
import com.wujha.admin.data.model.Floor
import com.wujha.admin.data.model.LibraryUser
import com.wujha.admin.data.model.Loan
import com.wujha.admin.data.model.LoanChannel
import com.wujha.admin.data.model.LoanPolicy
import com.wujha.admin.data.model.LoanStats
import com.wujha.admin.data.model.LoanStatus
import com.wujha.admin.data.model.ReportStats
import com.wujha.admin.data.model.Shelf
import com.wujha.admin.data.model.UserStatus
import com.wujha.admin.data.t
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/** Where the catalog is in its loading lifecycle. */
sealed interface DataStatus {
    data object Loading : DataStatus
    data object Ready : DataStatus
    data class Error(val message: String) : DataStatus
}

/** Progress of the one-time library setup done by the first admin. */
sealed interface SetupState {
    /** Nothing is being set up. */
    data object Idle : SetupState

    /** [done] of [total] documents written so far. */
    data class Running(val done: Int, val total: Int) : SetupState

    /** Setup stopped part-way; [LibraryRepository.retrySetup] resumes it. */
    data class Failed(val message: String) : SetupState
}

/**
 * The admin data layer, backed entirely by Cloud Firestore.
 *
 * Reads are live: every collection has a snapshot listener, so a change made
 * on another device — or in the Firebase console — appears here without a
 * refresh. Writes are suspend functions returning an Arabic error message,
 * or null on success.
 */
interface LibraryRepository {
    val books: StateFlow<List<Book>>
    val members: StateFlow<List<LibraryUser>>
    val shelves: StateFlow<List<Shelf>>
    val categories: StateFlow<List<Category>>
    val floors: StateFlow<List<Floor>>
    val activity: StateFlow<List<ActivityEntry>>
    val status: StateFlow<DataStatus>

    /** Every borrowing, newest first — requests, holds, loans out, history. */
    val loans: StateFlow<List<Loan>>

    /** The library's borrowing rules, from `meta/loanPolicy`. */
    val loanPolicy: StateFlow<LoanPolicy>

    /** Everyone holding the admin role, for the role management screen. */
    val admins: StateFlow<List<AdminGrant>>

    /** Every account that has ever signed in to either app. Admin-readable. */
    val accounts: StateFlow<List<AppAccount>>

    /** This account's role, or null while it holds none. */
    val role: StateFlow<AdminRole?>

    /** Progress of the first-login setup; [SetupState.Idle] on a normal launch. */
    val setup: StateFlow<SetupState>

    /**
     * True only while the starter library has never been written.
     *
     * It flips to false the moment the seed completes and stays false for
     * every admin, on every device, forever — so the button that runs it
     * appears exactly once in the life of the database.
     */
    val seedAvailable: StateFlow<Boolean>

    /** Resumes a setup that stopped part-way (network drop, app closed). */
    fun retrySetup()

    fun getBook(id: String): Book?

    suspend fun addBook(book: Book): String?
    suspend fun updateBook(book: Book): String?
    suspend fun deleteBook(id: String): String?

    suspend fun addShelf(shelf: Shelf): String?
    suspend fun updateShelf(shelf: Shelf): String?
    suspend fun deleteShelf(shelf: Shelf): String?

    suspend fun addCategory(category: Category): String?
    suspend fun deleteCategory(category: Category): String?

    suspend fun saveFloor(floor: Floor): String?
    suspend fun deleteFloor(floor: Floor): String?

    suspend fun addMember(member: LibraryUser): String?
    suspend fun updateMember(member: LibraryUser): String?
    suspend fun toggleMemberStatus(member: LibraryUser): String?
    suspend fun deleteMember(member: LibraryUser): String?

    // -----------------------------------------------------------------------
    // Borrowing
    //
    // Every call below returns null on success or an Arabic sentence a
    // librarian can act on. The ones that move a copy on or off the shelf run
    // as a Firestore transaction over the loan and the book together, so the
    // last copy can never be promised to two people at once — not even from
    // two devices in the same second.
    // -----------------------------------------------------------------------

    /** This loan's borrowing membership, when one has been matched. */
    fun memberFor(loan: Loan): LibraryUser?

    /** Every loan touching one book, newest first. */
    fun loansForBook(bookId: String): List<Loan>

    /** Every loan belonging to one membership, newest first. */
    fun loansForMember(member: LibraryUser): List<Loan>

    /** Loan figures for the dashboard and the reports screen. */
    fun loanStats(): LoanStats

    /**
     * Records a loan for someone standing at the desk.
     *
     * The book is handed over there and then, so this skips the request and
     * the hold: the loan starts out [LoanStatus.ACTIVE] with a due date.
     */
    suspend fun createDeskLoan(
        book: Book,
        member: LibraryUser,
        notes: String = "",
        idPhotoBase64: String = ""
    ): String?

    /**
     * Approves a request from the app and holds a copy for the borrower.
     *
     * The membership is resolved from the ID number on the request: an
     * existing one is linked to the account that asked, and a person who has
     * never borrowed before gets a membership created for them here — which
     * is the whole point of asking for the number and the photo.
     */
    suspend fun approveRequest(loan: Loan): String?

    /** Turns a request down, with a reason the borrower will see. */
    suspend fun rejectRequest(loan: Loan, reason: String): String?

    /** Records that the borrower collected the copy being held for them. */
    suspend fun issueLoan(loan: Loan): String?

    /** Drops a hold nobody came to collect and puts the copy back. */
    suspend fun releaseHold(loan: Loan, reason: String = ""): String?

    /** Takes the book back: the copy returns to the shelf. */
    suspend fun returnLoan(loan: Loan): String?

    /** Extends the due date, within the renewal limit in the policy. */
    suspend fun renewLoan(loan: Loan): String?

    /** Answers a renewal request with no: the due date stands. */
    suspend fun declineRenewal(loan: Loan): String?

    /** Writes a copy off as lost; it stops counting as out on loan. */
    suspend fun markLoanLost(loan: Loan, notes: String = ""): String?

    /** Records that a librarian compared the ID photo with the typed details. */
    suspend fun setIdVerified(loan: Loan, verified: Boolean): String?

    /** Saves the borrowing rules. */
    suspend fun saveLoanPolicy(policy: LoanPolicy): String?

    /** Gives [account] the admin role. Returns an Arabic error, or null. */
    suspend fun grantAdmin(account: AppAccount): String?

    /** Takes the admin role away. The owner can never be removed from here. */
    suspend fun revokeAdmin(grant: AdminGrant): String?

    fun dashboardStats(): DashboardStats
    fun reportStats(): ReportStats

    /** Writes the starter library. Only ever possible while [seedAvailable]. */
    suspend fun seedInitialData(): String?

    /** Everything the backup screen exports, as pretty-printed JSON. */
    fun exportAsJson(): String
}

class FirestoreLibraryRepository : LibraryRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val bookState = MutableStateFlow<List<Book>>(emptyList())
    private val memberState = MutableStateFlow<List<LibraryUser>>(emptyList())
    private val shelfState = MutableStateFlow<List<Shelf>>(emptyList())
    private val categoryState = MutableStateFlow<List<Category>>(emptyList())
    private val floorState = MutableStateFlow<List<Floor>>(emptyList())
    private val activityState = MutableStateFlow<List<ActivityEntry>>(emptyList())
    private val loanState = MutableStateFlow<List<Loan>>(emptyList())
    private val policyState = MutableStateFlow(LoanPolicy.DEFAULT)
    private val adminState = MutableStateFlow<List<AdminGrant>>(emptyList())
    private val accountState = MutableStateFlow<List<AppAccount>>(emptyList())
    private val roleState = MutableStateFlow<AdminRole?>(null)
    private val statusState = MutableStateFlow<DataStatus>(DataStatus.Loading)
    private val setupState = MutableStateFlow<SetupState>(SetupState.Idle)
    private val seedAvailableState = MutableStateFlow(false)

    override val books: StateFlow<List<Book>> = bookState.asStateFlow()
    override val members: StateFlow<List<LibraryUser>> = memberState.asStateFlow()
    override val shelves: StateFlow<List<Shelf>> = shelfState.asStateFlow()
    override val categories: StateFlow<List<Category>> = categoryState.asStateFlow()
    override val floors: StateFlow<List<Floor>> = floorState.asStateFlow()
    override val activity: StateFlow<List<ActivityEntry>> = activityState.asStateFlow()
    override val loans: StateFlow<List<Loan>> = loanState.asStateFlow()
    override val loanPolicy: StateFlow<LoanPolicy> = policyState.asStateFlow()
    override val admins: StateFlow<List<AdminGrant>> = adminState.asStateFlow()
    override val accounts: StateFlow<List<AppAccount>> = accountState.asStateFlow()
    override val role: StateFlow<AdminRole?> = roleState.asStateFlow()
    override val status: StateFlow<DataStatus> = statusState.asStateFlow()
    override val setup: StateFlow<SetupState> = setupState.asStateFlow()
    override val seedAvailable: StateFlow<Boolean> = seedAvailableState.asStateFlow()

    private val registrations = mutableListOf<ListenerRegistration>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var sessionUid: String? = null
    private var sessionJob: Job? = null

    init {
        // Listeners are NOT attached here. Firestore drops a listener for good
        // if its first read is refused, and before sign-in every read is
        // refused — so attaching at construction would leave the app dead
        // after login. Each sign-in starts a session instead: claim the
        // library if it is empty, seed it, then attach. Signing out tears the
        // whole thing down again.
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user?.uid == sessionUid) return@addAuthStateListener
            sessionUid = user?.uid
            if (user == null) endSession() else startSession(user)
        }
    }

    // -----------------------------------------------------------------------
    // Session
    // -----------------------------------------------------------------------

    private fun startSession(user: FirebaseUser) {
        sessionJob?.cancel()
        detachListeners()
        clearState()
        sessionJob = scope.launch {
            bootstrap(user)
            // Signed out, or switched account, while setup was running: this
            // session is stale and must not attach listeners.
            ensureActive()
            attachListeners(user.uid)
        }
    }

    private fun endSession() {
        sessionJob?.cancel()
        detachListeners()
        clearState()
        setupState.value = SetupState.Idle
    }

    override fun retrySetup() {
        auth.currentUser?.let { startSession(it) }
    }

    private fun detachListeners() {
        registrations.forEach { it.remove() }
        registrations.clear()
    }

    private fun clearState() {
        bookState.value = emptyList()
        memberState.value = emptyList()
        shelfState.value = emptyList()
        categoryState.value = emptyList()
        floorState.value = emptyList()
        activityState.value = emptyList()
        loanState.value = emptyList()
        policyState.value = LoanPolicy.DEFAULT
        adminState.value = emptyList()
        accountState.value = emptyList()
        roleState.value = null
        seedAvailableState.value = false
        statusState.value = DataStatus.Loading
    }

    // -----------------------------------------------------------------------
    // First-admin bootstrap
    // -----------------------------------------------------------------------

    /**
     * The first person to sign in to a brand-new database becomes its owner.
     *
     * `meta/setup` is the lock. A Firestore `create` only succeeds while the
     * document does not exist, so exactly one account can ever win the claim;
     * everyone signing in afterwards reads an existing document and is simply
     * not the owner. The claim writes `admins/{uid}` in the same batch, and
     * the rules accept the two only together — an account cannot make itself
     * an admin once the lock is taken.
     *
     * This is why nobody has to paste a user id into the Firebase console:
     * install the app, sign up, and the account that did it owns the library.
     *
     * If the seed was interrupted the same account resumes it on its next
     * sign-in. Every seed document has a fixed id, so writing it twice
     * overwrites rather than duplicates.
     */
    private suspend fun bootstrap(user: FirebaseUser) {
        if (user.isAnonymous) return
        val uid = user.uid
        val setupRef = db.collection(META).document(SETUP_DOC)
        val adminRef = db.collection(ADMINS).document(uid)

        val needsSeed = try {
            val setupDoc = setupRef.get().await()
            when {
                !setupDoc.exists() -> {
                    val claimed = claimLibrary(user, setupRef, adminRef)
                    if (!claimed && !setupRef.get().await().exists()) {
                        // The lock is still free, yet the claim was refused.
                        // Nobody beat us to it, so the rules are the problem.
                        setupState.value = SetupState.Failed(
                            t("تعذّر تسجيل حسابك كمالك للمكتبة. تأكد من نشر قواعد firestore.rules في Firestore ← Rules، ثم أعد المحاولة.")
                        )
                        return
                    }
                    claimed
                }
                setupDoc.getBoolean("seeded") != true &&
                    adminRef.get().await().exists() -> true
                else -> false
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // The lock could not even be read. This is the one that bites on
            // a first run: sign up before Firestore exists and the claim
            // never happens, with nothing on screen to say why. Surfacing it
            // here gives the retry dialog something to offer.
            setupState.value = SetupState.Failed(arabicMessage(e))
            return
        }

        seedAvailableState.value = needsSeed
        if (!needsSeed) return

        try {
            seedAll()
            setupState.value = SetupState.Idle
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            setupState.value = SetupState.Failed(arabicMessage(e))
        }
    }

    /** True when this account just claimed an empty library. */
    private suspend fun claimLibrary(
        user: FirebaseUser,
        setupRef: DocumentReference,
        adminRef: DocumentReference
    ): Boolean = try {
        val name = user.displayName?.takeIf { it.isNotBlank() }
            ?: user.email?.substringBefore("@").orEmpty()
        val batch = db.batch()
        batch.set(
            setupRef,
            mapOf(
                "ownerUid" to user.uid,
                "seeded" to false,
                "claimedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            adminRef,
            mapOf(
                "role" to AdminRole.OWNER.key,
                "name" to name,
                "email" to user.email.orEmpty(),
                "grantedByName" to name,
                "grantedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
        true
    } catch (e: FirebaseFirestoreException) {
        // Refused means another account claimed first, in the moment between
        // the read and this write. Not an error: this account is simply not
        // the owner.
        if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ||
            e.code == FirebaseFirestoreException.Code.ALREADY_EXISTS
        ) false else throw e
    }

    /**
     * Writes the starter library in small batches.
     *
     * Every write is checked against a rule that does one `exists()` lookup,
     * and Firestore caps a batched request at 20 of those — so a single
     * hundred-document batch would be refused outright. Ten per batch stays
     * well inside the cap and gives the progress dialog something to move.
     */
    private suspend fun seedAll() {
        val writes = buildList<Pair<DocumentReference, Map<String, Any>>> {
            SeedData.floors.forEach { add(db.collection(FLOORS).document(it.id) to it.toMap()) }
            SeedData.categories.forEach { add(db.collection(CATEGORIES).document(it.id) to it.toMap()) }
            SeedData.shelves.forEach { add(db.collection(SHELVES).document(it.id) to it.toMap()) }
            SeedData.members.forEach { add(db.collection(MEMBERS).document(it.id) to it.toMap()) }
            SeedData.books.forEach { add(db.collection(BOOKS).document(it.id) to it.toMap()) }
            SeedData.sampleLoans().forEach { add(db.collection(LOANS).document(it.id) to it.toMap()) }
            // The borrowing rules, written out rather than left implicit, so
            // the settings screen opens on real values and the field names
            // exist in the database from the first day.
            add(db.collection(META).document(LOAN_POLICY_DOC) to LoanPolicy.DEFAULT.toMap())
        }
        setupState.value = SetupState.Running(0, writes.size)

        writes.chunked(SEED_BATCH_SIZE).forEachIndexed { index, chunk ->
            val batch = db.batch()
            chunk.forEach { (ref, data) -> batch.set(ref, data) }
            batch.commit().await()
            setupState.value = SetupState.Running(
                done = minOf((index + 1) * SEED_BATCH_SIZE, writes.size),
                total = writes.size
            )
        }

        // Closes the door. From here the seed button is gone for every admin
        // on every device, because they all read this one flag.
        db.collection(META).document(SETUP_DOC).set(
            mapOf(
                "seeded" to true,
                "seededAt" to FieldValue.serverTimestamp(),
                "seedVersion" to SeedData.VERSION
            ),
            com.google.firebase.firestore.SetOptions.merge()
        ).await()
        seedAvailableState.value = false

        log(
            "أدخل البيانات الأولية",
            t("%s كتاب • %s رف • %s دور • %s إعارة").format(
                SeedData.books.size,
                SeedData.shelves.size,
                SeedData.floors.size,
                SeedData.sampleLoans().size
            )
        )
    }

    // -----------------------------------------------------------------------
    // Live reads
    // -----------------------------------------------------------------------

    private fun attachListeners(uid: String) {
        registrations += db.collection(ADMINS).document(uid)
            .addSnapshotListener { snap, _ ->
                roleState.value =
                    if (snap != null && snap.exists()) AdminRole.from(snap.getString("role")) else null
            }

        registrations += db.collection(META).document(SETUP_DOC)
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                // Only the owner of an unseeded library is offered the button.
                seedAvailableState.value =
                    snap.exists() && snap.getBoolean("seeded") != true && snap.getString("ownerUid") == uid
            }

        registrations += db.collection(FLOORS)
            .addSnapshotListener { snap, error ->
                if (error != null) { reportError(error); return@addSnapshotListener }
                floorState.value = LibraryPlan.ordered(
                    snap?.documents?.mapNotNull { it.toFloor() }.orEmpty()
                )
                resortShelves()
            }

        registrations += db.collection(BOOKS)
            .addSnapshotListener { snap, error ->
                if (error != null) { reportError(error); return@addSnapshotListener }
                bookState.value = snap?.documents
                    ?.mapNotNull { it.toBook() }
                    ?.sortedBy { it.title }
                    .orEmpty()
                statusState.value = DataStatus.Ready
            }

        registrations += db.collection(MEMBERS)
            .addSnapshotListener { snap, error ->
                if (error != null) { reportError(error); return@addSnapshotListener }
                memberState.value = snap?.documents
                    ?.mapNotNull { it.toMember() }
                    ?.sortedBy { it.name }
                    .orEmpty()
            }

        registrations += db.collection(SHELVES)
            .addSnapshotListener { snap, error ->
                if (error != null) { reportError(error); return@addSnapshotListener }
                rawShelves = snap?.documents?.mapNotNull { it.toShelf() }.orEmpty()
                resortShelves()
            }

        registrations += db.collection(CATEGORIES)
            .addSnapshotListener { snap, error ->
                if (error != null) { reportError(error); return@addSnapshotListener }
                categoryState.value = snap?.documents
                    ?.mapNotNull { it.toCategory() }
                    ?.sortedBy { it.name }
                    .orEmpty()
            }

        // The two below are admin-only reads. A librarian without the role
        // gets a permission error on them, which must not blank the app —
        // the catalog above is what matters, so these fail quietly.
        registrations += db.collection(ADMINS)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                adminState.value = snap?.documents
                    ?.map { it.toAdminGrant() }
                    ?.sortedWith(compareBy({ !it.isOwner }, { it.label }))
                    .orEmpty()
            }

        registrations += db.collection(USERS)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                accountState.value = snap?.documents
                    ?.map { it.toAccount() }
                    ?.sortedByDescending { it.lastSeenMillis }
                    .orEmpty()
            }

        registrations += db.collection(ACTIVITY)
            .orderBy("at", Query.Direction.DESCENDING)
            .limit(150)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                activityState.value = snap?.documents?.mapNotNull { it.toActivity() }.orEmpty()
            }

        // Loans are sorted here rather than in the query. Ordering in
        // Firestore would need a composite index for every filter the
        // الإعارة screen offers, and the whole collection of a library this
        // size is a few hundred documents — the device can sort that in
        // less time than a round trip to ask for an index.
        registrations += db.collection(LOANS)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                loanState.value = snap?.documents
                    ?.mapNotNull { it.toLoan() }
                    ?.sortedByDescending { it.sortKey }
                    .orEmpty()
            }

        // The borrowing rules. A library that has never opened this screen
        // has no document, and the defaults in LoanPolicy stand.
        registrations += db.collection(META).document(LOAN_POLICY_DOC)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                policyState.value =
                    if (snap != null && snap.exists()) snap.toLoanPolicy() else LoanPolicy.DEFAULT
            }
    }

    /** Last raw shelf snapshot, re-sorted whenever the floors change. */
    private var rawShelves: List<Shelf> = emptyList()

    private fun resortShelves() {
        shelfState.value = rawShelves.sortedWith(LibraryPlan.shelfOrder(floorState.value))
    }

    private fun reportError(error: Throwable) {
        statusState.value = DataStatus.Error(arabicMessage(error))
    }

    /** Turns a Firestore failure into something a librarian can act on. */
    private fun arabicMessage(error: Throwable): String {
        val raw = error.message.orEmpty()
        return when {
            raw.contains("PERMISSION_DENIED", true) || raw.contains("permission", true) ->
                t("لا تملك صلاحية الوصول. اطلب من مشرف الحالي أن يمنحك دور المشرف من إعدادات ← المشرفون والصلاحيات.")
            raw.contains("UNAVAILABLE", true) || raw.contains("network", true) ->
                t("تعذّر الاتصال بقاعدة البيانات. تحقق من اتصال الإنترنت.")
            raw.contains("NOT_FOUND", true) || raw.contains("does not exist", true) ->
                t("قاعدة البيانات غير موجودة. أنشئ Firestore من لوحة تحكم Firebase.")
            else -> t("حدث خطأ في قاعدة البيانات: %s").format(raw.take(120))
        }
    }

    // -----------------------------------------------------------------------
    // Mapping
    // -----------------------------------------------------------------------

    private fun DocumentSnapshot.toBook(): Book? {
        val title = getString("title") ?: return null
        val rawTags = get("tags") as? List<*>
        return Book(
            id = id,
            title = title,
            author = getString("author").orEmpty(),
            category = getString("category").orEmpty(),
            coverColor = getLong("coverColor") ?: 0xFF1F4E46,
            coverBase64 = getString("coverBase64").orEmpty(),
            status = BookStatus.from(getString("status")),
            shelf = getString("shelf").orEmpty(),
            section = getString("section").orEmpty(),
            floorId = getString("floorId").orEmpty(),
            floor = getString("floor").orEmpty(),
            block = getString("block").orEmpty(),
            aisle = getString("aisle").orEmpty(),
            serial = getString("serial").orEmpty(),
            dateAdded = getString("dateAdded").orEmpty(),
            copies = (getLong("copies") ?: 1L).toInt(),
            // How many copies are out right now. Read back so that editing a
            // book (updateBook) keeps the count instead of resetting it to 0.
            onLoan = (getLong("onLoan") ?: 0L).toInt(),
            notes = getString("notes").orEmpty(),
            description = getString("description").orEmpty(),
            tags = rawTags?.filterIsInstance<String>().orEmpty(),
            publisher = getString("publisher").orEmpty(),
            language = getString("language").orEmpty().ifBlank { "العربية" },
            pageCount = (getLong("pageCount") ?: 0L).toInt(),
            rating = getDouble("rating") ?: 0.0,
            ratingCount = (getLong("ratingCount") ?: 0L).toInt()
        )
    }

    private fun DocumentSnapshot.toMember(): LibraryUser? {
        val name = getString("name") ?: return null
        return LibraryUser(
            id = id,
            name = name,
            idNumber = getString("idNumber").orEmpty(),
            status = UserStatus.from(getString("status")),
            phone = getString("phone").orEmpty(),
            joinDate = getString("joinDate").orEmpty(),
            memberType = getString("memberType").orEmpty(),
            linkedUid = getString("linkedUid").orEmpty()
        )
    }

    /**
     * Reads a loan.
     *
     * A loan with no book title is not a loan — it is a half-written
     * document — so it is dropped rather than drawn as an empty row.
     */
    private fun DocumentSnapshot.toLoan(): Loan? {
        val bookId = getString("bookId") ?: return null
        if (getString("bookTitle").isNullOrBlank()) return null
        return Loan(
            id = id,
            bookId = bookId,
            bookTitle = getString("bookTitle").orEmpty(),
            bookSerial = getString("bookSerial").orEmpty(),
            bookShelf = getString("bookShelf").orEmpty(),
            memberId = getString("memberId").orEmpty(),
            memberName = getString("memberName").orEmpty(),
            memberIdNumber = getString("memberIdNumber").orEmpty(),
            memberPhone = getString("memberPhone").orEmpty(),
            requesterUid = getString("requesterUid").orEmpty(),
            status = LoanStatus.from(getString("status")),
            channel = LoanChannel.from(getString("channel")),
            idPhotoBase64 = getString("idPhotoBase64").orEmpty(),
            idVerified = getBoolean("idVerified") ?: false,
            idVerifiedBy = getString("idVerifiedBy").orEmpty(),
            requestedAt = getLong("requestedAt") ?: 0L,
            decidedAt = getLong("decidedAt") ?: 0L,
            issuedAt = getLong("issuedAt") ?: 0L,
            dueAt = getLong("dueAt") ?: 0L,
            returnedAt = getLong("returnedAt") ?: 0L,
            renewals = (getLong("renewals") ?: 0L).toInt(),
            renewRequested = getBoolean("renewRequested") ?: false,
            decidedBy = getString("decidedBy").orEmpty(),
            issuedBy = getString("issuedBy").orEmpty(),
            returnedBy = getString("returnedBy").orEmpty(),
            rejectReason = getString("rejectReason").orEmpty(),
            notes = getString("notes").orEmpty()
        )
    }

    private fun DocumentSnapshot.toLoanPolicy(): LoanPolicy = LoanPolicy.from(
        loanDays = getLong("loanDays"),
        maxRenewals = getLong("maxRenewals"),
        renewDays = getLong("renewDays"),
        maxActivePerMember = getLong("maxActivePerMember"),
        pickupWindowDays = getLong("pickupWindowDays"),
        requireIdPhoto = getBoolean("requireIdPhoto"),
        overdueSuspendDays = getLong("overdueSuspendDays")
    )

    private fun DocumentSnapshot.toShelf(): Shelf? {
        val code = getString("code") ?: return null
        return Shelf(
            id = id,
            code = code,
            floorId = getString("floorId").orEmpty(),
            floor = getString("floor").orEmpty(),
            block = getString("block").orEmpty(),
            aisle = getString("aisle").orEmpty(),
            position = (getLong("position") ?: 0L).toInt(),
            side = getString("side").orEmpty(),
            levels = (getLong("levels") ?: 3L).toInt(),
            zone = getString("zone").orEmpty(),
            capacity = (getLong("capacity") ?: 0L).toInt(),
            notes = getString("notes").orEmpty(),
            section = getString("section").orEmpty()
        )
    }

    private fun DocumentSnapshot.toCategory(): Category? {
        val name = getString("name") ?: return null
        return Category(id = id, name = name, iconKey = getString("iconKey").orEmpty().ifBlank { "book" })
    }

    /**
     * Reads a floor and the blocks and aisles nested inside it.
     *
     * The nested shape keeps a whole floor in one document, so the plan a
     * librarian edits is saved and read atomically — no chance of a block
     * arriving before the aisles that belong to it.
     */
    private fun DocumentSnapshot.toFloor(): Floor? {
        val name = getString("name") ?: return null
        val rawBlocks = get("blocks") as? List<*>
        val blocks = rawBlocks.orEmpty().mapNotNull { raw ->
            val map = raw as? Map<*, *> ?: return@mapNotNull null
            val rawAisles = map["aisles"] as? List<*>
            Block(
                code = map["code"] as? String ?: return@mapNotNull null,
                name = map["name"] as? String ?: "",
                nameEn = map["nameEn"] as? String ?: "",
                row = (map["row"] as? Number)?.toInt() ?: 0,
                column = (map["column"] as? Number)?.toInt() ?: 0,
                aisles = rawAisles.orEmpty().mapNotNull { rawAisle ->
                    val a = rawAisle as? Map<*, *> ?: return@mapNotNull null
                    Aisle(
                        code = a["code"] as? String ?: return@mapNotNull null,
                        name = a["name"] as? String ?: "",
                        nameEn = a["nameEn"] as? String ?: "",
                        order = (a["order"] as? Number)?.toInt() ?: 0
                    )
                }.sortedBy { it.order }
            )
        }.sortedWith(compareBy({ it.row }, { it.column }))

        return Floor(
            id = id,
            name = name,
            nameEn = getString("nameEn").orEmpty(),
            order = (getLong("order") ?: 0L).toInt(),
            blocks = blocks
        )
    }

    private fun DocumentSnapshot.toAdminGrant(): AdminGrant = AdminGrant(
        uid = id,
        role = AdminRole.from(getString("role")),
        name = getString("name").orEmpty(),
        email = getString("email").orEmpty(),
        grantedByName = getString("grantedByName").orEmpty(),
        grantedAtMillis = getTimestamp("grantedAt")?.toDate()?.time ?: 0L
    )

    private fun DocumentSnapshot.toAccount(): AppAccount = AppAccount(
        uid = id,
        name = getString("name").orEmpty(),
        email = getString("email").orEmpty(),
        photoBase64 = getString("photoBase64").orEmpty(),
        app = getString("app").orEmpty(),
        anonymous = getBoolean("anonymous") ?: false,
        lastSeenMillis = getTimestamp("lastSeenAt")?.toDate()?.time ?: 0L
    )

    private fun DocumentSnapshot.toActivity(): ActivityEntry? {
        val action = getString("action") ?: return null
        return ActivityEntry(
            id = id,
            action = action,
            target = getString("target").orEmpty(),
            actorName = getString("actorName").orEmpty(),
            actorUid = getString("actorUid").orEmpty(),
            atMillis = getTimestamp("at")?.toDate()?.time ?: 0L
        )
    }

    // -----------------------------------------------------------------------
    // Writes
    // -----------------------------------------------------------------------

    override fun getBook(id: String): Book? = bookState.value.find { it.id == id }

    private fun actorName(): String = auth.currentUser?.displayName
        ?: auth.currentUser?.email?.substringBefore("@")
        ?: "مشرف"

    /** Appends to the activity log. Never fails the operation it describes. */
    private suspend fun log(action: String, target: String) {
        runCatching {
            db.collection(ACTIVITY).add(
                mapOf(
                    "action" to action,
                    "target" to target,
                    "actorName" to actorName(),
                    "actorUid" to (auth.currentUser?.uid ?: ""),
                    "at" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    private suspend fun write(action: String, target: String, block: suspend () -> Unit): String? =
        try {
            block()
            log(action, target)
            null
        } catch (e: Exception) {
            arabicMessage(e)
        }

    override suspend fun addBook(book: Book): String? =
        write("أضاف كتاباً", book.title) {
            db.collection(BOOKS).add(book.toMap()).await()
        }

    /**
     * Saves an edited book, with the loan count protected from the form.
     *
     * The book form writes the whole document, and it knows nothing about
     * borrowing — so two things are enforced here. The library cannot be
     * told it owns fewer copies than it currently has out, and the status
     * cannot be set to available while every copy is out: both would make
     * the visitor app offer a book that is not on the shelf.
     */
    override suspend fun updateBook(book: Book): String? {
        val onLoan = getBook(book.id)?.onLoan ?: 0
        if (onLoan > book.copies) {
            return t("لا يمكن جعل عدد النسخ %s، فهناك %s نسخة مُعارة أو محجوزة حالياً.")
                .format(book.copies, onLoan)
        }
        val reconciled = book.copy(
            onLoan = onLoan,
            status = when {
                book.status == BookStatus.LOST -> BookStatus.LOST
                onLoan >= book.copies -> BookStatus.BORROWED
                book.status == BookStatus.BORROWED -> BookStatus.AVAILABLE
                else -> book.status
            }
        )
        return write("عدّل كتاباً", book.title) {
            db.collection(BOOKS).document(book.id).set(reconciled.toMap()).await()
        }
    }

    override suspend fun deleteBook(id: String): String? {
        val book = getBook(id)
        val title = book?.title.orEmpty()
        val out = loansForBook(id).count { it.holdsCopy }
        if (out > 0) {
            return t("لا يمكن حذف «%s»: %s نسخة منه مُعارة أو محجوزة. استرجعها أولاً.")
                .format(title, out)
        }
        return write("حذف كتاباً", title) {
            db.collection(BOOKS).document(id).delete().await()
        }
    }

    /** Books point at a bookcase by code, so two bookcases must never share one. */
    private fun codeTakenBy(shelf: Shelf): Shelf? =
        shelfState.value.firstOrNull {
            it.id != shelf.id && it.code.equals(shelf.code, ignoreCase = true)
        }

    override suspend fun addShelf(shelf: Shelf): String? {
        codeTakenBy(shelf)?.let { return t("رمز الرف %s مستخدم مسبقاً في %s").format(shelf.code, it.floor) }
        return write("أضاف رفاً", shelf.code) {
            db.collection(SHELVES).add(shelf.toMap()).await()
        }
    }

    override suspend fun updateShelf(shelf: Shelf): String? {
        codeTakenBy(shelf)?.let { return t("رمز الرف %s مستخدم مسبقاً في %s").format(shelf.code, it.floor) }
        return write("عدّل رفاً", shelf.code) {
            db.collection(SHELVES).document(shelf.id).set(shelf.toMap()).await()
        }
    }

    override suspend fun deleteShelf(shelf: Shelf): String? =
        write("حذف رفاً", shelf.code) {
            db.collection(SHELVES).document(shelf.id).delete().await()
        }

    override suspend fun addCategory(category: Category): String? =
        write("أضاف تصنيفاً", category.name) {
            db.collection(CATEGORIES).add(category.toMap()).await()
        }

    override suspend fun deleteCategory(category: Category): String? =
        write("حذف تصنيفاً", category.name) {
            db.collection(CATEGORIES).document(category.id).delete().await()
        }

    override suspend fun saveFloor(floor: Floor): String? {
        if (floor.id.isBlank()) return t("معرّف الدور مطلوب")
        val existing = floorState.value.firstOrNull { it.id == floor.id }
        return write(if (existing == null) "أضاف دوراً" else "عدّل دوراً", floor.name) {
            db.collection(FLOORS).document(floor.id).set(floor.toMap()).await()
        }
    }

    override suspend fun deleteFloor(floor: Floor): String? {
        val onFloor = shelfState.value.count { it.floorId == floor.id }
        if (onFloor > 0) {
            return t("لا يمكن حذف %s: ما زال يحتوي على %s رف. انقل الرفوف أو احذفها أولاً.").format(floor.name, onFloor)
        }
        return write("حذف دوراً", floor.name) {
            db.collection(FLOORS).document(floor.id).delete().await()
        }
    }

    override suspend fun addMember(member: LibraryUser): String? {
        val clash = memberState.value.firstOrNull {
            member.idNumber.isNotBlank() && it.idNumber == member.idNumber
        }
        if (clash != null) return t("رقم الهوية %s مسجّل مسبقاً باسم %s").format(member.idNumber, clash.name)
        return write("أضاف عضواً", member.name) {
            db.collection(MEMBERS).add(member.toMap()).await()
        }
    }

    override suspend fun updateMember(member: LibraryUser): String? =
        write("عدّل عضواً", member.name) {
            db.collection(MEMBERS).document(member.id).set(member.toMap()).await()
        }

    override suspend fun toggleMemberStatus(member: LibraryUser): String? {
        val next = if (member.status == UserStatus.ACTIVE) UserStatus.SUSPENDED else UserStatus.ACTIVE
        val label = if (next == UserStatus.SUSPENDED) "أوقف عضوية" else "أعاد تفعيل عضوية"
        return write(label, member.name) {
            db.collection(MEMBERS).document(member.id).update("status", next.name).await()
        }
    }

    override suspend fun deleteMember(member: LibraryUser): String? {
        val open = loansForMember(member).count { it.status.isOpen }
        if (open > 0) {
            return t("لا يمكن حذف %s: لديه %s إعارة مفتوحة. أغلِق إعاراته أولاً.").format(member.name, open)
        }
        return write("حذف عضواً", member.name) {
            db.collection(MEMBERS).document(member.id).delete().await()
        }
    }

    // -----------------------------------------------------------------------
    // Borrowing
    //
    // The shape of every operation below is the same: check what can be
    // checked from the live data first, because that is where the useful
    // Arabic error comes from, then do the part that must not race inside a
    // Firestore transaction — which re-checks the same things against the
    // server, and loses to whoever got there first.
    // -----------------------------------------------------------------------

    /** A refusal that already carries the sentence the librarian should read. */
    private class LoanRefused(val arabic: String) : Exception(arabic)

    /** Digs a [LoanRefused] out of whatever the Firestore client wrapped it in. */
    private fun refusalOf(error: Throwable): String? {
        if (error is LoanRefused) return error.arabic
        val cause = error.cause
        if (cause is LoanRefused) return cause.arabic
        return null
    }

    private suspend fun loanWrite(action: String, target: String, block: suspend () -> Unit): String? =
        try {
            block()
            log(action, target)
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            refusalOf(e) ?: arabicMessage(e)
        }

    /** What a transaction needs to know about one title's copies. */
    private data class CopyCount(val copies: Int, val onLoan: Int, val status: BookStatus) {
        val free: Int get() = (copies - onLoan).coerceAtLeast(0)
    }

    private fun Transaction.copyCount(ref: DocumentReference, title: String): CopyCount {
        val snap = get(ref)
        if (!snap.exists()) {
            throw LoanRefused(
                t("الكتاب «%s» غير موجود في الفهرس، ربما حُذف بعد تسجيل الطلب.").format(title)
            )
        }
        return CopyCount(
            copies = (snap.getLong("copies") ?: 1L).toInt(),
            onLoan = (snap.getLong("onLoan") ?: 0L).toInt(),
            status = BookStatus.from(snap.getString("status"))
        )
    }

    /** Re-reads the loan's status, so two librarians cannot both act on it. */
    private fun Transaction.loanStatus(ref: DocumentReference): LoanStatus {
        val snap = get(ref)
        if (!snap.exists()) throw LoanRefused(t("هذه الإعارة غير موجودة."))
        return LoanStatus.from(snap.getString("status"))
    }

    private fun Transaction.requireStatus(ref: DocumentReference, expected: LoanStatus): LoanStatus {
        val actual = loanStatus(ref)
        if (actual != expected) {
            throw LoanRefused(
                t("تغيّرت حالة هذه الإعارة إلى «%s» من جهاز آخر. أعِد فتح الصفحة.")
                    .format(t(actual.labelAr))
            )
        }
        return actual
    }

    /**
     * Writes the new out-on-loan count and keeps the book's own status with it.
     *
     * A title marked lost stays lost: the count moves underneath it, but
     * nothing here quietly promotes it back to available — that is the
     * librarian's call, from the book form.
     */
    private fun Transaction.setCopyCount(ref: DocumentReference, count: CopyCount, delta: Int) {
        val next = (count.onLoan + delta).coerceAtLeast(0)
        val status = when {
            count.status == BookStatus.LOST -> BookStatus.LOST
            next >= count.copies -> BookStatus.BORROWED
            else -> BookStatus.AVAILABLE
        }
        update(ref, mapOf("onLoan" to next, "status" to status.name))
    }

    override fun memberFor(loan: Loan): LibraryUser? {
        if (loan.memberId.isNotBlank()) {
            memberState.value.firstOrNull { it.id == loan.memberId }?.let { return it }
        }
        // The account's own membership outranks a match on the typed number:
        // one app account belongs to one person, and that person has one
        // card. A request carrying somebody else's number is a mistake to be
        // caught, not a second membership to be created.
        if (loan.requesterUid.isNotBlank()) {
            memberState.value.firstOrNull { it.linkedUid == loan.requesterUid }?.let { return it }
        }
        if (loan.memberIdNumber.isBlank()) return null
        return memberState.value.firstOrNull { it.idNumber == loan.memberIdNumber }
    }

    override fun loansForBook(bookId: String): List<Loan> =
        loanState.value.filter { it.bookId == bookId }

    override fun loansForMember(member: LibraryUser): List<Loan> =
        loanState.value.filter {
            (it.memberId.isNotBlank() && it.memberId == member.id) ||
                (member.idNumber.isNotBlank() && it.memberIdNumber == member.idNumber)
        }

    /** How many copies this member already has held or out. */
    private fun openLoanCount(member: LibraryUser): Int =
        loansForMember(member).count { it.holdsCopy }

    /** Shared pre-flight for both ways a loan can start. */
    private fun borrowingBlockedFor(member: LibraryUser, book: Book): String? {
        if (member.status == UserStatus.SUSPENDED) {
            return t("عضوية %s موقوفة حالياً. أعِد تفعيلها من «إدارة المستخدمين» قبل الإعارة.")
                .format(member.name)
        }
        val policy = policyState.value
        val open = openLoanCount(member)
        if (open >= policy.maxActivePerMember) {
            return t("%s لديه %s إعارة مفتوحة، والحد المسموح %s. استرجع كتاباً أولاً.")
                .format(member.name, open, policy.maxActivePerMember)
        }
        if (book.status == BookStatus.LOST) {
            return t("«%s» مسجّل كمفقود، ولا يمكن إعارته.").format(book.title)
        }
        return null
    }

    override suspend fun createDeskLoan(
        book: Book,
        member: LibraryUser,
        notes: String,
        idPhotoBase64: String
    ): String? {
        if (book.id.isBlank()) return t("اختر الكتاب المُعار.")
        if (member.id.isBlank()) return t("اختر العضو المستعير.")
        borrowingBlockedFor(member, book)?.let { return it }

        val policy = policyState.value
        val now = LoanDates.now()
        val loanRef = db.collection(LOANS).document()
        val bookRef = db.collection(BOOKS).document(book.id)
        val actor = actorName()

        // A desk loan starts out already in the borrower's hands, so it is
        // issued and due in the same write that creates it.
        val loan = Loan(
            bookId = book.id,
            bookTitle = book.title,
            bookSerial = book.serial,
            bookShelf = book.shelf,
            memberId = member.id,
            memberName = member.name,
            memberIdNumber = member.idNumber,
            memberPhone = member.phone,
            status = LoanStatus.ACTIVE,
            channel = LoanChannel.DESK,
            idPhotoBase64 = idPhotoBase64,
            // The librarian is holding the card, so the check has happened.
            idVerified = true,
            idVerifiedBy = actor,
            requestedAt = now,
            decidedAt = now,
            issuedAt = now,
            dueAt = LoanDates.dueDate(policy.loanDays, now),
            decidedBy = actor,
            issuedBy = actor,
            notes = notes.trim()
        )

        return loanWrite("سجّل إعارة", "${book.title} — ${member.name}") {
            db.runTransaction<Unit> { tx ->
                val count = tx.copyCount(bookRef, book.title)
                if (count.status == BookStatus.LOST) {
                    throw LoanRefused(t("«%s» مسجّل كمفقود، ولا يمكن إعارته.").format(book.title))
                }
                if (count.free <= 0) {
                    throw LoanRefused(
                        t("لا توجد نسخة متاحة من «%s»: كل النسخ (%s) مُعارة أو محجوزة.")
                            .format(book.title, count.copies)
                    )
                }
                tx.set(loanRef, loan.toMap())
                tx.setCopyCount(bookRef, count, +1)
            }.await()
        }
    }

    override suspend fun approveRequest(loan: Loan): String? {
        if (loan.status != LoanStatus.REQUESTED) return t("هذا الطلب لم يبقَ قيد المراجعة.")
        val policy = policyState.value

        // The review step, and the reason the visitor is asked for a photo at
        // all: a request is not approved until a human has compared the card
        // with the name and number typed into the app.
        if (loan.channel == LoanChannel.APP && policy.requireIdPhoto && !loan.idVerified) {
            return t("راجع صورة الهوية وأكّد مطابقتها للاسم ورقم الهوية قبل الموافقة.")
        }
        if (loan.memberIdNumber.isBlank()) {
            return t("الطلب بلا رقم هوية، فلا يمكن ربطه بعضوية. اطلب من مقدّم الطلب إعادة إرساله.")
        }

        val book = getBook(loan.bookId)
            ?: return t("الكتاب «%s» غير موجود في الفهرس، ربما حُذف بعد تسجيل الطلب.")
                .format(loan.bookTitle)

        // One account, one membership. If this account already has a card,
        // the request has to carry that card's number — otherwise approving
        // it would register the same person twice, each with their own
        // borrowing limit and their own history.
        val linked = memberState.value.firstOrNull {
            loan.requesterUid.isNotBlank() && it.linkedUid == loan.requesterUid
        }
        if (linked != null && linked.idNumber.isNotBlank() &&
            linked.idNumber != loan.memberIdNumber
        ) {
            return t("هذا الحساب مرتبط بعضوية %s برقم الهوية %s، والطلب يحمل الرقم %s. صحّح رقم الهوية في العضوية أو اطلب إعادة إرسال الطلب بالرقم الصحيح.")
                .format(linked.name, linked.idNumber, loan.memberIdNumber)
        }

        // And the other direction: a number that already belongs to somebody
        // else's account is not this person's to borrow under.
        val sameNumber = memberState.value.firstOrNull {
            it.idNumber.isNotBlank() && it.idNumber == loan.memberIdNumber
        }
        if (sameNumber != null && sameNumber.linkedUid.isNotBlank() &&
            loan.requesterUid.isNotBlank() && sameNumber.linkedUid != loan.requesterUid
        ) {
            return t("رقم الهوية %s مسجّل لعضوية %s ومرتبط بحساب آخر. تحقّق من الهوية قبل الموافقة.")
                .format(loan.memberIdNumber, sameNumber.name)
        }

        val existing = memberFor(loan)
        if (existing != null) {
            borrowingBlockedFor(existing, book)?.let { return it }
        }

        // No membership yet: this request is the first time the library has
        // heard of this person, so approving it registers them. This is the
        // «إضافة عضو برقم الهوية» path, reached from the request instead of
        // from the members screen.
        val newMembership = existing == null
        val memberRef = if (existing != null) {
            db.collection(MEMBERS).document(existing.id)
        } else {
            db.collection(MEMBERS).document()
        }
        val membership = existing ?: LibraryUser(
            id = memberRef.id,
            name = loan.memberName.trim(),
            idNumber = loan.memberIdNumber.trim(),
            status = UserStatus.ACTIVE,
            phone = loan.memberPhone.trim(),
            joinDate = LoanDates.today(),
            linkedUid = loan.requesterUid
        )

        val loanRef = db.collection(LOANS).document(loan.id)
        val bookRef = db.collection(BOOKS).document(loan.bookId)
        val now = LoanDates.now()
        val actor = actorName()
        val targetSuffix = if (newMembership) t(" (عضوية جديدة)") else ""

        return loanWrite("وافق على طلب إعارة", "${loan.bookTitle} — ${membership.name}$targetSuffix") {
            db.runTransaction<Unit> { tx ->
                val count = tx.copyCount(bookRef, loan.bookTitle)
                tx.requireStatus(loanRef, LoanStatus.REQUESTED)
                if (count.status == BookStatus.LOST) {
                    throw LoanRefused(t("«%s» مسجّل كمفقود، ولا يمكن إعارته.").format(loan.bookTitle))
                }
                if (count.free <= 0) {
                    throw LoanRefused(
                        t("لا توجد نسخة متاحة من «%s»: كل النسخ (%s) مُعارة أو محجوزة.")
                            .format(loan.bookTitle, count.copies)
                    )
                }

                if (newMembership) {
                    tx.set(memberRef, membership.toMap())
                } else if (membership.linkedUid.isBlank() && loan.requesterUid.isNotBlank()) {
                    // Ties the existing card to the app account that asked,
                    // so the next request needs no matching at all.
                    tx.update(memberRef, mapOf("linkedUid" to loan.requesterUid))
                }

                tx.update(
                    loanRef,
                    mapOf(
                        "status" to LoanStatus.APPROVED.name,
                        "memberId" to membership.id,
                        // The membership is the authority on the name from
                        // here on, not what was typed into the request.
                        "memberName" to membership.name,
                        "decidedAt" to now,
                        "decidedBy" to actor,
                        "rejectReason" to ""
                    )
                )
                tx.setCopyCount(bookRef, count, +1)
            }.await()
        }
    }

    override suspend fun rejectRequest(loan: Loan, reason: String): String? {
        if (loan.status != LoanStatus.REQUESTED) return t("هذا الطلب لم يبقَ قيد المراجعة.")
        if (reason.isBlank()) return t("اذكر سبب الرفض ليظهر لمقدّم الطلب.")
        val loanRef = db.collection(LOANS).document(loan.id)
        return loanWrite("رفض طلب إعارة", "${loan.bookTitle} — ${loan.borrowerLabel}") {
            loanRef.update(
                mapOf(
                    "status" to LoanStatus.REJECTED.name,
                    "decidedAt" to LoanDates.now(),
                    "decidedBy" to actorName(),
                    "rejectReason" to reason.trim(),
                    // A refused request keeps no picture of anybody's ID.
                    "idPhotoBase64" to ""
                )
            ).await()
        }
    }

    override suspend fun issueLoan(loan: Loan): String? {
        if (loan.status != LoanStatus.APPROVED) {
            return t("لا يمكن التسليم إلا لإعارة بانتظار الاستلام.")
        }
        val policy = policyState.value
        val now = LoanDates.now()
        val loanRef = db.collection(LOANS).document(loan.id)
        // The copy is already counted as off the shelf by the approval, so
        // handing it over moves no numbers — only dates.
        return loanWrite("سلّم نسخة لمستعير", "${loan.bookTitle} — ${loan.borrowerLabel}") {
            loanRef.update(
                mapOf(
                    "status" to LoanStatus.ACTIVE.name,
                    "issuedAt" to now,
                    "dueAt" to LoanDates.dueDate(policy.loanDays, now),
                    "issuedBy" to actorName()
                )
            ).await()
        }
    }

    override suspend fun releaseHold(loan: Loan, reason: String): String? {
        if (loan.status != LoanStatus.APPROVED) {
            return t("لا يوجد حجز لإلغائه على هذه الإعارة.")
        }
        val loanRef = db.collection(LOANS).document(loan.id)
        val bookRef = db.collection(BOOKS).document(loan.bookId)
        val note = reason.ifBlank { t("لم تُستلم النسخة خلال مدة الحجز") }
        return loanWrite("ألغى حجز نسخة", "${loan.bookTitle} — ${loan.borrowerLabel}") {
            db.runTransaction<Unit> { tx ->
                val count = tx.copyCount(bookRef, loan.bookTitle)
                tx.requireStatus(loanRef, LoanStatus.APPROVED)
                tx.update(
                    loanRef,
                    mapOf(
                        "status" to LoanStatus.CANCELLED.name,
                        "decidedAt" to LoanDates.now(),
                        "decidedBy" to actorName(),
                        "rejectReason" to note,
                        "renewRequested" to false,
                        "idPhotoBase64" to ""
                    )
                )
                tx.setCopyCount(bookRef, count, -1)
            }.await()
        }
    }

    override suspend fun returnLoan(loan: Loan): String? {
        if (loan.status != LoanStatus.ACTIVE) {
            return t("لا يمكن الاسترجاع إلا لإعارة قائمة.")
        }
        val loanRef = db.collection(LOANS).document(loan.id)
        val bookRef = db.collection(BOOKS).document(loan.bookId)
        val late = loan.daysLate
        val target = if (late > 0) {
            t("%s — %s (متأخرة %s يوم)").format(loan.bookTitle, loan.borrowerLabel, late)
        } else {
            "${loan.bookTitle} — ${loan.borrowerLabel}"
        }
        return loanWrite("استرجع كتاباً", target) {
            db.runTransaction<Unit> { tx ->
                val count = tx.copyCount(bookRef, loan.bookTitle)
                tx.requireStatus(loanRef, LoanStatus.ACTIVE)
                tx.update(
                    loanRef,
                    mapOf(
                        "status" to LoanStatus.RETURNED.name,
                        "returnedAt" to LoanDates.now(),
                        "returnedBy" to actorName(),
                        "renewRequested" to false,
                        // The loan is closed, so the photo of the ID card has
                        // nothing left to prove. Keeping it would be keeping
                        // somebody's identity document for no reason.
                        "idPhotoBase64" to ""
                    )
                )
                tx.setCopyCount(bookRef, count, -1)
            }.await()
        }
    }

    override suspend fun renewLoan(loan: Loan): String? {
        if (loan.status != LoanStatus.ACTIVE) return t("لا يمكن تجديد إعارة غير قائمة.")
        val policy = policyState.value
        if (loan.renewals >= policy.maxRenewals) {
            return t("استُهلك عدد التجديدات المسموح (%s) لهذه الإعارة.").format(policy.maxRenewals)
        }
        if (loan.isOverdue) {
            return t("لا يمكن تجديد إعارة متأخرة. استرجع الكتاب أولاً، ثم أعِد إعارته إن أراد.")
        }
        val next = LoanDates.renewedDueDate(loan.dueAt, policy.renewDays)
        val loanRef = db.collection(LOANS).document(loan.id)
        return loanWrite(
            "جدّد إعارة",
            t("%s — %s (حتى %s)").format(loan.bookTitle, loan.borrowerLabel, LoanDates.format(next))
        ) {
            loanRef.update(
                mapOf(
                    "dueAt" to next,
                    "renewals" to loan.renewals + 1,
                    "renewRequested" to false
                )
            ).await()
        }
    }

    override suspend fun declineRenewal(loan: Loan): String? {
        if (!loan.renewRequested) return t("لا يوجد طلب تجديد على هذه الإعارة.")
        val loanRef = db.collection(LOANS).document(loan.id)
        return loanWrite("رفض طلب تجديد", "${loan.bookTitle} — ${loan.borrowerLabel}") {
            loanRef.update(mapOf("renewRequested" to false)).await()
        }
    }

    override suspend fun markLoanLost(loan: Loan, notes: String): String? {
        if (!loan.holdsCopy) {
            return t("لا يمكن تسجيل الفقدان إلا لنسخة محجوزة أو مُعارة.")
        }
        val loanRef = db.collection(LOANS).document(loan.id)
        val bookRef = db.collection(BOOKS).document(loan.bookId)
        val current = loan.status
        // The copy stops counting as out on loan, because it is never coming
        // back. The number of copies the library owns is a separate fact, and
        // the librarian adjusts it from the book form if the copy is written
        // off for good.
        return loanWrite("سجّل نسخة مفقودة", "${loan.bookTitle} — ${loan.borrowerLabel}") {
            db.runTransaction<Unit> { tx ->
                val count = tx.copyCount(bookRef, loan.bookTitle)
                tx.requireStatus(loanRef, current)
                tx.update(
                    loanRef,
                    mapOf(
                        "status" to LoanStatus.LOST.name,
                        "returnedAt" to LoanDates.now(),
                        "returnedBy" to actorName(),
                        "renewRequested" to false,
                        "notes" to notes.trim().ifBlank { loan.notes },
                        "idPhotoBase64" to ""
                    )
                )
                tx.setCopyCount(bookRef, count, -1)
            }.await()
        }
    }

    override suspend fun setIdVerified(loan: Loan, verified: Boolean): String? {
        val loanRef = db.collection(LOANS).document(loan.id)
        val action = if (verified) "أكّد مطابقة الهوية" else "ألغى تأكيد الهوية"
        return loanWrite(action, "${loan.bookTitle} — ${loan.borrowerLabel}") {
            loanRef.update(
                mapOf(
                    "idVerified" to verified,
                    "idVerifiedBy" to if (verified) actorName() else ""
                )
            ).await()
        }
    }

    override suspend fun saveLoanPolicy(policy: LoanPolicy): String? {
        if (policy.loanDays <= 0) return t("مدة الإعارة يجب أن تكون يوماً واحداً على الأقل.")
        if (policy.maxActivePerMember <= 0) return t("الحد الأعلى للإعارات يجب أن يكون 1 على الأقل.")
        if (policy.pickupWindowDays <= 0) return t("مدة حجز النسخة يجب أن تكون يوماً واحداً على الأقل.")
        return loanWrite("عدّل إعدادات الإعارة", t("%s يوم للإعارة").format(policy.loanDays)) {
            db.collection(META).document(LOAN_POLICY_DOC).set(policy.toMap()).await()
        }
    }

    // -----------------------------------------------------------------------
    // Roles
    // -----------------------------------------------------------------------

    override suspend fun grantAdmin(account: AppAccount): String? {
        if (account.uid.isBlank()) return t("الحساب غير صالح")
        if (account.anonymous) return t("حسابات الزوار لا يمكن ترقيتها إلى مشرف.")
        if (adminState.value.any { it.uid == account.uid }) return t("%s مشرف بالفعل.").format(account.label)
        return write("منح صلاحية مشرف", account.label) {
            db.collection(ADMINS).document(account.uid).set(
                mapOf(
                    "role" to AdminRole.ADMIN.key,
                    "name" to account.name,
                    "email" to account.email,
                    "grantedByName" to actorName(),
                    "grantedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    override suspend fun revokeAdmin(grant: AdminGrant): String? {
        if (grant.isOwner) return t("لا يمكن سحب الصلاحية من مالك المكتبة.")
        if (grant.uid == auth.currentUser?.uid) return t("لا يمكنك سحب صلاحيتك من نفسك.")
        return write("سحب صلاحية مشرف", grant.label) {
            db.collection(ADMINS).document(grant.uid).delete().await()
        }
    }

    // -----------------------------------------------------------------------
    // Derived figures — computed from the live catalog, never stored
    // -----------------------------------------------------------------------

    override fun dashboardStats(): DashboardStats {
        val all = bookState.value
        val names = categoryState.value.associate { it.id to it.name }
        return DashboardStats(
            totalBooks = all.sumOf { it.copies },
            availableBooks = all.count { it.status == BookStatus.AVAILABLE },
            borrowedBooks = all.count { it.status == BookStatus.BORROWED },
            lostBooks = all.count { it.status == BookStatus.LOST },
            byCategory = all.groupingBy { it.category }.eachCount()
                .map { (id, n) -> CategoryCount(names[id] ?: id.ifBlank { t("غير مصنّف") }, n) }
                .sortedByDescending { it.count }
        )
    }

    override fun loanStats(): LoanStats {
        val all = loanState.value
        val monthAgo = LoanDates.now() - RECENT_WINDOW_MILLIS
        return LoanStats(
            pendingRequests = all.count { it.status == LoanStatus.REQUESTED },
            awaitingPickup = all.count { it.status == LoanStatus.APPROVED },
            activeLoans = all.count { it.status == LoanStatus.ACTIVE },
            overdueLoans = all.count { it.isOverdue },
            dueSoon = all.count { it.isDueSoon },
            renewalRequests = all.count { it.renewRequested && it.status == LoanStatus.ACTIVE },
            returnedRecently = all.count {
                it.status == LoanStatus.RETURNED && it.returnedAt >= monthAgo
            },
            lostLoans = all.count { it.status == LoanStatus.LOST },
            // Requests that were turned down or withdrawn are left out: the
            // book was never borrowed, so counting them would make a title
            // look popular because people kept being refused it.
            topBorrowed = all
                .filter { it.status != LoanStatus.REJECTED && it.status != LoanStatus.CANCELLED }
                .groupingBy { it.bookTitle }
                .eachCount()
                .map { (title, n) -> CategoryCount(title, n) }
                .sortedByDescending { it.count }
                .take(5)
        )
    }

    override fun reportStats(): ReportStats {
        val all = bookState.value
        val names = categoryState.value.associate { it.id to it.name }
        return ReportStats(
            totalBooks = all.size,
            totalShelves = shelfState.value.size,
            totalMembers = memberState.value.size,
            activeMembers = memberState.value.count { it.status == UserStatus.ACTIVE },
            statusBreakdown = BookStatus.entries.map { s ->
                CategoryCount(t(s.labelAr), all.count { it.status == s })
            },
            topCategories = all.groupingBy { it.category }.eachCount()
                .map { (id, n) -> CategoryCount(names[id] ?: id.ifBlank { t("غير مصنّف") }, n) }
                .sortedByDescending { it.count }
                .take(5),
            byShelf = all.filter { it.shelf.isNotBlank() }
                .groupingBy { it.shelf }.eachCount()
                .map { (code, n) -> CategoryCount(code, n) }
                .sortedByDescending { it.count }
                .take(8)
        )
    }

    // -----------------------------------------------------------------------
    // Seeding and export
    // -----------------------------------------------------------------------

    override suspend fun seedInitialData(): String? {
        if (!seedAvailableState.value) {
            return t("تم إدخال البيانات الأولية مسبقاً، ولا يمكن تكرارها.")
        }
        return try {
            seedAll()
            setupState.value = SetupState.Idle
            null
        } catch (e: Exception) {
            setupState.value = SetupState.Idle
            arabicMessage(e)
        }
    }

    override fun exportAsJson(): String {
        fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
        val sb = StringBuilder()
        sb.append("{\n  \"floors\": [\n")
        sb.append(floorState.value.joinToString(",\n") { f ->
            "    {\"id\":\"${esc(f.id)}\",\"name\":\"${esc(f.name)}\"," +
                "\"blocks\":${f.blocks.size},\"aisles\":${f.blocks.sumOf { it.aisles.size }}}"
        })
        sb.append("\n  ],\n  \"books\": [\n")
        sb.append(bookState.value.joinToString(",\n") { b ->
            "    {\"id\":\"${esc(b.id)}\",\"title\":\"${esc(b.title)}\"," +
                "\"author\":\"${esc(b.author)}\",\"category\":\"${esc(b.category)}\"," +
                "\"status\":\"${b.status.name}\",\"shelf\":\"${esc(b.shelf)}\"," +
                "\"level\":\"${esc(b.section)}\",\"floor\":\"${esc(b.floor)}\",\"copies\":${b.copies}}"
        })
        sb.append("\n  ],\n  \"shelves\": [\n")
        sb.append(shelfState.value.joinToString(",\n") { s ->
            "    {\"code\":\"${esc(s.code)}\",\"floorId\":\"${esc(s.floorId)}\"," +
                "\"block\":\"${esc(s.block)}\",\"aisle\":\"${esc(s.aisle)}\"," +
                "\"position\":${s.position},\"capacity\":${s.capacity}}"
        })
        sb.append("\n  ],\n  \"members\": [\n")
        sb.append(memberState.value.joinToString(",\n") { m ->
            "    {\"name\":\"${esc(m.name)}\",\"idNumber\":\"${esc(m.idNumber)}\"," +
                "\"status\":\"${m.status.name}\"}"
        })
        sb.append("\n  ],\n  \"categories\": [\n")
        sb.append(categoryState.value.joinToString(",\n") { c ->
            "    {\"id\":\"${esc(c.id)}\",\"name\":\"${esc(c.name)}\"}"
        })
        // Loans are exported without the ID photo, deliberately: a backup is
        // a file that gets copied around, and a picture of somebody's ID card
        // has no business travelling with it.
        sb.append("\n  ],\n  \"loans\": [\n")
        sb.append(loanState.value.joinToString(",\n") { l ->
            "    {\"book\":\"${esc(l.bookTitle)}\",\"member\":\"${esc(l.memberName)}\"," +
                "\"idNumber\":\"${esc(l.memberIdNumber)}\",\"status\":\"${l.status.name}\"," +
                "\"channel\":\"${l.channel.name}\"," +
                "\"issuedAt\":\"${LoanDates.format(l.issuedAt)}\"," +
                "\"dueAt\":\"${LoanDates.format(l.dueAt)}\"," +
                "\"returnedAt\":\"${LoanDates.format(l.returnedAt)}\"," +
                "\"renewals\":${l.renewals}}"
        })
        sb.append("\n  ]\n}\n")
        return sb.toString()
    }

    private companion object {
        const val BOOKS = "books"
        const val MEMBERS = "members"
        const val SHELVES = "shelves"
        const val CATEGORIES = "categories"
        const val FLOORS = "floors"
        const val ACTIVITY = "activity"
        const val ADMINS = "admins"
        const val USERS = "users"
        const val LOANS = "loans"
        const val META = "meta"
        const val SETUP_DOC = "setup"
        const val LOAN_POLICY_DOC = "loanPolicy"

        /** See [seedAll] for why this is 10 and not larger. */
        const val SEED_BATCH_SIZE = 10

        /** What "recently" means for the returned-this-month figure. */
        const val RECENT_WINDOW_MILLIS = 30L * 24L * 60L * 60L * 1000L
    }
}

object LibraryRepositoryProvider {

    @Volatile
    private var instance: LibraryRepository? = null

    /** Called from MainActivity, after Firebase has initialised. */
    fun init() {
        if (instance == null) instance = FirestoreLibraryRepository()
    }

    val repository: LibraryRepository
        get() = instance ?: FirestoreLibraryRepository().also { instance = it }
}

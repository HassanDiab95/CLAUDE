package com.wujha.admin.data

import java.util.Calendar
import java.util.Locale

/**
 * Dates for the borrowing cycle.
 *
 * Two things here are deliberate and worth the few lines they cost.
 *
 * **A due date is the end of a day, not an instant.** If a book is issued at
 * 11:40 on the 1st for fourteen days, it is due *on* the 15th — all of it,
 * until closing. Storing the moment of issue plus fourteen days would make
 * it late at 11:41 that morning, and a borrower who returns it that
 * afternoon would be told they are a day over. So [dueDate] winds the clock
 * to 23:59:59 of the final day.
 *
 * **Days are counted between calendar days, not in 24-hour blocks.** The
 * difference matters at the edges: Monday 23:00 to Tuesday 07:00 is eight
 * hours but one day late, and that is what a human means by "a day late".
 * [daysBetween] and [relativeDays] both work off midnight boundaries.
 *
 * Every formatted date is built with [Locale.US] on purpose, so a date is
 * written `2026-03-14` with Western digits on every device. The library's
 * own records — the date a book was catalogued, the date a membership began
 * — are written that way, and a mixture of digit shapes in one column is
 * the kind of detail that makes a report look wrong.
 */
object LoanDates {

    /** Now, in epoch milliseconds. */
    fun now(): Long = System.currentTimeMillis()

    /** Today as `YYYY-MM-DD`. */
    fun today(): String = format(now())

    /**
     * The end of the day [days] from [from] — what a due date is.
     *
     * `dueDate(14)` issued on the 1st returns the 15th at 23:59:59.
     */
    fun dueDate(days: Int, from: Long = now()): Long {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = from
            add(Calendar.DAY_OF_MONTH, days)
        }
        return endOfDay(calendar).timeInMillis
    }

    /**
     * A renewal's new due date.
     *
     * Extra days are added to the date it was already due, so a borrower who
     * renews early keeps the days they had not used yet. Once it is late
     * there is nothing left to keep, and the extension runs from today.
     */
    fun renewedDueDate(currentDueAt: Long, days: Int): Long {
        val base = if (currentDueAt > now()) currentDueAt else now()
        return dueDate(days, base)
    }

    /** `YYYY-MM-DD`, or an em dash for a date that was never set. */
    fun format(millis: Long): String {
        if (millis <= 0L) return "—"
        val calendar = Calendar.getInstance().apply { timeInMillis = millis }
        return String.format(
            Locale.US,
            "%04d-%02d-%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    /** `YYYY-MM-DD HH:mm`, for the audit lines that need the hour too. */
    fun formatWithTime(millis: Long): String {
        if (millis <= 0L) return "—"
        val calendar = Calendar.getInstance().apply { timeInMillis = millis }
        return String.format(
            Locale.US,
            "%04d-%02d-%02d %02d:%02d",
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH),
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE)
        )
    }

    /** Whole calendar days from [from] to [to]; never negative. */
    fun daysBetween(from: Long, to: Long): Int {
        if (from <= 0L || to <= 0L) return 0
        val start = startOfDay(from)
        val end = startOfDay(to)
        if (end <= start) return 0
        return ((end - start) / DAY_MILLIS).toInt()
    }

    /**
     * Days from today to [millis] — positive ahead, negative behind.
     *
     * A due date today returns 0, which is what "due today" has to read as.
     */
    fun relativeDays(millis: Long): Int {
        if (millis <= 0L) return 0
        val today = startOfDay(now())
        val target = startOfDay(millis)
        return ((target - today) / DAY_MILLIS).toInt()
    }

    /**
     * How late something is, in Arabic that counts properly.
     *
     * Arabic has three shapes for a count — one, two, and a number — and a
     * library screen that says «متأخرة 1 يوم» looks machine-made. Each shape
     * is its own sentence here so that each has its own English entry too.
     */
    fun overdueLabel(days: Int): String = when (days) {
        0, 1 -> t("متأخرة يوماً واحداً")
        2 -> t("متأخرة يومين")
        in 3..10 -> t("متأخرة %s أيام").format(days)
        else -> t("متأخرة %s يوماً").format(days)
    }

    /** How long is left, in the same three shapes. */
    fun remainingLabel(dueAt: Long): String {
        val days = relativeDays(dueAt)
        return when {
            days < 0 -> overdueLabel(-days)
            days == 0 -> t("تُستحق اليوم")
            days == 1 -> t("يبقى يوم واحد")
            days == 2 -> t("يبقى يومان")
            days <= 10 -> t("تبقّى %s أيام").format(days)
            else -> t("تبقّى %s يوماً").format(days)
        }
    }

    /** Midnight at the start of the day [millis] falls in. */
    private fun startOfDay(millis: Long): Long {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = millis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }

    private fun endOfDay(calendar: Calendar): Calendar = calendar.apply {
        set(Calendar.HOUR_OF_DAY, 23)
        set(Calendar.MINUTE, 59)
        set(Calendar.SECOND, 59)
        set(Calendar.MILLISECOND, 0)
    }

    private const val DAY_MILLIS = 24L * 60L * 60L * 1000L
}

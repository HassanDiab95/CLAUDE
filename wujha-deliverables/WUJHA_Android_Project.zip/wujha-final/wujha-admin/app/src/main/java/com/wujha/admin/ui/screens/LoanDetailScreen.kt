package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.AssignmentReturn
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ReportProblem
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.Catalogs
import com.wujha.admin.data.LoanDates
import com.wujha.admin.data.model.LoanChannel
import com.wujha.admin.data.model.LoanStatus
import com.wujha.admin.data.model.UserStatus
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.FilterChip
import com.wujha.admin.ui.components.FormErrorBanner
import com.wujha.admin.ui.components.IdPhotoView
import com.wujha.admin.ui.components.LoadingView
import com.wujha.admin.ui.components.LoanChannelChip
import com.wujha.admin.ui.components.LoanStatusBadge
import com.wujha.admin.ui.components.PrimaryButton
import com.wujha.admin.ui.components.SecondaryButton
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.AccentGoldDark
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackground
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenMid
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * One loan, with everything a librarian needs to move it along.
 *
 * The screen is ordered the way the decision is made: what is being
 * borrowed, who says they are borrowing it, the evidence for that claim,
 * the dates, and only then the buttons. The buttons offered are the ones
 * the loan's own status allows — there is no "return" on a request and no
 * "approve" on something already out — so the state machine is visible in
 * the interface rather than enforced by error messages after the fact.
 */
@Composable
fun LoanDetailScreen(
    loanId: String,
    repository: LibraryRepository,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val loans by repository.loans.collectAsState()
    val members by repository.members.collectAsState()
    val policy by repository.loanPolicy.collectAsState()

    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showReject by remember { mutableStateOf(false) }
    var showLost by remember { mutableStateOf(false) }
    var showRelease by remember { mutableStateOf(false) }

    val loan = loans.firstOrNull { it.id == loanId }
    if (loan == null) {
        LoadingView(
            message = t("جارٍ تحميل الإعارة..."),
            modifier = Modifier.background(CreamBackground)
        )
        return
    }

    // `members` is read above so this recomposes when a membership is created
    // by the approval, or suspended from the button at the bottom.
    val member = remember(loan, members) { repository.memberFor(loan) }
    val book = repository.getBook(loan.bookId)

    /** Runs one repository call, keeping the screen honest while it does. */
    fun act(block: suspend () -> String?) {
        if (busy) return
        busy = true
        error = null
        scope.launch {
            error = block()
            busy = false
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Outlined.ArrowForward, contentDescription = t("رجوع"), tint = TextPrimary)
                }
                Text(
                    text = t("تفاصيل الإعارة"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                )
                LoanStatusBadge(loan = loan, modifier = Modifier.padding(end = 8.dp))
            }
        }

        // ---- What is being borrowed -------------------------------------
        item {
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Outlined.MenuBook,
                        contentDescription = null,
                        tint = ForestGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = loan.bookTitle,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    LoanChannelChip(channel = loan.channel)
                }
                Spacer(Modifier.height(8.dp))
                InfoLine(t("الرقم التسلسلي"), loan.bookSerial.ifBlank { "—" })
                InfoLine(t("الرف"), loan.bookShelf.ifBlank { t("غير محدد") })
                if (book != null) {
                    InfoLine(
                        t("النسخ"),
                        t("%s متاحة من %s").format(book.availableCopies, book.copies)
                    )
                } else {
                    InfoLine(t("النسخ"), t("الكتاب غير موجود في الفهرس حالياً"))
                }
            }
        }

        // ---- Who is borrowing it ----------------------------------------
        item {
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Outlined.Person,
                        contentDescription = null,
                        tint = ForestGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = loan.memberName.ifBlank { t("بلا اسم") },
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                }
                Spacer(Modifier.height(8.dp))
                InfoLine(t("رقم الهوية"), loan.memberIdNumber.ifBlank { "—" })
                InfoLine(t("رقم الجوال"), loan.memberPhone.ifBlank { "—" })
                InfoLine(
                    t("العضوية"),
                    when {
                        member == null -> t("غير مسجّلة — ستُنشأ عند الموافقة")
                        member.status == UserStatus.SUSPENDED -> t("موقوفة")
                        else -> t("نشطة") + member.memberType.let { if (it.isBlank()) "" else " • ${t(it)}" }
                    }
                )
                if (member != null) {
                    val open = repository.loansForMember(member).count { it.holdsCopy }
                    InfoLine(
                        t("إعارات مفتوحة"),
                        t("%s من %s").format(open, policy.maxActivePerMember)
                    )
                }
            }
        }

        // ---- The evidence -----------------------------------------------
        // Shown for anything that came from the app, even when no photo was
        // attached: "no photo" is itself something the librarian has to see
        // before deciding, not an empty space where a card should be.
        if (loan.channel == LoanChannel.APP || loan.idPhotoBase64.isNotBlank()) {
            item {
                Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Outlined.Badge,
                            contentDescription = null,
                            tint = ForestGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = t("مراجعة الهوية"),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        if (loan.idVerified) {
                            Icon(
                                Icons.Outlined.CheckCircle,
                                contentDescription = t("مؤكَّدة"),
                                tint = ForestGreenMid,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = t("قارن الاسم ورقم الهوية المكتوبين أعلاه بالصورة المرفقة، ثم أكّد المطابقة."),
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                    Spacer(Modifier.height(10.dp))

                    if (loan.status.isOpen || loan.idPhotoBase64.isNotBlank()) {
                        IdPhotoView(base64 = loan.idPhotoBase64)
                        Spacer(Modifier.height(10.dp))
                    } else {
                        // Closed loans keep no photo: see the note in Loan.
                        Text(
                            text = t("حُذفت صورة الهوية تلقائياً بعد إغلاق الإعارة."),
                            color = TextSecondary,
                            fontSize = 11.5.sp
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    if (loan.idVerified) {
                        Text(
                            text = t("أكّد المطابقة: %s").format(loan.idVerifiedBy.ifBlank { "—" }),
                            color = ForestGreenMid,
                            fontSize = 12.sp
                        )
                        if (loan.status == LoanStatus.REQUESTED) {
                            Spacer(Modifier.height(8.dp))
                            SecondaryButton(
                                text = t("إلغاء تأكيد المطابقة"),
                                onClick = { act { repository.setIdVerified(loan, false) } },
                                enabled = !busy
                            )
                        }
                    } else if (loan.status == LoanStatus.REQUESTED) {
                        PrimaryButton(
                            text = t("الهوية مطابقة"),
                            onClick = { act { repository.setIdVerified(loan, true) } },
                            loading = busy
                        )
                    } else {
                        Text(
                            text = t("لم تُؤكَّد مطابقة الهوية."),
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // ---- The dates ---------------------------------------------------
        item {
            Card {
                Text(
                    text = t("المواعيد"),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = TextPrimary
                )
                Spacer(Modifier.height(8.dp))
                InfoLine(t("تاريخ الطلب"), LoanDates.format(loan.requestedAt))
                if (loan.decidedAt > 0L) {
                    InfoLine(t("تاريخ القرار"), LoanDates.format(loan.decidedAt))
                }
                if (loan.status == LoanStatus.APPROVED) {
                    val deadline = LoanDates.dueDate(policy.pickupWindowDays, loan.decidedAt)
                    InfoLine(
                        t("آخر موعد للاستلام"),
                        "${LoanDates.format(deadline)} • ${LoanDates.remainingLabel(deadline)}"
                    )
                }
                if (loan.issuedAt > 0L) {
                    InfoLine(t("تاريخ التسليم"), LoanDates.format(loan.issuedAt))
                }
                if (loan.dueAt > 0L) {
                    InfoLine(
                        label = t("تاريخ الإرجاع"),
                        value = LoanDates.format(loan.dueAt),
                        valueColor = if (loan.isOverdue) SignalRed else TextPrimary
                    )
                }
                if (loan.returnedAt > 0L) {
                    InfoLine(
                        t(if (loan.status == LoanStatus.LOST) "تاريخ تسجيل الفقدان" else "تاريخ الإرجاع الفعلي"),
                        LoanDates.format(loan.returnedAt)
                    )
                }
                InfoLine(
                    t("التجديدات"),
                    t("%s من %s").format(loan.renewals, policy.maxRenewals)
                )
                if (loan.status == LoanStatus.ACTIVE) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = LoanDates.remainingLabel(loan.dueAt),
                        color = if (loan.isOverdue) SignalRed else ForestGreenMid,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        if (loan.rejectReason.isNotBlank()) {
            item {
                Card {
                    Text(
                        text = t(if (loan.status == LoanStatus.REJECTED) "سبب الرفض" else "سبب الإلغاء"),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(text = loan.rejectReason, color = TextSecondary, fontSize = 13.sp)
                }
            }
        }

        if (loan.notes.isNotBlank()) {
            item {
                Card {
                    Text(
                        text = t("ملاحظات"),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(text = loan.notes, color = TextSecondary, fontSize = 13.sp)
                }
            }
        }

        // ---- A renewal waiting for an answer ----------------------------
        if (loan.renewRequested && loan.status == LoanStatus.ACTIVE) {
            item {
                Card(tint = AccentGoldDark) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Outlined.Autorenew,
                            contentDescription = null,
                            tint = AccentGoldDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = t("طلب المستعير تجديد المدة"),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = t("التجديد يضيف %s يوماً إلى تاريخ الإرجاع.").format(policy.renewDays),
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    PrimaryButton(
                        text = t("قبول التجديد"),
                        onClick = { act { repository.renewLoan(loan) } },
                        loading = busy
                    )
                    Spacer(Modifier.height(8.dp))
                    SecondaryButton(
                        text = t("رفض التجديد"),
                        onClick = { act { repository.declineRenewal(loan) } },
                        enabled = !busy
                    )
                }
            }
        }

        // ---- A loan late enough to act on the membership ----------------
        if (loan.isOverdue && member != null && loan.daysLate >= policy.overdueSuspendDays) {
            item {
                Card(tint = SignalRed) {
                    Text(
                        text = LoanDates.overdueLabel(loan.daysLate),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = SignalRed
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = t("تجاوز التأخير %s يوماً، وهو الحد الذي تُوقف عنده العضوية في إعدادات الإعارة.")
                            .format(policy.overdueSuspendDays),
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    if (member.status == UserStatus.ACTIVE) {
                        Spacer(Modifier.height(10.dp))
                        DangerButton(
                            text = t("إيقاف عضوية %s").format(member.name),
                            icon = Icons.Outlined.ReportProblem,
                            onClick = { act { repository.toggleMemberStatus(member) } },
                            enabled = !busy
                        )
                    } else {
                        Spacer(Modifier.height(6.dp))
                        Text(text = t("العضوية موقوفة بالفعل."), color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }

        // ---- The actions the status allows ------------------------------
        val currentError = error
        if (currentError != null) {
            item {
                FormErrorBanner(
                    message = currentError,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                )
            }
        }

        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                when (loan.status) {
                    LoanStatus.REQUESTED -> {
                        PrimaryButton(
                            text = t("موافقة وحجز نسخة"),
                            onClick = { act { repository.approveRequest(loan) } },
                            loading = busy
                        )
                        Spacer(Modifier.height(10.dp))
                        DangerButton(
                            text = t("رفض الطلب"),
                            icon = Icons.Outlined.ReportProblem,
                            onClick = { showReject = true },
                            enabled = !busy
                        )
                    }

                    LoanStatus.APPROVED -> {
                        PrimaryButton(
                            text = t("تسليم الكتاب للمستعير"),
                            onClick = { act { repository.issueLoan(loan) } },
                            loading = busy
                        )
                        Spacer(Modifier.height(10.dp))
                        SecondaryButton(
                            text = t("إلغاء الحجز وإرجاع النسخة للرف"),
                            onClick = { showRelease = true },
                            enabled = !busy
                        )
                    }

                    LoanStatus.ACTIVE -> {
                        PrimaryButton(
                            text = t("استرجاع الكتاب"),
                            onClick = { act { repository.returnLoan(loan) } },
                            loading = busy
                        )
                        Spacer(Modifier.height(10.dp))
                        SecondaryButton(
                            text = t("تجديد المدة %s يوماً").format(policy.renewDays),
                            onClick = { act { repository.renewLoan(loan) } },
                            leadingIcon = Icons.Outlined.Autorenew,
                            iconTint = ForestGreenMid,
                            enabled = !busy && loan.renewals < policy.maxRenewals && !loan.isOverdue
                        )
                        Spacer(Modifier.height(10.dp))
                        DangerButton(
                            text = t("تسجيل النسخة كمفقودة"),
                            icon = Icons.Outlined.ReportProblem,
                            onClick = { showLost = true },
                            enabled = !busy
                        )
                    }

                    LoanStatus.RETURNED, LoanStatus.REJECTED,
                    LoanStatus.CANCELLED, LoanStatus.LOST -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Outlined.AssignmentReturn,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = t("هذه الإعارة مغلقة، ولا توجد إجراءات عليها."),
                                color = TextSecondary,
                                fontSize = 12.5.sp
                            )
                        }
                    }
                }
            }
        }

        // ---- Who did what ------------------------------------------------
        item {
            Column(modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp)) {
                if (loan.decidedBy.isNotBlank()) {
                    AuditLine(t("قرار الطلب"), loan.decidedBy)
                }
                if (loan.issuedBy.isNotBlank()) {
                    AuditLine(t("سلّم النسخة"), loan.issuedBy)
                }
                if (loan.returnedBy.isNotBlank()) {
                    AuditLine(t("أغلق الإعارة"), loan.returnedBy)
                }
            }
        }
    }

    if (showReject) {
        ReasonDialog(
            title = t("رفض طلب الإعارة"),
            detail = t("سيظهر السبب لمقدّم الطلب في تطبيق الزائر."),
            options = Catalogs.rejectReasons,
            confirmLabel = t("رفض الطلب"),
            onDismiss = { showReject = false },
            onConfirm = { reason ->
                showReject = false
                act { repository.rejectRequest(loan, reason) }
            }
        )
    }

    if (showRelease) {
        ReasonDialog(
            title = t("إلغاء حجز النسخة"),
            detail = t("ستعود النسخة متاحة للإعارة فوراً."),
            options = Catalogs.releaseReasons,
            confirmLabel = t("إلغاء الحجز"),
            onDismiss = { showRelease = false },
            onConfirm = { reason ->
                showRelease = false
                act { repository.releaseHold(loan, reason) }
            }
        )
    }

    if (showLost) {
        ReasonDialog(
            title = t("تسجيل النسخة كمفقودة"),
            detail = t("ستخرج النسخة من دائرة الإعارة. عدّل عدد النسخ من صفحة الكتاب إن شُطبت نهائياً."),
            options = Catalogs.lostReasons,
            confirmLabel = t("تسجيل الفقدان"),
            onDismiss = { showLost = false },
            onConfirm = { note ->
                showLost = false
                act { repository.markLoanLost(loan, note) }
            }
        )
    }
}

/**
 * A dialog that asks for a reason and will not take silence for an answer.
 *
 * The chips are the five or six reasons that cover almost every case, and
 * the box underneath is there for the one that does not. Either way
 * something is written down, because a refusal with no reason is the thing
 * the borrower then has to come and ask about.
 */
@Composable
private fun ReasonDialog(
    title: String,
    detail: String,
    options: List<String>,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var picked by remember { mutableStateOf("") }
    var typed by remember { mutableStateOf("") }
    val reason = typed.trim().ifBlank { picked }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = { Text(title, fontWeight = FontWeight.Bold, color = TextPrimary) },
        text = {
            Column {
                Text(detail, color = TextSecondary, fontSize = 12.5.sp)
                Spacer(Modifier.height(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    options.forEach { option ->
                        FilterChip(
                            label = t(option),
                            selected = picked == option && typed.isBlank(),
                            onClick = { picked = option; typed = "" }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                WujhaTextField(
                    value = typed,
                    onValueChange = { typed = it },
                    placeholder = t("أو اكتب سبباً آخر"),
                    singleLine = false,
                    fieldHeight = 70
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (reason.isNotBlank()) onConfirm(reason) },
                enabled = reason.isNotBlank()
            ) {
                Text(confirmLabel, color = SignalRed, fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(t("إلغاء"), color = TextSecondary) }
        }
    )
}

/** The white card every section on this screen sits in. */
@Composable
private fun Card(tint: Color? = null, content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        color = if (tint == null) SurfaceWhite else tint.copy(alpha = 0.07f),
        border = BorderStroke(1.dp, if (tint == null) BorderLight else tint.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun InfoLine(
    label: String,
    value: String,
    valueColor: Color = TextPrimary
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 12.sp)
        Text(value, color = valueColor, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun AuditLine(label: String, who: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text("$label: ", color = TextSecondary, fontSize = 11.sp)
        Text(who, color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

/** A bordered button for something that cannot be undone. */
@Composable
private fun DangerButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, SignalRed.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = SignalRed, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(text = text, color = SignalRed, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
        }
    }
}

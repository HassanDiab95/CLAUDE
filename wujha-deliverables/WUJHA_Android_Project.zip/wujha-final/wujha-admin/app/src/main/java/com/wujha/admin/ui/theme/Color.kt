package com.wujha.admin.ui.theme

import androidx.compose.ui.graphics.Color

// =========================================================================
// The WUJHA palette.
//
// Every colour is a getter, not a constant: it answers with the light or the
// dark value depending on [WujhaThemeState.isDark]. That flag is Compose
// state, so switching the appearance recolours every screen at once, and no
// call site had to change.
//
// The ten values in the first block are the brand sheet, exactly as issued.
// Everything below them is derived from those ten — a tint, a shade, or an
// alias — so no screen can drift into a colour the brand does not own.
//
// The single exception is [SignalRed], documented where it is defined.
// =========================================================================

/** #1F4E46 — primary surfaces, buttons, headings. */
val ForestGreen: Color get() = if (WujhaThemeState.isDark) Color(0xFF8CC5B0) else Color(0xFF1F4E46)

/** #2F6B5B — icons and interactive accents. */
val ForestGreenMid: Color get() = if (WujhaThemeState.isDark) Color(0xFF7DBBA2) else Color(0xFF2F6B5B)

/** #A7C9B1 — soft fills and active states. */
val ForestGreenLight: Color get() = if (WujhaThemeState.isDark) Color(0xFF2F5A4E) else Color(0xFFA7C9B1)

/** #B08D5E — secondary icons, the map pin, highlights. */
val AccentGold: Color get() = if (WujhaThemeState.isDark) Color(0xFFD4B486) else Color(0xFFB08D5E)

/** #D9C9B2 — card backgrounds and interface furniture. */
val BeigeSurface: Color get() = if (WujhaThemeState.isDark) Color(0xFF3A342B) else Color(0xFFD9C9B2)

/** #F7F5EE — the page background. */
val CreamBackground: Color get() = if (WujhaThemeState.isDark) Color(0xFF111816) else Color(0xFFF7F5EE)

/** #FFFFFF — cards, raised surfaces, text on dark. */
val SurfaceWhite: Color get() = if (WujhaThemeState.isDark) Color(0xFF1A2320) else Color(0xFFFFFFFF)

/** #2E3A36 — body and heading text. */
val TextPrimary: Color get() = if (WujhaThemeState.isDark) Color(0xFFE9E6DD) else Color(0xFF2E3A36)

/** #8B8B8B — secondary text and inactive icons. */
val TextSecondary: Color get() = if (WujhaThemeState.isDark) Color(0xFFA3ADA8) else Color(0xFF8B8B8B)

/** #EDE7D9 — secondary backgrounds. */
val CreamBackgroundAlt: Color get() = if (WujhaThemeState.isDark) Color(0xFF212C28) else Color(0xFFEDE7D9)

// -------------------------------------------------------------------------
// Derived
// -------------------------------------------------------------------------

/** The deepest green, for pressed states and the gradient behind the logo. */
val ForestGreenDark: Color get() = if (WujhaThemeState.isDark) Color(0xFF0C211C) else Color(0xFF16382F)

/**
 * [ForestGreenLight] thinned to a wash. Over cream it lands on a pale mint
 * that a green icon still reads clearly against — which the full-strength
 * colour does not.
 */
val ForestGreenWash: Color get() = ForestGreenLight.copy(alpha = 0.30f)

/** [AccentGold] thinned the same way, for gold-tinted panels. */
val AccentGoldWash: Color get() = AccentGold.copy(alpha = 0.14f)

/** A shade of [AccentGold] for pressed gold controls. */
val AccentGoldDark: Color get() = if (WujhaThemeState.isDark) Color(0xFFE3C79C) else Color(0xFF8E7048)

/** Alias kept so older call sites keep compiling; it is the light beige. */
val AccentGoldLight: Color get() = CreamBackgroundAlt

/** Text and icons on a filled brand-green control. */
val TextOnPrimary: Color get() = SurfaceWhite

/**
 * Text laid over the library photograph on the opening and sign-in screens.
 *
 * The photograph is washed with cream rather than green, because the logo is
 * dark artwork and needs a light ground to read on — so the text over it is
 * the ordinary dark pair, not a light one.
 */
val TextOnBackdrop: Color get() = TextPrimary
val TextOnBackdropMuted: Color get() = if (WujhaThemeState.isDark) Color(0xB3E9E6DD) else Color(0xB32E3A36)

/** Hairlines and card borders: the beige at low strength. */
val BorderLight: Color get() = if (WujhaThemeState.isDark) Color(0xFF2F3B37) else Color(0xFFE3DCCC)
val DividerLight: Color get() = CreamBackgroundAlt

// -------------------------------------------------------------------------
// Status
// -------------------------------------------------------------------------

val StatusAvailableBg: Color get() = ForestGreenWash
val StatusAvailableText: Color get() = ForestGreenMid

val StatusBorrowedBg: Color get() = AccentGoldWash
val StatusBorrowedText: Color get() = AccentGoldDark

/**
 * The one colour outside the brand sheet.
 *
 * Destructive actions and errors need to be unmistakable, and the sheet has
 * no warm-danger hue: using the gold for "delete" and for "borrowed" would
 * make the two read the same. This is deliberately muted so it sits beside
 * the palette rather than shouting over it.
 */
val SignalRed: Color get() = if (WujhaThemeState.isDark) Color(0xFFE58A7E) else Color(0xFFB2483C)

val StatusLostBg: Color get() = if (WujhaThemeState.isDark) Color(0x26E58A7E) else Color(0x1AB2483C)
val StatusLostText: Color get() = SignalRed

val StatusActiveDot: Color get() = ForestGreenMid
val StatusSuspendedDot: Color get() = SignalRed

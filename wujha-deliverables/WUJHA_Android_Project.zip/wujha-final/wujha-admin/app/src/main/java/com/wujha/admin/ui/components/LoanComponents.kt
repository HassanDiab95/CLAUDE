package com.wujha.admin.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PendingActions
import androidx.compose.material.icons.outlined.ReportProblem
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.LoanDates
import com.wujha.admin.data.model.Loan
import com.wujha.admin.data.model.LoanChannel
import com.wujha.admin.data.model.LoanStatus
import com.wujha.admin.data.storage.ImageCodec
import com.wujha.admin.data.t
import com.wujha.admin.ui.theme.AccentGoldDark
import com.wujha.admin.ui.theme.AccentGoldWash
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackgroundAlt
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenMid
import com.wujha.admin.ui.theme.ForestGreenWash
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.StatusLostBg
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

/**
 * How a loan looks: its colours, its icon, and the word on its badge.
 *
 * Overdue is handled here rather than in [LoanStatus] because it is not a
 * status — it is an active loan whose due date has passed. Pushing it into
 * the appearance layer means every list, badge and card reports lateness the
 * same way without anyone having to remember to check for it.
 */
private data class LoanLook(
    val label: String,
    val background: Color,
    val foreground: Color,
    val icon: ImageVector
)

@Composable
private fun lookOf(loan: Loan): LoanLook = when {
    loan.isOverdue -> LoanLook(
        label = t("متأخرة"),
        background = StatusLostBg,
        foreground = SignalRed,
        icon = Icons.Outlined.ReportProblem
    )

    loan.status == LoanStatus.REQUESTED -> LoanLook(
        label = t(loan.status.labelAr),
        background = AccentGoldWash,
        foreground = AccentGoldDark,
        icon = Icons.Outlined.PendingActions
    )

    loan.status == LoanStatus.APPROVED -> LoanLook(
        label = t(loan.status.labelAr),
        background = ForestGreenWash,
        foreground = ForestGreenMid,
        icon = Icons.Outlined.Schedule
    )

    loan.status == LoanStatus.ACTIVE -> LoanLook(
        label = t(loan.status.labelAr),
        background = ForestGreen.copy(alpha = 0.12f),
        foreground = ForestGreen,
        icon = Icons.Outlined.MenuBook
    )

    loan.status == LoanStatus.RETURNED -> LoanLook(
        label = t(loan.status.labelAr),
        background = CreamBackgroundAlt,
        foreground = TextSecondary,
        icon = Icons.Outlined.CheckCircle
    )

    loan.status == LoanStatus.LOST || loan.status == LoanStatus.REJECTED -> LoanLook(
        label = t(loan.status.labelAr),
        background = StatusLostBg,
        foreground = SignalRed,
        icon = Icons.Outlined.ReportProblem
    )

    else -> LoanLook(
        label = t(loan.status.labelAr),
        background = CreamBackgroundAlt,
        foreground = TextSecondary,
        icon = Icons.Outlined.Schedule
    )
}

/** The pill that says where a loan has got to. */
@Composable
fun LoanStatusBadge(loan: Loan, modifier: Modifier = Modifier) {
    val look = lookOf(loan)
    Surface(modifier = modifier, shape = RoundedCornerShape(20.dp), color = look.background) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(look.icon, contentDescription = null, tint = look.foreground, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(5.dp))
            Text(
                text = look.label,
                color = look.foreground,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/**
 * The due date in words — how late, or how long is left.
 *
 * Only shown for a loan that is actually out: a returned book has a due date
 * in its history, but counting days against it would read as a complaint
 * about something that has already been settled.
 */
@Composable
fun LoanDueChip(loan: Loan, modifier: Modifier = Modifier) {
    if (loan.status != LoanStatus.ACTIVE || loan.dueAt <= 0L) return
    val overdue = loan.isOverdue
    Text(
        text = LoanDates.remainingLabel(loan.dueAt),
        color = if (overdue) SignalRed else TextSecondary,
        fontSize = 11.sp,
        fontWeight = if (overdue) FontWeight.SemiBold else FontWeight.Normal,
        modifier = modifier
    )
}

/** Where the loan came from: the app, or the desk. */
@Composable
fun LoanChannelChip(channel: LoanChannel, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(8.dp), color = CreamBackgroundAlt) {
        Text(
            text = t(channel.labelAr),
            color = TextSecondary,
            fontSize = 10.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

/**
 * One loan in a list: the title, who has it, and where it has got to.
 *
 * The two flags on the right are the ones a librarian scans for — a renewal
 * waiting to be answered, and a request whose ID photo has not been checked
 * yet — so they are marks on the row rather than something you find by
 * opening it.
 */
@Composable
fun LoanRow(loan: Loan, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val look = lookOf(loan)
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape).background(look.background),
                contentAlignment = Alignment.Center
            ) {
                Icon(look.icon, contentDescription = null, tint = look.foreground, modifier = Modifier.size(19.dp))
            }

            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    text = loan.bookTitle,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = loan.borrowerLabel,
                    fontSize = 11.5.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LoanDueChip(loan)
                    if (loan.status == LoanStatus.APPROVED && loan.decidedAt > 0L) {
                        Text(
                            text = t("وافق عليها %s").format(LoanDates.format(loan.decidedAt)),
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    if (loan.status == LoanStatus.REQUESTED && loan.requestedAt > 0L) {
                        Text(
                            text = LoanDates.format(loan.requestedAt),
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                LoanStatusBadge(loan)
                Spacer(Modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    if (loan.renewRequested) {
                        FlagDot(Icons.Outlined.Autorenew, AccentGoldDark, t("طلب تجديد"))
                    }
                    if (loan.status == LoanStatus.REQUESTED && loan.idPhotoBase64.isNotBlank() && !loan.idVerified) {
                        FlagDot(Icons.Outlined.Badge, ForestGreenMid, t("صورة هوية للمراجعة"))
                    }
                }
            }
        }
    }
}

@Composable
private fun FlagDot(icon: ImageVector, tint: Color, label: String) {
    Box(
        modifier = Modifier.size(22.dp).clip(CircleShape).background(tint.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(13.dp))
    }
}

/**
 * The photo of the ID card, as large as the card it is drawn on allows.
 *
 * A librarian is being asked to compare a name and a ten-digit number
 * against this, so it is shown at a readable size rather than as a
 * thumbnail, and it keeps the aspect ratio of an ID card.
 */
@Composable
fun IdPhotoView(base64: String, modifier: Modifier = Modifier) {
    val bitmap = remember(base64) { ImageCodec.decode(base64) }
    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1.58f)
            .clip(RoundedCornerShape(12.dp))
            .background(CreamBackgroundAlt),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = t("صورة الهوية"),
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Outlined.Badge,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(Modifier.height(6.dp))
                Text(t("لا توجد صورة هوية مرفقة"), color = TextSecondary, fontSize = 11.5.sp)
            }
        }
    }
}

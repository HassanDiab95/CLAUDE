package com.wujha.admin.data.model

import com.wujha.admin.data.LoanDates

/**
 * Where a loan has reached in its life.
 *
 * The order below is the order things happen in, and the whole borrowing
 * cycle is these seven values and nothing else:
 *
 * ```
 *                    ┌──────────► REJECTED   (الهوية غير مطابقة، لا نسخة متاحة…)
 *                    │
 *  REQUESTED ────────┼──────────► CANCELLED  (ألغاه الزائر قبل الموافقة)
 *  (من التطبيق)      │
 *                    ▼
 *                 APPROVED ─────► CANCELLED  (لم يَحضُر لاستلامه، فأُفرجت النسخة)
 *          (نسخة محجوزة باسمه)
 *                    │
 *                    ▼
 *                  ACTIVE ──────► RETURNED   (أعادها)
 *          (بيده، ولها تاريخ      └────────► LOST       (أعلن فقدانها)
 *             إرجاع)
 * ```
 *
 * A desk loan — one a librarian records for someone standing in front of her
 * — starts at [ACTIVE] directly, because the book and the person are both
 * already there. Nothing else changes: the same row, the same due date, the
 * same return.
 *
 * There is deliberately no `OVERDUE` value. Being late is not a state
 * somebody has to remember to set: it is [ACTIVE] plus a due date in the
 * past, which [Loan.isOverdue] works out on the spot. A stored flag would
 * need a server to flip it at midnight, and this project has no server — so
 * a loan that falls due while nobody is looking is still, correctly, late.
 */
enum class LoanStatus(val labelAr: String) {
    REQUESTED("قيد المراجعة"),
    APPROVED("بانتظار الاستلام"),
    ACTIVE("مُعارة"),
    RETURNED("أُعيدت"),
    REJECTED("مرفوضة"),
    CANCELLED("ملغاة"),
    LOST("مفقودة");

    /** True while the loan is still something the library has to act on. */
    val isOpen: Boolean get() = this == REQUESTED || this == APPROVED || this == ACTIVE

    /**
     * True when a copy is off the shelf because of this loan.
     *
     * This is the single rule behind availability: a copy is unavailable from
     * the moment a request is approved — not when it is handed over — so two
     * people cannot both be promised the last copy.
     */
    val holdsCopy: Boolean get() = this == APPROVED || this == ACTIVE

    companion object {
        fun from(raw: String?): LoanStatus = entries.firstOrNull { it.name == raw } ?: REQUESTED
    }
}

/** How the loan reached the library. */
enum class LoanChannel(val labelAr: String) {
    /** The visitor asked from the app and attached a photo of their ID. */
    APP("من تطبيق الزائر"),

    /** The librarian recorded it at the desk, card in hand. */
    DESK("من مكتب الاستعارة");

    companion object {
        fun from(raw: String?): LoanChannel = entries.firstOrNull { it.name == raw } ?: APP
    }
}

/**
 * One borrowing, in the `loans` collection.
 *
 * The book and the member are referenced by id **and** copied in by name,
 * serial and ID number. That duplication is on purpose: a loan is a record
 * of something that happened, and it has to keep reading correctly a year
 * later even if the book was re-catalogued or the membership deleted. The
 * ids are what the app joins on; the copied text is what the history shows.
 *
 * [idPhotoBase64] is the photo of the ID card the visitor attaches to a
 * request, so a librarian can check the name and number against a real card
 * before approving. It is held on this document as Base64 — the same
 * approach as book covers, so the project still needs no Storage bucket —
 * and it is **erased the moment the loan ends**: nobody needs a picture of
 * somebody's ID card to know that a book came back.
 *
 * Every time is epoch milliseconds, written by the device that made the
 * change rather than by a server timestamp. A due date is a date a librarian
 * reads out loud and counts days against, and `serverTimestamp()` resolves
 * to null locally for a moment after the write — long enough for a due date
 * to appear blank on the screen of the person who just set it.
 */
data class Loan(
    val id: String = "",

    // ---- What was borrowed (id to join on, text to keep) ---------------
    val bookId: String = "",
    val bookTitle: String = "",
    val bookSerial: String = "",
    val bookShelf: String = "",

    // ---- Who borrowed it ----------------------------------------------
    /** The membership this loan belongs to, once one has been matched. */
    val memberId: String = "",
    val memberName: String = "",
    /** The number on the card — how a librarian finds the person. */
    val memberIdNumber: String = "",
    val memberPhone: String = "",
    /** The app account that asked, when the request came from the app. */
    val requesterUid: String = "",

    val status: LoanStatus = LoanStatus.REQUESTED,
    val channel: LoanChannel = LoanChannel.APP,

    // ---- ID verification ----------------------------------------------
    /** Base64 JPEG of the ID card. Empty once the loan has ended. */
    val idPhotoBase64: String = "",
    /** Set when a librarian confirmed the card matches the typed details. */
    val idVerified: Boolean = false,
    val idVerifiedBy: String = "",

    // ---- The dates ----------------------------------------------------
    val requestedAt: Long = 0L,
    /** When the request was approved or rejected. */
    val decidedAt: Long = 0L,
    /** When the book was actually handed over. */
    val issuedAt: Long = 0L,
    /** When it is due back — end of that day, not the moment of issue. */
    val dueAt: Long = 0L,
    val returnedAt: Long = 0L,

    // ---- Renewal ------------------------------------------------------
    val renewals: Int = 0,
    /** The borrower asked for more time; the librarian has not answered yet. */
    val renewRequested: Boolean = false,

    // ---- Who did what -------------------------------------------------
    val decidedBy: String = "",
    val issuedBy: String = "",
    val returnedBy: String = "",

    val rejectReason: String = "",
    val notes: String = ""
) {
    /** Late only while it is still out: a returned book is never overdue. */
    val isOverdue: Boolean
        get() = status == LoanStatus.ACTIVE && dueAt > 0L && LoanDates.now() > dueAt

    /** Days past the due date, 0 when not overdue. */
    val daysLate: Int
        get() = if (isOverdue) LoanDates.daysBetween(dueAt, LoanDates.now()) else 0

    /** Days left before it falls due; negative once it is late. */
    val daysLeft: Int
        get() = if (dueAt <= 0L) 0 else LoanDates.relativeDays(dueAt)

    /** Due within the next three days and not yet late. */
    val isDueSoon: Boolean
        get() = status == LoanStatus.ACTIVE && !isOverdue && dueAt > 0L && daysLeft <= 3

    /** True when this loan is holding a copy off the shelf. */
    val holdsCopy: Boolean get() = status.holdsCopy

    /** Shown wherever the borrower needs one line of identity. */
    val borrowerLabel: String
        get() = memberName.ifBlank { memberIdNumber }.ifBlank { "—" }

    /**
     * When this loan was last moved along — what every list sorts on.
     *
     * Using the latest of the four stamps rather than the request date keeps
     * a loan that was just returned at the top of the history, where the
     * librarian who returned it expects to find it.
     */
    val sortKey: Long
        get() = maxOf(requestedAt, decidedAt, issuedAt, returnedAt)

    fun toMap(): Map<String, Any> = mapOf(
        "bookId" to bookId,
        "bookTitle" to bookTitle,
        "bookSerial" to bookSerial,
        "bookShelf" to bookShelf,
        "memberId" to memberId,
        "memberName" to memberName,
        "memberIdNumber" to memberIdNumber,
        "memberPhone" to memberPhone,
        "requesterUid" to requesterUid,
        "status" to status.name,
        "channel" to channel.name,
        "idPhotoBase64" to idPhotoBase64,
        "idVerified" to idVerified,
        "idVerifiedBy" to idVerifiedBy,
        "requestedAt" to requestedAt,
        "decidedAt" to decidedAt,
        "issuedAt" to issuedAt,
        "dueAt" to dueAt,
        "returnedAt" to returnedAt,
        "renewals" to renewals,
        "renewRequested" to renewRequested,
        "decidedBy" to decidedBy,
        "issuedBy" to issuedBy,
        "returnedBy" to returnedBy,
        "rejectReason" to rejectReason,
        "notes" to notes
    )
}

/**
 * The library's borrowing rules, in `meta/loanPolicy`.
 *
 * These are kept in the database rather than in the code because they are
 * the librarian's decision, not the programmer's: a library that lends for
 * three weeks should not need a new version of the app to say so. The
 * values below are what a brand-new database starts with, and what the app
 * falls back to if the document has not been written yet.
 */
data class LoanPolicy(
    /** How long a loan runs, in days. */
    val loanDays: Int = 14,
    /** How many times one loan may be extended. */
    val maxRenewals: Int = 1,
    /** Days added by one renewal. */
    val renewDays: Int = 7,
    /** How many loans one member may have out at once. */
    val maxActivePerMember: Int = 3,
    /** How long an approved copy is held before the hold is dropped. */
    val pickupWindowDays: Int = 3,
    /** Whether a request from the app must carry a photo of the ID card. */
    val requireIdPhoto: Boolean = true,
    /** Days overdue after which the app suggests suspending the membership. */
    val overdueSuspendDays: Int = 14
) {
    fun toMap(): Map<String, Any> = mapOf(
        "loanDays" to loanDays,
        "maxRenewals" to maxRenewals,
        "renewDays" to renewDays,
        "maxActivePerMember" to maxActivePerMember,
        "pickupWindowDays" to pickupWindowDays,
        "requireIdPhoto" to requireIdPhoto,
        "overdueSuspendDays" to overdueSuspendDays
    )

    companion object {
        val DEFAULT = LoanPolicy()

        /** Reads the stored policy, falling back field by field. */
        fun from(
            loanDays: Long?,
            maxRenewals: Long?,
            renewDays: Long?,
            maxActivePerMember: Long?,
            pickupWindowDays: Long?,
            requireIdPhoto: Boolean?,
            overdueSuspendDays: Long?
        ): LoanPolicy = LoanPolicy(
            loanDays = loanDays?.toInt()?.takeIf { it > 0 } ?: DEFAULT.loanDays,
            maxRenewals = maxRenewals?.toInt()?.coerceAtLeast(0) ?: DEFAULT.maxRenewals,
            renewDays = renewDays?.toInt()?.takeIf { it > 0 } ?: DEFAULT.renewDays,
            maxActivePerMember = maxActivePerMember?.toInt()?.takeIf { it > 0 }
                ?: DEFAULT.maxActivePerMember,
            pickupWindowDays = pickupWindowDays?.toInt()?.takeIf { it > 0 }
                ?: DEFAULT.pickupWindowDays,
            requireIdPhoto = requireIdPhoto ?: DEFAULT.requireIdPhoto,
            overdueSuspendDays = overdueSuspendDays?.toInt()?.takeIf { it > 0 }
                ?: DEFAULT.overdueSuspendDays
        )
    }
}

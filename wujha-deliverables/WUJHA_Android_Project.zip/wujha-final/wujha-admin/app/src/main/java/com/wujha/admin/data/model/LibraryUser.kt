package com.wujha.admin.data.model

enum class UserStatus(val labelAr: String) {
    ACTIVE("نشطة"),
    SUSPENDED("موقوف");

    companion object {
        fun from(raw: String?): UserStatus =
            entries.firstOrNull { it.name == raw } ?: ACTIVE
    }
}

/**
 * A library **membership**, in the `members` collection.
 *
 * This is deliberately not the same thing as an app account, and the two are
 * worth keeping apart:
 *
 *  - An app account (`users/{uid}`) is someone who installed an app and
 *    signed in. It is created by Firebase Auth and identified by a user id.
 *  - A membership is the library's own record of a person entitled to borrow
 *    — a student, a lecturer, a member of staff — identified by the ID number
 *    printed on their card. It exists whether or not that person ever opens
 *    the app, which is exactly why a librarian needs to be able to create one
 *    by hand from a card at the desk.
 *
 * Memberships are what the reports count, what gets suspended when someone
 * keeps a book too long, and what a future loans feature would hang off.
 * They grant nothing inside the app: permission comes from [AdminGrant].
 *
 * [linkedUid] is the optional bridge — set it when a membership belongs to a
 * person who also has an app account.
 */
data class LibraryUser(
    val id: String = "",
    val name: String = "",
    /** The number on the membership card. Unique across the library. */
    val idNumber: String = "",
    val status: UserStatus = UserStatus.ACTIVE,
    val phone: String = "",
    val joinDate: String = "",
    /** One of `Catalogs.memberTypes`, e.g. "طالب". */
    val memberType: String = "",
    /** The app account this membership belongs to, when it has one. */
    val linkedUid: String = ""
) {
    fun toMap(): Map<String, Any> = mapOf(
        "name" to name,
        "idNumber" to idNumber,
        "status" to status.name,
        "phone" to phone,
        "joinDate" to joinDate,
        "memberType" to memberType,
        "linkedUid" to linkedUid
    )
}

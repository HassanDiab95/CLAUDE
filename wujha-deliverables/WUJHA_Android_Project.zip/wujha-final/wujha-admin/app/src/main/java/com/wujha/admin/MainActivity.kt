package com.wujha.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.wujha.admin.data.Localization
import com.wujha.admin.data.PreferencesProvider
import com.wujha.admin.data.auth.AuthProviderHolder
import com.wujha.admin.data.notify.NotificationStoreProvider
import com.wujha.admin.data.repository.AccountProvider
import com.wujha.admin.data.repository.LibraryRepositoryProvider
import com.wujha.admin.navigation.WujhaAdminNavGraph
import com.wujha.admin.ui.theme.WujhaTheme
import com.wujha.admin.ui.theme.WujhaThemeState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Firebase auto-initialises from google-services.json before onCreate,
        // so these are safe here. The repository attaches its Firestore
        // snapshot listeners as soon as it is constructed.
        AuthProviderHolder.init()
        LibraryRepositoryProvider.init()
        AccountProvider.init()
        PreferencesProvider.init(applicationContext)
        NotificationStoreProvider.init(applicationContext)
        Localization.init(applicationContext)

        // Light or dark: the saved choice, plus the phone's night mode. Android
        // re-creates the activity when night mode changes, so this re-runs.
        WujhaThemeState.init(this)

        enableEdgeToEdge()
        setContent {
            WujhaTheme {
                // Dark status-bar icons on the light palette, light ones on the dark.
                val dark = WujhaThemeState.isDark
                SideEffect {
                    WindowCompat.getInsetsController(window, window.decorView).apply {
                        isAppearanceLightStatusBars = !dark
                        isAppearanceLightNavigationBars = !dark
                    }
                }
                Surface(modifier = Modifier.fillMaxSize()) {
                    WujhaAdminNavGraph()
                }
            }
        }
    }
}

package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.repository.DataStatus
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.ui.theme.AccentGoldDark
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.ErrorView
import com.wujha.admin.ui.components.LoadingView
import com.wujha.admin.ui.components.SectionHeader
import com.wujha.admin.ui.components.StatBarList
import com.wujha.admin.ui.components.StatTile
import com.wujha.admin.ui.theme.AccentGold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackground
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.StatusBorrowedText
import com.wujha.admin.ui.theme.StatusLostText
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

/**
 * The admin home screen.
 *
 * Every figure is computed from the live catalog rather than stored, so the
 * dashboard can't drift out of sync with the books collection.
 */
@Composable
fun DashboardScreen(
    repository: LibraryRepository,
    onOpenMap: () -> Unit,
    onOpenReports: () -> Unit,
    onOpenBooks: () -> Unit,
    onOpenLoans: () -> Unit
) {
    val books by repository.books.collectAsState()
    val status by repository.status.collectAsState()
    // `loans` is collected rather than just read so that the borrowing
    // figures below refresh the moment anything moves, the same way the
    // catalog figures follow `books`.
    val loans by repository.loans.collectAsState()
    val stats = repository.dashboardStats()
    val loanStats = repository.loanStats()

    when {
        status is DataStatus.Error -> {
            ErrorView(
                message = (status as DataStatus.Error).message,
                modifier = Modifier.background(CreamBackground)
            )
            return
        }
        status is DataStatus.Loading && books.isEmpty() -> {
            LoadingView(
                message = t("جارٍ تحميل بيانات المكتبة..."),
                modifier = Modifier.background(CreamBackground)
            )
            return
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text(t("لوحة التحكم"), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextPrimary)
                Text(
                    text = t("نظرة عامة على فهرس المكتبة"),
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        if (books.isEmpty()) {
            item {
                EmptyView(
                    icon = Icons.Outlined.LibraryBooks,
                    title = t("لا توجد كتب في الفهرس"),
                    detail = t("أضف أول كتاب من تبويب الكتب، أو أدخل بيانات أولية من الإعدادات."),
                    actionLabel = t("إدارة الكتب"),
                    onAction = onOpenBooks
                )
            }
            return@LazyColumn
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatTile(
                    label = t("إجمالي النسخ"),
                    value = stats.totalBooks.toString(),
                    accent = ForestGreen,
                    modifier = Modifier.weight(1f)
                )
                StatTile(
                    label = t("متوفر"),
                    value = stats.availableBooks.toString(),
                    accent = ForestGreen,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatTile(
                    label = t("مستعار"),
                    value = stats.borrowedBooks.toString(),
                    accent = StatusBorrowedText,
                    modifier = Modifier.weight(1f)
                )
                StatTile(
                    label = t("مفقود"),
                    value = stats.lostBooks.toString(),
                    accent = StatusLostText,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // ---- Borrowing -------------------------------------------------
        // Put before the catalog chart on purpose: the chart is a picture of
        // the library, while these four numbers are the work waiting to be
        // done today.
        item {
            Column(modifier = Modifier.padding(top = 24.dp, start = 20.dp, end = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionHeader(title = t("الإعارة"), modifier = Modifier.weight(1f))
                    Text(
                        text = t("عرض الكل"),
                        color = ForestGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable(onClick = onOpenLoans)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        label = t("طلبات بانتظار المراجعة"),
                        value = loanStats.pendingRequests.toString(),
                        accent = AccentGoldDark,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        label = t("مُعارة حالياً"),
                        value = loanStats.activeLoans.toString(),
                        accent = ForestGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        label = t("متأخرة عن موعد الإرجاع"),
                        value = loanStats.overdueLoans.toString(),
                        accent = if (loanStats.overdueLoans > 0) SignalRed else TextSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        label = t("محجوزة للاستلام"),
                        value = loanStats.awaitingPickup.toString(),
                        accent = ForestGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (loanStats.pendingRequests > 0 || loanStats.renewalRequests > 0) {
                    Spacer(Modifier.height(12.dp))
                    Surface(
                        onClick = onOpenLoans,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = AccentGoldDark.copy(alpha = 0.10f)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Outlined.SwapHoriz,
                                contentDescription = null,
                                tint = AccentGoldDark,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = buildString {
                                    if (loanStats.pendingRequests > 0) {
                                        append(t("%s طلب إعارة بانتظار المراجعة").format(loanStats.pendingRequests))
                                    }
                                    if (loanStats.pendingRequests > 0 && loanStats.renewalRequests > 0) {
                                        append(" • ")
                                    }
                                    if (loanStats.renewalRequests > 0) {
                                        append(t("%s طلب تجديد").format(loanStats.renewalRequests))
                                    }
                                },
                                color = AccentGoldDark,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }
                if (loans.isEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = t("لم تُسجّل أي إعارة بعد."),
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                }
            }
        }

        item {
            Column(modifier = Modifier.padding(top = 24.dp, start = 20.dp, end = 20.dp)) {
                SectionHeader(title = t("توزيع الكتب على التصنيفات"))
                Spacer(Modifier.height(14.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    StatBarList(
                        values = stats.byCategory,
                        modifier = Modifier.padding(16.dp),
                        barColor = AccentGold
                    )
                }
            }
        }

        item {
            Column(modifier = Modifier.padding(top = 24.dp, start = 20.dp, end = 20.dp)) {
                SectionHeader(title = t("اختصارات"))
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    QuickAction(
                        icon = Icons.Outlined.Map,
                        label = t("خريطة المكتبة"),
                        onClick = onOpenMap,
                        modifier = Modifier.weight(1f)
                    )
                    QuickAction(
                        icon = Icons.Outlined.Assignment,
                        label = t("التقارير"),
                        onClick = onOpenReports,
                        modifier = Modifier.weight(1f)
                    )
                    QuickAction(
                        icon = Icons.Outlined.SwapHoriz,
                        label = t("الإعارة"),
                        onClick = onOpenLoans,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickAction(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(8.dp))
            Text(label, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

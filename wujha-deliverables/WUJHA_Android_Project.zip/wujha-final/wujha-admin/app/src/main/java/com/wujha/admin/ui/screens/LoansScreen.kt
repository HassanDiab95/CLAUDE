package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.model.Loan
import com.wujha.admin.data.model.LoanStatus
import com.wujha.admin.data.repository.DataStatus
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.ErrorView
import com.wujha.admin.ui.components.FilterChip
import com.wujha.admin.ui.components.LoanRow
import com.wujha.admin.ui.components.SearchField
import com.wujha.admin.ui.theme.AccentGoldDark
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackground
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

/**
 * The five lists a librarian actually works from.
 *
 * They are not the seven statuses: «المتأخرة» is a slice of the loans that
 * are out, and the three closed statuses share one history. These are the
 * piles on the desk, not the values in the database.
 */
private enum class LoanFilter(val label: String) {
    REQUESTS("الطلبات"),
    HOLDS("بانتظار الاستلام"),
    OUT("المُعارة"),
    LATE("المتأخرة"),
    HISTORY("السجل")
}

private fun matches(loan: Loan, filter: LoanFilter): Boolean = when (filter) {
    LoanFilter.REQUESTS -> loan.status == LoanStatus.REQUESTED
    LoanFilter.HOLDS -> loan.status == LoanStatus.APPROVED
    LoanFilter.OUT -> loan.status == LoanStatus.ACTIVE
    LoanFilter.LATE -> loan.isOverdue
    LoanFilter.HISTORY -> !loan.status.isOpen
}

@Composable
fun LoansScreen(
    repository: LibraryRepository,
    onOpenLoan: (String) -> Unit,
    onNewLoan: () -> Unit
) {
    val allLoans by repository.loans.collectAsState()
    val status by repository.status.collectAsState()
    val stats = repository.loanStats()

    var query by remember { mutableStateOf("") }

    // Which list opens first is worked out rather than fixed. A librarian
    // arriving at the desk wants the requests nobody has answered; with none
    // waiting, what matters is what is late, and otherwise what is simply
    // out. It is derived on every pass on purpose: the collection is empty
    // for the first moment after launch, and a filter chosen from that empty
    // list would be the wrong one by the time the data arrived.
    //
    // The moment the librarian taps a chip, their choice wins and stops
    // moving underneath them.
    var chosen by remember { mutableStateOf<LoanFilter?>(null) }
    val filter = chosen ?: when {
        stats.pendingRequests > 0 -> LoanFilter.REQUESTS
        stats.overdueLoans > 0 -> LoanFilter.LATE
        else -> LoanFilter.OUT
    }

    val filtered = remember(query, filter, allLoans) {
        val q = query.trim()
        allLoans
            .filter { matches(it, filter) }
            .filter {
                q.isBlank() ||
                    it.bookTitle.contains(q, true) ||
                    it.memberName.contains(q, true) ||
                    it.memberIdNumber.contains(q) ||
                    it.bookSerial.contains(q, true)
            }
    }

    if (status is DataStatus.Error) {
        ErrorView(
            message = (status as DataStatus.Error).message,
            modifier = Modifier.background(CreamBackground)
        )
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = t("الإعارة"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                )
                Surface(onClick = onNewLoan, shape = RoundedCornerShape(10.dp), color = ForestGreen) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Add,
                            contentDescription = null,
                            tint = SurfaceWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = t("إعارة يدوية"),
                            color = SurfaceWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        item {
            CountStrip(
                items = listOf(
                    Triple(t("طلبات"), stats.pendingRequests, AccentGoldDark),
                    Triple(t("محجوزة"), stats.awaitingPickup, ForestGreen),
                    Triple(t("مُعارة"), stats.activeLoans, TextPrimary),
                    Triple(t("متأخرة"), stats.overdueLoans, SignalRed)
                ),
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(Modifier.height(14.dp))
        }

        if (allLoans.isEmpty() && status is DataStatus.Ready) {
            item {
                EmptyView(
                    icon = Icons.Outlined.SwapHoriz,
                    title = t("لا توجد إعارات بعد"),
                    detail = t("ستظهر هنا طلبات الإعارة الواردة من تطبيق الزائر، ويمكنك تسجيل إعارة يدوياً لعضو يقف أمامك."),
                    actionLabel = t("إعارة يدوية"),
                    onAction = onNewLoan
                )
            }
            return@LazyColumn
        }

        item {
            SearchField(
                value = query,
                onValueChange = { query = it },
                placeholder = t("ابحث بعنوان الكتاب أو اسم العضو أو رقم الهوية..."),
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(Modifier.height(12.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(LoanFilter.entries.toList()) { f ->
                    val count = allLoans.count { matches(it, f) }
                    FilterChip(
                        label = if (count > 0) "${t(f.label)} ($count)" else t(f.label),
                        selected = filter == f,
                        onClick = { chosen = f }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (stats.renewalRequests > 0 && filter != LoanFilter.HISTORY) {
            item {
                Notice(
                    text = t("%s طلب تجديد بانتظار ردّك. افتح الإعارة لقبوله أو رفضه.")
                        .format(stats.renewalRequests),
                    tint = AccentGoldDark,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
            }
        }

        if (filtered.isEmpty()) {
            item {
                Text(
                    text = when {
                        query.isNotBlank() -> t("لا توجد إعارات مطابقة لهذا البحث.")
                        filter == LoanFilter.REQUESTS -> t("لا توجد طلبات بانتظار المراجعة.")
                        filter == LoanFilter.HOLDS -> t("لا توجد نسخ محجوزة بانتظار الاستلام.")
                        filter == LoanFilter.OUT -> t("لا توجد كتب مُعارة حالياً.")
                        filter == LoanFilter.LATE -> t("لا توجد إعارات متأخرة الآن.")
                        else -> t("السجل فارغ حتى الآن.")
                    },
                    color = TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().padding(32.dp)
                )
            }
        }

        items(filtered) { loan ->
            LoanRow(loan = loan, onClick = { onOpenLoan(loan.id) })
        }
    }
}

/** Four numbers across one card: the state of the desk at a glance. */
@Composable
private fun CountStrip(items: List<Triple<String, Int, Color>>, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
            items.forEachIndexed { index, (label, value, tint) ->
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = value.toString(),
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (value == 0) TextSecondary else tint
                    )
                    Text(text = label, fontSize = 11.sp, color = TextSecondary)
                }
                if (index != items.lastIndex) {
                    Box(modifier = Modifier.width(1.dp).height(30.dp).background(BorderLight))
                }
            }
        }
    }
}

/** A one-line nudge, tinted but not alarming. */
@Composable
private fun Notice(text: String, tint: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = tint.copy(alpha = 0.10f)
    ) {
        Text(
            text = text,
            color = tint,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }
}

package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.Catalogs
import com.wujha.admin.data.model.LoanPolicy
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.DropdownField
import com.wujha.admin.ui.components.FormErrorBanner
import com.wujha.admin.ui.components.PickerOption
import com.wujha.admin.ui.components.PrimaryButton
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackgroundAlt
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenMid
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * The borrowing rules, editable by the librarian.
 *
 * These live in the database rather than in the code because they are the
 * library's policy, not the app's design: lending for three weeks instead of
 * two should not need a new version of the app, and the trainer should be
 * able to change it in front of the class.
 *
 * Everything is a fixed choice rather than a number field. A due date
 * computed from a mistyped 1 000 is a bug nobody notices until a book is
 * lent out until 2029.
 */
@Composable
fun LoanSettingsScreen(repository: LibraryRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val stored by repository.loanPolicy.collectAsState()

    // The draft starts from the stored policy and is keyed on it, so a change
    // made on another device while this screen is open is picked up instead
    // of being silently overwritten by a stale form.
    var draft by remember(stored) { mutableStateOf(stored) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }

    val dirty = draft != stored

    ScreenScaffold(title = t("إعدادات الإعارة"), onBack = onBack) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            item {
                Text(
                    text = t("تُطبَّق هذه القواعد على الإعارات الجديدة، وتظهر للزائر في تطبيقه قبل إرسال الطلب."),
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                )
            }

            item {
                SettingsCard(title = t("المدة والحدود")) {
                    NumberChoice(
                        label = t("مدة الإعارة (أيام)"),
                        options = Catalogs.loanDayOptions,
                        value = draft.loanDays,
                        onSelect = { draft = draft.copy(loanDays = it) }
                    )
                    Spacer(Modifier.height(12.dp))
                    NumberChoice(
                        label = t("أقصى عدد كتب لكل عضو"),
                        options = Catalogs.loanLimitOptions,
                        value = draft.maxActivePerMember,
                        onSelect = { draft = draft.copy(maxActivePerMember = it) }
                    )
                    Spacer(Modifier.height(12.dp))
                    NumberChoice(
                        label = t("مدة حجز النسخة للاستلام (أيام)"),
                        options = Catalogs.pickupWindowOptions,
                        value = draft.pickupWindowDays,
                        onSelect = { draft = draft.copy(pickupWindowDays = it) }
                    )
                    Spacer(Modifier.height(6.dp))
                    Hint(t("بعد انتهاء هذه المدة يمكن إلغاء الحجز وإعادة النسخة للرف."))
                }
            }

            item {
                SettingsCard(title = t("التجديد")) {
                    NumberChoice(
                        label = t("عدد التجديدات المسموحة"),
                        options = Catalogs.renewalCountOptions,
                        value = draft.maxRenewals,
                        onSelect = { draft = draft.copy(maxRenewals = it) }
                    )
                    Spacer(Modifier.height(12.dp))
                    NumberChoice(
                        label = t("مدة التجديد (أيام)"),
                        options = Catalogs.renewalDayOptions,
                        value = draft.renewDays,
                        onSelect = { draft = draft.copy(renewDays = it) }
                    )
                    Spacer(Modifier.height(6.dp))
                    Hint(t("الإعارة المتأخرة لا تُجدَّد؛ تُسترجع أولاً."))
                }
            }

            item {
                SettingsCard(title = t("التحقق والتأخير")) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = t("اشتراط صورة الهوية لطلبات التطبيق"),
                                color = TextPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = t("عند التفعيل لا تُقبل الموافقة قبل تأكيد مطابقة الصورة للبيانات."),
                                color = TextSecondary,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        Switch(
                            checked = draft.requireIdPhoto,
                            onCheckedChange = { draft = draft.copy(requireIdPhoto = it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = ForestGreen
                            )
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    NumberChoice(
                        label = t("التأخير الذي يُقترح عنده إيقاف العضوية (أيام)"),
                        options = Catalogs.overdueSuspendOptions,
                        value = draft.overdueSuspendDays,
                        onSelect = { draft = draft.copy(overdueSuspendDays = it) }
                    )
                    Spacer(Modifier.height(6.dp))
                    Hint(t("الإيقاف لا يحدث تلقائياً: يظهر اقتراح في صفحة الإعارة وأنت تقرّر."))
                }
            }

            val currentError = error
            if (currentError != null) {
                item {
                    FormErrorBanner(
                        message = currentError,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                }
            }

            if (saved && !dirty) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = ForestGreenMid.copy(alpha = 0.10f)
                    ) {
                        Text(
                            text = t("حُفظت إعدادات الإعارة."),
                            color = ForestGreenMid,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }

            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                    PrimaryButton(
                        text = t("حفظ الإعدادات"),
                        onClick = {
                            busy = true
                            error = null
                            saved = false
                            scope.launch {
                                val failure = repository.saveLoanPolicy(draft)
                                busy = false
                                if (failure == null) saved = true else error = failure
                            }
                        },
                        enabled = dirty,
                        loading = busy
                    )
                    if (!dirty && !saved) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = t("لا توجد تغييرات لحفظها."),
                            color = TextSecondary,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = CreamBackgroundAlt
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = t("القيم الافتراضية"),
                            color = TextPrimary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = t("%s يوماً للإعارة • %s كتب لكل عضو • تجديد %s مرة • حجز %s أيام")
                                .format(
                                    LoanPolicy.DEFAULT.loanDays,
                                    LoanPolicy.DEFAULT.maxActivePerMember,
                                    LoanPolicy.DEFAULT.maxRenewals,
                                    LoanPolicy.DEFAULT.pickupWindowDays
                                ),
                            color = TextSecondary,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = TextPrimary)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

/** A dropdown over a list of numbers, so nothing invalid can be chosen. */
@Composable
private fun NumberChoice(
    label: String,
    options: List<Int>,
    value: Int,
    onSelect: (Int) -> Unit
) {
    DropdownField(
        label = label,
        // The stored value is offered even if it is not in the list: a policy
        // written by hand in the console should be shown, not quietly reset.
        options = (if (value in options) options else options + value)
            .sorted()
            .map { PickerOption(it.toString(), it.toString()) },
        selectedValue = value.toString(),
        onSelect = { raw -> raw.toIntOrNull()?.let(onSelect) }
    )
}

@Composable
private fun Hint(text: String) {
    Text(text = text, color = TextSecondary, fontSize = 11.sp)
}

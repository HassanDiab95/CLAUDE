package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.model.Aisle
import com.wujha.admin.data.model.Block
import com.wujha.admin.data.model.Floor
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.DropdownField
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.PickerOption
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.AccentGold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackgroundAlt
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenWash
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * إدارة المواقع — the shape of the building.
 *
 * This is the screen that makes every location dropdown in the app honest:
 * a bookcase can only be placed in a block that exists on the floor it was
 * put on, and only in an aisle that exists in that block, because both lists
 * come from here. It is also what the floor map draws.
 */
@Composable
fun ManageFloorsScreen(
    repository: LibraryRepository,
    onBack: () -> Unit,
    onOpenFloor: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val floors by repository.floors.collectAsState()
    val shelves by repository.shelves.collectAsState()

    var showNew by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Floor?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    ScreenScaffold(
        title = t("إدارة المواقع"),
        onBack = onBack,
        actionLabel = t("دور جديد"),
        onAction = { showNew = true }
    ) {
        if (floors.isEmpty()) {
            EmptyView(
                icon = Icons.Outlined.Layers,
                title = t("لم تُعرَّف أي أدوار بعد"),
                detail = t("ابدأ بإضافة دور، ثم أضف إليه البلوكات والممرات. الرفوف تُسند بعد ذلك إلى ممر داخل بلوك."),
                actionLabel = t("إضافة دور"),
                onAction = { showNew = true }
            )
            return@ScreenScaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    text = t("الدور يحتوي على بلوكات، والبلوك يحتوي على ممرات، والممر تُصفّ عليه الرفوف. الفراغ بين البلوكات هو الممر الرئيسي الذي تُرسم عليه طريق الوصول."),
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            items(floors) { floor ->
                val shelfCount = shelves.count { it.floorId == floor.id }
                FloorRow(
                    floor = floor,
                    shelfCount = shelfCount,
                    onEdit = { onOpenFloor(floor.id) },
                    onDelete = { deleting = floor }
                )
            }
        }
    }

    if (showNew) {
        FloorDialog(
            existing = null,
            takenIds = floors.map { it.id },
            onDismiss = { showNew = false },
            onSave = { floor ->
                showNew = false
                scope.launch { message = repository.saveFloor(floor) }
            }
        )
    }

    val toDelete = deleting
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = SurfaceWhite,
            title = { Text(t("حذف %s").format(toDelete.name), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Text(
                    t("سيُحذف الدور وكل بلوكاته وممراته. لن تُحذف الرفوف، لكنها ستصبح بلا موقع على الخريطة."),
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch { message = repository.deleteFloor(toDelete) }
                }) { Text(t("حذف"), color = SignalRed, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(t("إلغاء"), color = TextSecondary) }
            }
        )
    }

    ResultDialog(message) { message = null }
}

@Composable
private fun FloorRow(floor: Floor, shelfCount: Int, onEdit: () -> Unit, onDelete: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = RoundedCornerShape(10.dp), color = ForestGreenWash) {
                Box(modifier = Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = "${floor.order}",
                        color = ForestGreen,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(floor.name, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    text = t("%s بلوك • %s ممر • %s رف").format(floor.blocks.size, floor.blocks.sumOf { it.aisles.size }, shelfCount),
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Outlined.Edit, contentDescription = t("تعديل"), tint = TextSecondary)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Outlined.Delete, contentDescription = t("حذف"), tint = SignalRed)
            }
        }
    }
}

/**
 * One floor's blocks and aisles.
 *
 * The whole floor is edited as a single draft and saved in one write,
 * because it is stored as one document — which is what guarantees a block
 * can never arrive without the aisles that belong to it.
 */
@Composable
fun FloorEditorScreen(
    floorId: String,
    repository: LibraryRepository,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val floors by repository.floors.collectAsState()
    val stored = floors.firstOrNull { it.id == floorId }

    var draft by remember(stored?.id) { mutableStateOf(stored ?: Floor(id = floorId)) }
    var editingBlock by remember { mutableStateOf<Block?>(null) }
    var showBlockDialog by remember { mutableStateOf(false) }
    var showFloorDialog by remember { mutableStateOf(false) }
    var aisleFor by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    fun replaceBlock(code: String, transform: (Block) -> Block?) {
        draft = draft.copy(
            blocks = draft.blocks.mapNotNull { if (it.code == code) transform(it) else it }
        )
    }

    ScreenScaffold(
        title = draft.name.ifBlank { t("تعديل الدور") },
        onBack = onBack,
        actionLabel = t("بلوك جديد"),
        onAction = { editingBlock = null; showBlockDialog = true }
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = draft.name.ifBlank { t("بلا اسم") },
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = listOfNotNull(
                                draft.nameEn.takeIf { it.isNotBlank() },
                                t("الترتيب: %s").format(draft.order)
                            ).joinToString(" • "),
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = { showFloorDialog = true }) {
                        Icon(Icons.Outlined.Edit, contentDescription = t("تعديل"), tint = TextSecondary)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))

            Text(
                text = t("ترتيب البلوكات في الشبكة (الصف والعمود) هو ما يرسم شكل الدور على الخريطة، والفراغ بينها هو الممر الرئيسي."),
                color = TextSecondary,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(14.dp))

            if (draft.blocks.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = CreamBackgroundAlt
                ) {
                    Text(
                        text = t("لا توجد بلوكات في هذا الدور بعد. اضغط «بلوك جديد» لإضافة أول بلوك."),
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            draft.blocks.forEach { block ->
                BlockCard(
                    block = block,
                    onEdit = { editingBlock = block; showBlockDialog = true },
                    onDelete = { replaceBlock(block.code) { null } },
                    onAddAisle = { aisleFor = block.code },
                    onRemoveAisle = { aisle ->
                        replaceBlock(block.code) { b ->
                            b.copy(aisles = b.aisles.filterNot { it.code == aisle.code })
                        }
                    }
                )
                Spacer(Modifier.height(10.dp))
            }

            Spacer(Modifier.height(16.dp))
            Surface(
                onClick = {
                    if (!saving) {
                        saving = true
                        scope.launch {
                            message = repository.saveFloor(draft) ?: t("تم حفظ %s.").format(draft.name)
                            saving = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = ForestGreen
            ) {
                Text(
                    text = if (saving) t("جارٍ الحفظ...") else t("حفظ الدور"),
                    color = SurfaceWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(vertical = 14.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
            Spacer(Modifier.height(30.dp))
        }
    }

    if (showFloorDialog) {
        FloorDialog(
            existing = draft,
            takenIds = floors.map { it.id },
            onDismiss = { showFloorDialog = false },
            onSave = { edited ->
                showFloorDialog = false
                // Only the details change here; the blocks being edited on
                // this screen are the ones that get saved.
                draft = draft.copy(
                    name = edited.name,
                    nameEn = edited.nameEn,
                    order = edited.order
                )
            }
        )
    }

    if (showBlockDialog) {
        BlockDialog(
            existing = editingBlock,
            takenCodes = draft.blocks.map { it.code },
            onDismiss = { showBlockDialog = false },
            onSave = { block ->
                showBlockDialog = false
                val current = editingBlock
                draft = if (current == null) {
                    draft.copy(blocks = draft.blocks + block)
                } else {
                    draft.copy(
                        blocks = draft.blocks.map {
                            if (it.code == current.code) block.copy(aisles = it.aisles) else it
                        }
                    )
                }
            }
        )
    }

    val addingTo = aisleFor
    if (addingTo != null) {
        val block = draft.blocks.firstOrNull { it.code == addingTo }
        AisleDialog(
            blockCode = addingTo,
            takenCodes = block?.aisles?.map { it.code }.orEmpty(),
            nextOrder = block?.aisles?.size ?: 0,
            onDismiss = { aisleFor = null },
            onSave = { aisle ->
                aisleFor = null
                replaceBlock(addingTo) { b -> b.copy(aisles = b.aisles + aisle) }
            }
        )
    }

    ResultDialog(message) { message = null }
}

@Composable
private fun BlockCard(
    block: Block,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onAddAisle: () -> Unit,
    onRemoveAisle: (Aisle) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(8.dp), color = ForestGreenWash) {
                    Text(
                        text = block.code,
                        color = ForestGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(
                        text = block.name.ifBlank { t("بلوك %s").format(block.code) },
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = t("الصف %s • العمود %s").format(block.row, block.column),
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Outlined.Edit, contentDescription = t("تعديل"), tint = TextSecondary)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Outlined.Delete, contentDescription = t("حذف"), tint = SignalRed)
                }
            }

            Spacer(Modifier.height(8.dp))
            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BorderLight))
            Spacer(Modifier.height(8.dp))

            if (block.aisles.isEmpty()) {
                Text(t("لا توجد ممرات في هذا البلوك."), color = TextSecondary, fontSize = 11.sp)
            }
            block.aisles.forEach { aisle ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = aisle.code,
                        color = AccentGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(44.dp)
                    )
                    Text(
                        text = aisle.name.ifBlank { t("بلا اسم") },
                        color = TextPrimary,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { onRemoveAisle(aisle) }) {
                        Icon(
                            Icons.Outlined.Delete,
                            contentDescription = t("حذف الممر"),
                            tint = SignalRed,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))
            Surface(
                onClick = onAddAisle,
                shape = RoundedCornerShape(10.dp),
                color = ForestGreenWash
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Outlined.Add,
                        contentDescription = null,
                        tint = ForestGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = t("إضافة ممر"),
                        color = ForestGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FloorDialog(
    existing: Floor?,
    takenIds: List<String>,
    onDismiss: () -> Unit,
    onSave: (Floor) -> Unit
) {
    var id by remember { mutableStateOf(existing?.id.orEmpty()) }
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var nameEn by remember { mutableStateOf(existing?.nameEn.orEmpty()) }
    var order by remember { mutableStateOf((existing?.order ?: takenIds.size).toString()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = {
            Text(
                text = if (existing == null) t("دور جديد") else t("تعديل الدور"),
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
            Column(modifier = Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                // The id is what every bookcase on this floor points at, so
                // it is fixed once the floor exists. The names above it are
                // free to change.
                WujhaTextField(
                    value = id,
                    onValueChange = { input -> id = input.filter { it.isLetterOrDigit() || it == '_' }; error = null },
                    placeholder = t("المعرّف بالإنجليزية (مثال: ground)"),
                    enabled = existing == null,
                    errorText = error
                )
                Spacer(Modifier.height(10.dp))
                WujhaTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = t("اسم الدور بالعربية")
                )
                Spacer(Modifier.height(10.dp))
                WujhaTextField(
                    value = nameEn,
                    onValueChange = { nameEn = it },
                    placeholder = t("اسم الدور بالإنجليزية")
                )
                Spacer(Modifier.height(10.dp))
                WujhaTextField(
                    value = order,
                    onValueChange = { input -> order = input.filter { it.isDigit() }.take(2) },
                    placeholder = t("الترتيب في المبنى (0 للأرضي)"),
                    keyboardType = KeyboardType.Number
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    id.isBlank() -> error = t("الرجاء إدخال معرّف الدور")
                    existing == null && takenIds.contains(id) -> error = t("هذا المعرّف مستخدم مسبقاً")
                    name.isBlank() -> error = t("الرجاء إدخال اسم الدور")
                    else -> onSave(
                        Floor(
                            id = id.trim(),
                            name = name.trim(),
                            nameEn = nameEn.trim(),
                            order = order.toIntOrNull() ?: 0,
                            blocks = existing?.blocks.orEmpty()
                        )
                    )
                }
            }) { Text(t("حفظ"), color = ForestGreen, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(t("إلغاء"), color = TextSecondary) }
        }
    )
}

@Composable
private fun BlockDialog(
    existing: Block?,
    takenCodes: List<String>,
    onDismiss: () -> Unit,
    onSave: (Block) -> Unit
) {
    var code by remember { mutableStateOf(existing?.code.orEmpty()) }
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var nameEn by remember { mutableStateOf(existing?.nameEn.orEmpty()) }
    var row by remember { mutableStateOf((existing?.row ?: 0).toString()) }
    var column by remember { mutableStateOf((existing?.column ?: 0).toString()) }
    var error by remember { mutableStateOf<String?>(null) }

    val gridOptions = (0..3).map { PickerOption(it.toString(), it.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = {
            Text(
                text = if (existing == null) t("بلوك جديد") else t("تعديل البلوك %s").format(existing.code),
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
            Column(modifier = Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                WujhaTextField(
                    value = code,
                    onValueChange = { input -> code = input.uppercase().take(3); error = null },
                    placeholder = t("رمز البلوك (مثال: A)"),
                    errorText = error
                )
                Spacer(Modifier.height(10.dp))
                WujhaTextField(value = name, onValueChange = { name = it }, placeholder = t("اسم البلوك بالعربية"))
                Spacer(Modifier.height(10.dp))
                WujhaTextField(value = nameEn, onValueChange = { nameEn = it }, placeholder = t("اسم البلوك بالإنجليزية"))
                Spacer(Modifier.height(12.dp))
                DropdownField(
                    label = t("الصف على الخريطة"),
                    options = gridOptions,
                    selectedValue = row,
                    onSelect = { row = it }
                )
                Spacer(Modifier.height(12.dp))
                DropdownField(
                    label = t("العمود على الخريطة"),
                    options = gridOptions,
                    selectedValue = column,
                    onSelect = { column = it }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    code.isBlank() -> error = t("الرجاء إدخال رمز البلوك")
                    existing == null && takenCodes.contains(code) -> error = t("هذا الرمز مستخدم في هذا الدور")
                    else -> onSave(
                        Block(
                            code = code.trim(),
                            name = name.trim(),
                            nameEn = nameEn.trim(),
                            row = row.toIntOrNull() ?: 0,
                            column = column.toIntOrNull() ?: 0,
                            aisles = existing?.aisles.orEmpty()
                        )
                    )
                }
            }) { Text(t("حفظ"), color = ForestGreen, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(t("إلغاء"), color = TextSecondary) }
        }
    )
}

@Composable
private fun AisleDialog(
    blockCode: String,
    takenCodes: List<String>,
    nextOrder: Int,
    onDismiss: () -> Unit,
    onSave: (Aisle) -> Unit
) {
    var code by remember { mutableStateOf("$blockCode${nextOrder + 1}") }
    var name by remember { mutableStateOf("") }
    var nameEn by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = { Text(t("ممر جديد في البلوك %s").format(blockCode), fontWeight = FontWeight.Bold, color = TextPrimary) },
        text = {
            Column {
                WujhaTextField(
                    value = code,
                    onValueChange = { input -> code = input.uppercase().take(6); error = null },
                    placeholder = t("رمز الممر (مثال: %s)").format("${blockCode}1"),
                    errorText = error
                )
                Spacer(Modifier.height(10.dp))
                WujhaTextField(value = name, onValueChange = { name = it }, placeholder = t("اسم الممر بالعربية"))
                Spacer(Modifier.height(10.dp))
                WujhaTextField(value = nameEn, onValueChange = { nameEn = it }, placeholder = t("اسم الممر بالإنجليزية"))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    code.isBlank() -> error = t("الرجاء إدخال رمز الممر")
                    takenCodes.contains(code) -> error = t("هذا الرمز مستخدم في هذا البلوك")
                    else -> onSave(
                        Aisle(
                            code = code.trim(),
                            name = name.trim(),
                            nameEn = nameEn.trim(),
                            order = nextOrder
                        )
                    )
                }
            }) { Text(t("إضافة"), color = ForestGreen, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(t("إلغاء"), color = TextSecondary) }
        }
    )
}

/** A one-line outcome, shown after something was saved or removed. */
@Composable
fun ResultDialog(message: String?, onDismiss: () -> Unit) {
    if (message == null) return
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = { Text(t("النتيجة"), fontWeight = FontWeight.Bold, color = TextPrimary) },
        text = { Text(message, color = TextSecondary) },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(t("حسناً"), color = ForestGreen, fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

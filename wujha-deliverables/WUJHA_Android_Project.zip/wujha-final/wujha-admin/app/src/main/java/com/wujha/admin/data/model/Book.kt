package com.wujha.admin.data.model

enum class BookStatus(val labelAr: String) {
    AVAILABLE("متوفر"),
    BORROWED("مستعار"),
    LOST("مفقود");

    companion object {
        /** Safe parse for a value coming out of Firestore. */
        fun from(raw: String?): BookStatus =
            entries.firstOrNull { it.name == raw } ?: AVAILABLE
    }
}

/**
 * A catalog entry. This is the full record: the admin app edits every field
 * and the visitor app reads the subset it displays, so both apps share one
 * `books` document shape.
 *
 * Every property has a default, so a partially-filled document reads as its
 * defaults rather than throwing.
 */
data class Book(
    val id: String = "",
    val title: String = "",
    val author: String = "",
    val category: String = "",
    /** Fallback tint drawn behind the title when there is no cover photo. */
    val coverColor: Long = 0xFF1F4E46,
    /** Base64 JPEG cover, stored on the document itself. Empty means none. */
    val coverBase64: String = "",
    val status: BookStatus = BookStatus.AVAILABLE,

    // ---- Where it is ---------------------------------------------------
    // The bookcase is the real answer: `shelf` plus `level` is enough for
    // LibraryPlan to resolve the floor, block and aisle from the live
    // building. The three fields after them are a snapshot of that answer at
    // the time of cataloguing, kept only so a book whose bookcase was deleted
    // still says roughly where it used to be.
    /** Code of the bookcase this book lives on, e.g. "1-A3". */
    val shelf: String = "",
    /** Which level of that bookcase, e.g. "الرف الأوسط". */
    val section: String = "",
    val floorId: String = "",
    val floor: String = "",
    val block: String = "",
    val aisle: String = "",

    val serial: String = "",
    val dateAdded: String = "",
    val copies: Int = 1,

    /**
     * How many copies are off the shelf right now: approved holds plus
     * loans out with a borrower.
     *
     * This is the one denormalised number in the database, and it is here
     * for a reason. Availability has to be visible in the **visitor** app,
     * and a visitor is not allowed to read other people's loans — so the
     * count cannot be worked out on their device. It is maintained only
     * inside the loan transactions in `LibraryRepository`, which read the
     * book and the loan together and refuse to let the last copy go out
     * twice. Nothing else should ever write it by hand.
     */
    val onLoan: Int = 0,

    val notes: String = "",
    val description: String = "",
    val tags: List<String> = emptyList(),
    val publisher: String = "",
    val language: String = "العربية",
    val pageCount: Int = 0,
    val rating: Double = 0.0,
    val ratingCount: Int = 0
) {
    /** Copies a visitor could borrow today. */
    val availableCopies: Int get() = (copies - onLoan).coerceAtLeast(0)

    /** True while at least one copy is on the shelf and the title is not lost. */
    val isBorrowable: Boolean get() = status != BookStatus.LOST && availableCopies > 0

    /** Field map written to Firestore. The document id is kept out of it. */
    fun toMap(): Map<String, Any> = mapOf(
        "title" to title,
        "author" to author,
        "category" to category,
        "coverColor" to coverColor,
        "coverBase64" to coverBase64,
        "status" to status.name,
        "shelf" to shelf,
        "section" to section,
        "floorId" to floorId,
        "floor" to floor,
        "block" to block,
        "aisle" to aisle,
        "serial" to serial,
        "dateAdded" to dateAdded,
        "copies" to copies,
        "onLoan" to onLoan,
        "notes" to notes,
        "description" to description,
        "tags" to tags,
        "publisher" to publisher,
        "language" to language,
        "pageCount" to pageCount,
        "rating" to rating,
        "ratingCount" to ratingCount
    )
}

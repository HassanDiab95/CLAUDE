package com.wujha.admin.data.model

/**
 * A physical bookcase.
 *
 * It hangs off the building described in [Floor]: a bookcase belongs to one
 * [floorId], sits in one [block] of that floor, stands along one [aisle] of
 * that block at [position], on one [side] of the walkway. Books point at it
 * by [code] and name a [levels] level.
 *
 * [floor] is the floor's Arabic name at the time of writing. It is only a
 * fallback for display — [floorId] is the real link — so a floor that is
 * renamed does not orphan its bookcases.
 */
data class Shelf(
    val id: String = "",
    /** Code printed on the bookcase itself, e.g. "1-A3". Unique. */
    val code: String = "",
    /** Document id in the `floors` collection, e.g. "first". */
    val floorId: String = "",
    /** The floor's name as it read when this was saved. Display fallback only. */
    val floor: String = "",
    /** Block code on that floor, e.g. "A". */
    val block: String = "",
    /** Aisle code inside that block, e.g. "A1". */
    val aisle: String = "",
    /** Order along the aisle, 1 = nearest the aisle entrance. */
    val position: Int = 0,
    /** Which side of the walkway, one of `Catalogs.sides`. */
    val side: String = "",
    /** How many levels this bookcase has. Books pick one of them. */
    val levels: Int = 3,
    /** Subject area, e.g. "الروايات العربية". Optional. */
    val zone: String = "",
    /** How many books it physically holds. 0 = unspecified. */
    val capacity: Int = 0,
    val notes: String = "",
    /**
     * Legacy: the earliest documents stored a single level here. Kept so
     * those still load; new bookcases leave it blank.
     */
    val section: String = ""
) {
    fun toMap(): Map<String, Any> = mapOf(
        "code" to code,
        "floorId" to floorId,
        "floor" to floor,
        "block" to block,
        "aisle" to aisle,
        "position" to position,
        "side" to side,
        "levels" to levels,
        "zone" to zone,
        "capacity" to capacity,
        "notes" to notes,
        "section" to section
    )

    /**
     * The levels of this bookcase, top first.
     *
     * Three is the common case and gets the names a visitor would actually
     * use; anything else is numbered, because "الرف الرابع من ستة" is not a
     * phrase that helps someone standing in front of it.
     */
    fun levelNames(): List<String> {
        val n = levels.coerceIn(1, 12)
        return if (n == 3) THREE_LEVELS else (1..n).map { "المستوى $it" }
    }

    companion object {
        val THREE_LEVELS = listOf("الرف العلوي", "الرف الأوسط", "الرف السفلي")

        // "G-A1-2" — floor G, aisle A1, second bookcase. The older two-part
        // form "1-B3" is still understood so early documents keep working.
        private val THREE_PART = Regex("""^[A-Za-z0-9]+-([A-Za-z]+)(\d*)-(\d+)$""")
        private val TWO_PART = Regex("""^[A-Za-z0-9]+-([A-Za-z]+)(\d+)$""")

        /**
         * Suggests block, aisle and position from a printed code.
         *
         * Only used to prefill the form. A bookcase whose code follows no
         * pattern at all is still perfectly valid, because the real values
         * are stored as their own fields rather than parsed back out.
         */
        fun parseCode(code: String): Triple<String, String, Int> {
            val trimmed = code.trim()
            THREE_PART.matchEntire(trimmed)?.let { m ->
                val block = m.groupValues[1].uppercase()
                return Triple(block, block + m.groupValues[2], m.groupValues[3].toIntOrNull() ?: 0)
            }
            TWO_PART.matchEntire(trimmed)?.let { m ->
                val block = m.groupValues[1].uppercase()
                return Triple(block, block + m.groupValues[2], m.groupValues[2].toIntOrNull() ?: 0)
            }
            return Triple("", "", 0)
        }
    }
}

package com.wujha.admin.data

/**
 * The fixed option lists the forms offer instead of a free-text box.
 *
 * Anything a librarian types by hand eventually gets typed two ways —
 * "الطابق الأول" and "الدور الأول" for one place — and the map matches on
 * these strings, so every field with a knowable set of values picks from
 * here or from the database.
 *
 * What is NOT here, because it is live data and editable in the app:
 * floors, blocks and aisles (the `floors` collection), categories
 * (`categories`) and bookcases (`shelves`).
 */
object Catalogs {

    /** Levels of a three-level bookcase, top first. */
    val levels = listOf("الرف العلوي", "الرف الأوسط", "الرف السفلي")

    /** Which side of the aisle walkway a bookcase stands on. */
    val sides = listOf("يمين الممر", "يسار الممر")

    val languages = listOf(
        "العربية",
        "الإنجليزية",
        "الفرنسية",
        "أخرى"
    )

    /** How many levels a new bookcase is offered. */
    val levelCounts = listOf(2, 3, 4, 5, 6)

    /** Capacities offered for a new bookcase. */
    val capacities = listOf(60, 90, 120, 150, 200, 250)

    /** Copy counts offered in the book form. */
    val copyCounts = (1..10).toList()

    /** Kinds of membership a library card can carry. */
    val memberTypes = listOf(
        "طالب",
        "عضو هيئة تدريس",
        "موظف",
        "زائر"
    )

    // ---- Borrowing rules -------------------------------------------------
    // Offered as fixed choices rather than a number box. Every one of these
    // is a decision the library has already made in words — "we lend for two
    // weeks" — and a free number field only invites 0, 365 and typos.

    /** Loan lengths offered, in days. */
    val loanDayOptions = listOf(7, 14, 21, 30)

    /** How many books one member may hold at once. */
    val loanLimitOptions = listOf(1, 2, 3, 4, 5, 6)

    /** Renewals allowed per loan. */
    val renewalCountOptions = listOf(0, 1, 2, 3)

    /** Days one renewal adds. */
    val renewalDayOptions = listOf(3, 7, 14)

    /** How long an approved copy waits to be collected, in days. */
    val pickupWindowOptions = listOf(1, 2, 3, 5, 7)

    /** Days overdue after which the app suggests suspending a membership. */
    val overdueSuspendOptions = listOf(7, 14, 21, 30)

    /**
     * The reasons a borrowing request is turned down.
     *
     * Offered as chips so that the common cases are one tap rather than a
     * sentence typed differently every time — and so the borrower reads a
     * reason written in the library's own words instead of nothing at all.
     */
    val rejectReasons = listOf(
        "صورة الهوية غير واضحة",
        "البيانات لا تطابق صورة الهوية",
        "لا توجد نسخة متاحة حالياً",
        "العضوية موقوفة",
        "تجاوز الحد المسموح من الإعارات"
    )

    /** Why a copy held for someone went back on the shelf. */
    val releaseReasons = listOf(
        "لم يُستلم خلال مدة الحجز",
        "ألغى المستعير طلبه",
        "طُلب الكتاب لاستخدام داخلي"
    )

    /** Why a copy is being written off as lost. */
    val lostReasons = listOf(
        "أبلغ المستعير عن فقدان النسخة",
        "تجاوز التأخير المدة المسموحة ولم يُرجع",
        "أُعيدت النسخة تالفة وغير صالحة"
    )

    /** Suggested tags offered as chips in the book form. */
    val suggestedTags = listOf(
        "تطوير الذات",
        "العادات",
        "علم النفس",
        "إدارة",
        "تاريخ",
        "علوم",
        "تقنية",
        "أدب",
        "رواية",
        "شعر",
        "سيرة ذاتية",
        "فلسفة"
    )

    /** Cover tints cycled through when a book has no photo. */
    val coverPalette = listOf(
        0xFF1F4E46, 0xFF2F6B5B, 0xFFB08D5E, 0xFF2E3A36,
        0xFF4A5D4E, 0xFF6B5B3E, 0xFF37514A, 0xFF8E7048
    )

    fun paletteFor(seed: String): Long =
        coverPalette[if (seed.isEmpty()) 0 else seed.length % coverPalette.size]
}

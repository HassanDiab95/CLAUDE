package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.Catalogs
import com.wujha.admin.data.model.Floor
import com.wujha.admin.data.model.Shelf
import com.wujha.admin.data.repository.DataStatus
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.DropdownField
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.ErrorView
import com.wujha.admin.ui.components.LoadingView
import com.wujha.admin.ui.components.LocationPickerFields
import com.wujha.admin.ui.components.LocationSelection
import com.wujha.admin.ui.components.PickerOption
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenWash
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * إدارة الرفوف — the bookcases themselves.
 *
 * A bookcase is always filed somewhere real: it belongs to an aisle, which
 * belongs to a block, which belongs to a floor, and all three are picked
 * from lists that come out of إدارة المواقع. There is no free-text location
 * field anywhere on this screen, which is what stops a bookcase from being
 * recorded in a block that does not exist on the floor it was put on.
 */
@Composable
fun ManageShelvesScreen(repository: LibraryRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val shelves by repository.shelves.collectAsState()
    val books by repository.books.collectAsState()
    val floors by repository.floors.collectAsState()
    val status by repository.status.collectAsState()

    var editing by remember { mutableStateOf<Shelf?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Shelf?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    ScreenScaffold(
        title = t("إدارة الرفوف"),
        onBack = onBack,
        actionLabel = t("رف جديد"),
        onAction = { editing = null; showForm = true }
    ) {
        when {
            status is DataStatus.Error ->
                ErrorView(message = (status as DataStatus.Error).message)

            status is DataStatus.Loading && shelves.isEmpty() ->
                LoadingView(message = t("جارٍ تحميل الرفوف..."))

            floors.isEmpty() -> EmptyView(
                icon = Icons.Outlined.Storage,
                title = t("عرّف أدوار المكتبة أولاً"),
                detail = t("الرف يُسند إلى ممر داخل بلوك داخل دور. أضف الأدوار والبلوكات والممرات من الإعدادات ← إدارة المواقع.")
            )

            shelves.isEmpty() -> EmptyView(
                icon = Icons.Outlined.Storage,
                title = t("لا توجد رفوف بعد"),
                detail = t("أضف رفوف المكتبة ليتمكّن الكتب من الإشارة إليها وتظهر على الخريطة."),
                actionLabel = t("إضافة رف"),
                onAction = { editing = null; showForm = true }
            )

            else -> LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = t("%s رف • %s كتاب موزّع").format(shelves.size, books.count { it.shelf.isNotBlank() }),
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
                items(shelves) { shelf ->
                    ShelfRow(
                        shelf = shelf,
                        bookCount = books.count { it.shelf == shelf.code },
                        onEdit = { editing = shelf; showForm = true },
                        onDelete = { deleting = shelf }
                    )
                }
            }
        }
    }

    if (showForm) {
        ShelfFormDialog(
            existing = editing,
            floors = floors,
            onDismiss = { showForm = false },
            onSave = { shelf ->
                showForm = false
                scope.launch {
                    errorMessage = if (editing == null) {
                        repository.addShelf(shelf)
                    } else {
                        repository.updateShelf(shelf)
                    }
                }
            }
        )
    }

    val toDelete = deleting
    if (toDelete != null) {
        val used = books.count { it.shelf == toDelete.code }
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = SurfaceWhite,
            title = { Text(t("حذف الرف %s").format(toDelete.code), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Text(
                    text = if (used > 0) {
                        t("يوجد %s كتاب مرتبط بهذا الرف. حذفه لن يحذف الكتب، لكنها ستبقى تشير إلى رف غير موجود.").format(used)
                    } else {
                        t("لا توجد كتب على هذا الرف. سيتم حذفه نهائياً.")
                    },
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch { errorMessage = repository.deleteShelf(toDelete) }
                }) { Text(t("حذف"), color = SignalRed, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(t("إلغاء"), color = TextSecondary) }
            }
        )
    }

    val err = errorMessage
    if (err != null) {
        AlertDialog(
            onDismissRequest = { errorMessage = null },
            containerColor = SurfaceWhite,
            title = { Text(t("تعذّر الحفظ"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = { Text(err, color = TextSecondary) },
            confirmButton = {
                TextButton(onClick = { errorMessage = null }) {
                    Text(t("حسناً"), color = ForestGreen, fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}

@Composable
private fun ShelfRow(shelf: Shelf, bookCount: Int, onEdit: () -> Unit, onDelete: () -> Unit) {
    val over = shelf.capacity in 1..bookCount
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = RoundedCornerShape(10.dp), color = ForestGreenWash) {
                Box(modifier = Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = shelf.code,
                        color = ForestGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    text = shelf.zone.ifBlank { shelf.floor.ifBlank { t("بدون قسم") } },
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = listOfNotNull(
                        shelf.floor.takeIf { it.isNotBlank() },
                        shelf.block.takeIf { it.isNotBlank() }?.let { t("بلوك %s").format(it) },
                        shelf.aisle.takeIf { it.isNotBlank() }?.let { t("ممر %s").format(it) }
                    ).joinToString(" • "),
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = listOfNotNull(
                        if (shelf.capacity > 0) t("%s من %s كتاب").format(bookCount, shelf.capacity) else t("%s كتاب").format(bookCount),
                        shelf.side.takeIf { it.isNotBlank() },
                        t("%s مستويات").format(shelf.levels)
                    ).joinToString(" • "),
                    color = if (over) SignalRed else TextSecondary,
                    fontSize = 11.sp
                )
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Outlined.Edit, contentDescription = t("تعديل"), tint = TextSecondary)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Outlined.Delete, contentDescription = t("حذف"), tint = SignalRed)
            }
        }
    }
}

@Composable
private fun ShelfFormDialog(
    existing: Shelf?,
    floors: List<Floor>,
    onDismiss: () -> Unit,
    onSave: (Shelf) -> Unit
) {
    var location by remember {
        mutableStateOf(
            LocationSelection(
                floorId = existing?.floorId.orEmpty(),
                floorName = existing?.floor.orEmpty(),
                block = existing?.block.orEmpty(),
                aisle = existing?.aisle.orEmpty()
            )
        )
    }
    var code by remember { mutableStateOf(existing?.code.orEmpty()) }
    var position by remember { mutableStateOf((existing?.position ?: 1).toString()) }
    var side by remember { mutableStateOf(existing?.side ?: Catalogs.sides.first()) }
    var levels by remember { mutableStateOf((existing?.levels ?: 3).toString()) }
    var capacity by remember { mutableStateOf((existing?.capacity ?: 120).toString()) }
    var zone by remember { mutableStateOf(existing?.zone.orEmpty()) }
    var notes by remember { mutableStateOf(existing?.notes.orEmpty()) }

    var codeError by remember { mutableStateOf<String?>(null) }
    var floorError by remember { mutableStateOf<String?>(null) }
    var blockError by remember { mutableStateOf<String?>(null) }
    var aisleError by remember { mutableStateOf<String?>(null) }

    // A code the librarian should not have to invent: floor, aisle, position.
    val suggested = remember(location, position, floors) {
        val floor = floors.firstOrNull { it.id == location.floorId }
        val floorCode = when {
            floor == null -> ""
            floor.order == 0 -> "G"
            else -> floor.order.toString()
        }
        if (floorCode.isBlank() || location.aisle.isBlank()) ""
        else "$floorCode-${location.aisle}-${position.ifBlank { "1" }}"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = {
            Text(
                text = if (existing == null) t("إضافة رف جديد") else t("تعديل الرف %s").format(existing.code),
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
            Column(modifier = Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                LocationPickerFields(
                    floors = floors,
                    selection = location,
                    onChange = {
                        location = it
                        floorError = null; blockError = null; aisleError = null
                    },
                    floorError = floorError,
                    blockError = blockError,
                    aisleError = aisleError
                )

                Spacer(Modifier.height(12.dp))
                DropdownField(
                    label = t("الترتيب على الممر"),
                    options = (1..12).map { PickerOption(it.toString(), t("الرف رقم %s").format(it)) },
                    selectedValue = position,
                    onSelect = { position = it }
                )

                Spacer(Modifier.height(12.dp))
                DropdownField(
                    label = t("جهة الممر"),
                    options = Catalogs.sides.map { PickerOption(it, t(it)) },
                    selectedValue = side,
                    onSelect = { side = it }
                )

                Spacer(Modifier.height(12.dp))
                WujhaTextField(
                    value = code,
                    onValueChange = { code = it; codeError = null },
                    placeholder = if (suggested.isBlank()) t("رمز الرف المطبوع عليه") else t("رمز الرف (مقترح: %s)").format(suggested),
                    errorText = codeError
                )
                if (suggested.isNotBlank() && code.isBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        onClick = { code = suggested },
                        shape = RoundedCornerShape(10.dp),
                        color = ForestGreenWash
                    ) {
                        Text(
                            text = t("استخدام %s").format(suggested),
                            color = ForestGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                DropdownField(
                    label = t("عدد مستويات الرف"),
                    options = Catalogs.levelCounts.map { PickerOption(it.toString(), t("%s مستويات").format(it)) },
                    selectedValue = levels,
                    onSelect = { levels = it }
                )

                Spacer(Modifier.height(12.dp))
                DropdownField(
                    label = t("السعة"),
                    options = Catalogs.capacities.map { PickerOption(it.toString(), t("%s كتاب").format(it)) },
                    selectedValue = capacity,
                    onSelect = { capacity = it }
                )

                Spacer(Modifier.height(12.dp))
                WujhaTextField(
                    value = zone,
                    onValueChange = { zone = it },
                    placeholder = t("القسم الموضوعي (مثال: الروايات العربية)")
                )
                Spacer(Modifier.height(10.dp))
                WujhaTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    placeholder = t("ملاحظات (اختياري)")
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                floorError = if (location.floorId.isBlank()) t("اختر الدور") else null
                blockError = if (location.block.isBlank()) t("اختر البلوك") else null
                aisleError = if (location.aisle.isBlank()) t("اختر الممر") else null
                val finalCode = code.trim().ifBlank { suggested }
                codeError = if (finalCode.isBlank()) t("الرجاء إدخال رمز الرف") else null

                if (floorError == null && blockError == null && aisleError == null && codeError == null) {
                    onSave(
                        Shelf(
                            id = existing?.id.orEmpty(),
                            code = finalCode.uppercase(),
                            floorId = location.floorId,
                            floor = location.floorName,
                            block = location.block,
                            aisle = location.aisle,
                            position = position.toIntOrNull() ?: 1,
                            side = side,
                            levels = levels.toIntOrNull() ?: 3,
                            zone = zone.trim(),
                            capacity = capacity.toIntOrNull() ?: 0,
                            notes = notes.trim()
                        )
                    )
                }
            }) { Text(t("حفظ"), color = ForestGreen, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(t("إلغاء"), color = TextSecondary) }
        }
    )
}

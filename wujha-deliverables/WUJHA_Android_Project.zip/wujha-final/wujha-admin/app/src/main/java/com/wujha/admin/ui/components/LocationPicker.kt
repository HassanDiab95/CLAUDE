package com.wujha.admin.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wujha.admin.data.model.Floor
import com.wujha.admin.data.t

/**
 * Where something is, as far down the building as the caller needs.
 *
 * Held as one value rather than four loose fields so the cascade below can
 * clear the parts that stop making sense the moment a parent changes.
 */
data class LocationSelection(
    val floorId: String = "",
    val floorName: String = "",
    val block: String = "",
    val aisle: String = ""
)

/**
 * Floor, then block, then aisle — each list drawn from the one above it.
 *
 * This is the whole reason the building is stored as data: picking الدور
 * الأول can only offer the blocks that exist on the first floor, and picking
 * a block can only offer that block's aisles. It is impossible to file a
 * bookcase into a block that is on a different floor, because that block is
 * never in the list.
 *
 * Changing a parent clears its children rather than leaving a stale value
 * behind — a block code from the previous floor would otherwise be saved as
 * if it belonged to the new one.
 */
@Composable
fun LocationPickerFields(
    floors: List<Floor>,
    selection: LocationSelection,
    onChange: (LocationSelection) -> Unit,
    modifier: Modifier = Modifier,
    floorLabel: String = t("الدور"),
    blockLabel: String = t("البلوك"),
    aisleLabel: String = t("الممر"),
    floorError: String? = null,
    blockError: String? = null,
    aisleError: String? = null,
    showAisle: Boolean = true
) {
    val floor = floors.firstOrNull { it.id == selection.floorId }
    val block = floor?.block(selection.block)

    Column(modifier = modifier.fillMaxWidth()) {
        DropdownField(
            label = floorLabel,
            options = floors.map { PickerOption(it.id, it.name) },
            selectedValue = selection.floorId,
            onSelect = { id ->
                val picked = floors.firstOrNull { it.id == id }
                onChange(
                    LocationSelection(
                        floorId = id,
                        floorName = picked?.name.orEmpty(),
                        block = "",
                        aisle = ""
                    )
                )
            },
            errorText = floorError,
            emptyHint = t("لا توجد أدوار — أضفها من إدارة المواقع")
        )

        Spacer(Modifier.height(12.dp))
        DropdownField(
            label = blockLabel,
            options = floor?.blocks.orEmpty().map {
                PickerOption(it.code, t("%s — %s").format(it.code, it.name.ifBlank { t("بلا اسم") }))
            },
            selectedValue = selection.block,
            onSelect = { code -> onChange(selection.copy(block = code, aisle = "")) },
            errorText = blockError,
            emptyHint = when {
                selection.floorId.isBlank() -> t("اختر الدور أولاً")
                else -> t("لا توجد بلوكات في هذا الدور")
            }
        )

        if (showAisle) {
            Spacer(Modifier.height(12.dp))
            DropdownField(
                label = aisleLabel,
                options = block?.aisles.orEmpty().map {
                    PickerOption(it.code, t("%s — %s").format(it.code, it.name.ifBlank { t("بلا اسم") }))
                },
                selectedValue = selection.aisle,
                onSelect = { code -> onChange(selection.copy(aisle = code)) },
                errorText = aisleError,
                emptyHint = when {
                    selection.block.isBlank() -> t("اختر البلوك أولاً")
                    else -> t("لا توجد ممرات في هذا البلوك")
                }
            )
        }
    }
}

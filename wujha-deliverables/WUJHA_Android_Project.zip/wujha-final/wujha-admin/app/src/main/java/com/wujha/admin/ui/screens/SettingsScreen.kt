package com.wujha.admin.ui.screens

import com.wujha.admin.ui.theme.TextOnPrimary
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.ExitToApp
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.SeedData
import com.wujha.admin.data.auth.AuthProviderHolder
import com.wujha.admin.data.repository.AccountProvider
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.ProfilePhotoPicker
import com.wujha.admin.ui.theme.AccentGold
import com.wujha.admin.ui.theme.AccentGoldWash
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackground
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.ForestGreenWash
import com.wujha.admin.ui.theme.SignalRed
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

private data class SettingsRow(
    val key: String,
    val icon: ImageVector,
    val label: String,
    val detail: String,
    val destructive: Boolean = false
)

/**
 * The rows, in Arabic.
 *
 * The labels stay untranslated here on purpose: this list is built once when
 * the file is loaded, so a `t(...)` in it would capture whichever language
 * happened to be active at that moment and never change again. They are
 * translated in [SettingsRowItem], which runs on every recomposition.
 */
private val settingsRows = listOf(
    SettingsRow("locations", Icons.Outlined.Layers, "إدارة المواقع", "الأدوار والبلوكات والممرات"),
    SettingsRow("shelves", Icons.Outlined.Storage, "إدارة الرفوف", "رفوف المكتبة وأماكنها وسعتها"),
    SettingsRow("categories", Icons.Outlined.Category, "إدارة التصنيفات", "تصنيفات الكتب المعروضة للزوار"),
    SettingsRow("loan_settings", Icons.Outlined.SwapHoriz, "إعدادات الإعارة", "المدة والحدود والتجديد"),
    SettingsRow("admins", Icons.Outlined.AdminPanelSettings, "المشرفون والصلاحيات", "من يملك حق التعديل"),
    SettingsRow("language", Icons.Outlined.Language, "اللغة والمظهر", "العربية أو الإنجليزية، فاتح أو داكن"),
    SettingsRow("notifications", Icons.Outlined.NotificationsNone, "الإشعارات", "تنبيهات السعة والأعضاء"),
    SettingsRow("backup", Icons.Outlined.Backup, "النسخ الاحتياطي", "تصدير الفهرس كملف JSON"),
    SettingsRow("activity", Icons.Outlined.History, "سجل النشاط", "كل تعديل ومن قام به"),
    SettingsRow("help", Icons.Outlined.HelpOutline, "مساعدة والدعم", "أسئلة شائعة وشرح سريع"),
    SettingsRow("signout", Icons.Outlined.ExitToApp, "تسجيل الخروج", "", destructive = true)
)

/**
 * The admin settings hub.
 *
 * The starter-data card at the top is the only thing here that is
 * conditional, and deliberately so: it appears for the account that claimed
 * an empty library, and vanishes for everyone the moment the seed finishes.
 */
@Composable
fun SettingsScreen(
    repository: LibraryRepository,
    onOpen: (String) -> Unit,
    onSignedOut: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val authRepository = AuthProviderHolder.repository
    val accountRepository = AccountProvider.repository
    val currentUser by authRepository.currentUser.collectAsState()
    val profile by accountRepository.profile.collectAsState()
    val role by repository.role.collectAsState()
    val seedAvailable by repository.seedAvailable.collectAsState()

    var showSignOutDialog by remember { mutableStateOf(false) }
    var seeding by remember { mutableStateOf(false) }
    var seedResult by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Text(
                text = t("الإعدادات"),
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = TextPrimary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            )
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                shape = RoundedCornerShape(16.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(t("مسجّل الدخول باسم"), fontSize = 12.sp, color = TextSecondary)
                            Text(
                                text = profile?.name?.takeIf { it.isNotBlank() }
                                    ?: currentUser?.displayName
                                    ?: t("مشرف"),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextPrimary
                            )
                            Text(
                                text = currentUser?.email?.takeIf { it.isNotBlank() }
                                    ?: t("مكتبة وجهة — الفرع الرئيسي"),
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                        RoleBadge(role?.labelAr?.let { t(it) })
                    }
                    Spacer(Modifier.height(14.dp))
                    ProfilePhotoPicker(
                        photoBase64 = profile?.photoBase64.orEmpty(),
                        initial = profile?.initial ?: t("م"),
                        accountRepository = accountRepository
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        // Offered once, to the account that claimed an empty library. The
        // flag behind it lives on meta/setup, so once the seed completes it
        // is gone for every admin on every device — there is no second run.
        if (seedAvailable) {
            item {
                SeedCard(
                    seeding = seeding,
                    onRun = {
                        if (!seeding) {
                            seeding = true
                            scope.launch {
                                val error = repository.seedInitialData()
                                seeding = false
                                seedResult = error
                                    ?: t("تم إدخال البيانات الأولية: %s أدوار، %s رف، %s كتاب.").format(SeedData.floors.size, SeedData.shelves.size, SeedData.books.size)
                            }
                        }
                    }
                )
                Spacer(Modifier.height(16.dp))
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                shape = RoundedCornerShape(16.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column {
                    settingsRows.forEachIndexed { index, row ->
                        SettingsRowItem(row) {
                            if (row.key == "signout") showSignOutDialog = true else onOpen(row.key)
                        }
                        if (index != settingsRows.lastIndex) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp)
                                    .height(1.dp)
                                    .background(BorderLight)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSignOutDialog) {
        AlertDialog(
            onDismissRequest = { showSignOutDialog = false },
            containerColor = SurfaceWhite,
            title = { Text(t("تسجيل الخروج"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = { Text(t("هل أنت متأكد من تسجيل الخروج من لوحة التحكم؟"), color = TextSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    showSignOutDialog = false
                    authRepository.signOut()
                    onSignedOut()
                }) {
                    Text(t("تسجيل الخروج"), color = SignalRed, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutDialog = false }) {
                    Text(t("إلغاء"), color = TextSecondary)
                }
            }
        )
    }

    ResultDialog(seedResult) { seedResult = null }
}

@Composable
private fun RoleBadge(label: String?) {
    if (label == null) return
    Surface(shape = RoundedCornerShape(20.dp), color = ForestGreenWash) {
        Text(
            text = label,
            color = ForestGreen,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun SeedCard(seeding: Boolean, onRun: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        shape = RoundedCornerShape(16.dp),
        color = AccentGoldWash
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Outlined.CloudUpload,
                    contentDescription = null,
                    tint = AccentGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = t("تجهيز المكتبة لأول مرة"),
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = t("قاعدة البيانات فارغة، وحسابك هو أول حساب فيها. يمكنك إدخال مكتبة تجريبية كاملة: %s أدوار ببلوكاتها وممراتها، %s رفاً، %s تصنيفاً، %s عضواً، و%s كتاباً.").format(SeedData.floors.size, SeedData.shelves.size, SeedData.categories.size, SeedData.members.size, SeedData.books.size),
                color = TextSecondary,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = t("تُنفَّذ هذه الخطوة مرة واحدة فقط في عمر قاعدة البيانات، ولن تظهر مرة أخرى لك ولا لأي مشرف آخر."),
                color = AccentGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(12.dp))
            Surface(
                onClick = onRun,
                shape = RoundedCornerShape(12.dp),
                color = ForestGreen
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (seeding) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = TextOnPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = t("إدخال البيانات الأولية"),
                            color = TextOnPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsRowItem(row: SettingsRow, onClick: () -> Unit) {
    val color = if (row.destructive) SignalRed else TextPrimary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(row.icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
            Text(text = t(row.label), fontSize = 13.sp, color = color, fontWeight = FontWeight.Medium)
            if (row.detail.isNotBlank()) {
                Text(text = t(row.detail), fontSize = 11.sp, color = TextSecondary)
            }
        }
        Icon(Icons.Outlined.ChevronLeft, contentDescription = null, tint = TextSecondary)
    }
}

package com.wujha.admin.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.wujha.admin.data.Catalogs
import com.wujha.admin.data.model.Book
import com.wujha.admin.data.model.BookStatus
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.storage.ImageCodec
import com.wujha.admin.data.storage.UploadResult
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.DropdownField
import com.wujha.admin.ui.components.LocationPickerFields
import com.wujha.admin.ui.components.LocationSelection
import com.wujha.admin.ui.components.FormErrorBanner
import com.wujha.admin.ui.components.PickerOption
import com.wujha.admin.ui.components.PrimaryButton
import com.wujha.admin.ui.components.TagChipRow
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.CreamBackground
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.StatusLostText
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Add or edit a catalog entry.
 *
 * Everything with a known set of valid values is a dropdown rather than a
 * text box — categories and shelves come live from Firestore, floors,
 * sections, languages and statuses from [Catalogs] — so the same shelf is
 * never recorded two different ways. Picking a shelf fills in its floor and
 * section automatically.
 *
 * @param bookId null to create, otherwise the entry being edited.
 */
@Composable
fun BookFormScreen(
    bookId: String?,
    repository: LibraryRepository,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val allBooks by repository.books.collectAsState()
    val categories by repository.categories.collectAsState()
    val shelves by repository.shelves.collectAsState()
    val floors by repository.floors.collectAsState()

    val existing = remember(bookId, allBooks) { allBooks.find { it.id == bookId } }
    val isEdit = existing != null

    var title by remember(existing) { mutableStateOf(existing?.title.orEmpty()) }
    var author by remember(existing) { mutableStateOf(existing?.author.orEmpty()) }
    var category by remember(existing) { mutableStateOf(existing?.category.orEmpty()) }
    var shelf by remember(existing) { mutableStateOf(existing?.shelf.orEmpty()) }
    var level by remember(existing) { mutableStateOf(existing?.section.orEmpty()) }
    var location by remember(existing) {
        mutableStateOf(
            LocationSelection(
                floorId = existing?.floorId.orEmpty(),
                floorName = existing?.floor.orEmpty(),
                block = existing?.block.orEmpty(),
                aisle = existing?.aisle.orEmpty()
            )
        )
    }
    var status by remember(existing) { mutableStateOf(existing?.status ?: BookStatus.AVAILABLE) }
    var language by remember(existing) { mutableStateOf(existing?.language ?: "العربية") }
    var publisher by remember(existing) { mutableStateOf(existing?.publisher.orEmpty()) }
    var serial by remember(existing) { mutableStateOf(existing?.serial.orEmpty()) }
    var copies by remember(existing) { mutableStateOf((existing?.copies ?: 1).toString()) }
    var pageCount by remember(existing) { mutableStateOf((existing?.pageCount ?: 0).toString()) }
    var description by remember(existing) { mutableStateOf(existing?.description.orEmpty()) }
    var notes by remember(existing) { mutableStateOf(existing?.notes.orEmpty()) }
    var tags by remember(existing) { mutableStateOf(existing?.tags.orEmpty()) }

    var coverBase64 by remember(existing) { mutableStateOf(existing?.coverBase64.orEmpty()) }
    var pickedImage by remember { mutableStateOf<Uri?>(null) }

    var titleError by remember { mutableStateOf<String?>(null) }
    var authorError by remember { mutableStateOf<String?>(null) }
    var categoryError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) pickedImage = uri }

    fun save() {
        if (saving) return
        titleError = if (title.isBlank()) t("الرجاء إدخال عنوان الكتاب") else null
        authorError = if (author.isBlank()) t("الرجاء إدخال اسم المؤلف") else null
        categoryError = if (category.isBlank()) t("الرجاء اختيار التصنيف") else null
        if (titleError != null || authorError != null || categoryError != null) return

        formError = null
        saving = true
        scope.launch {
            // Encode a newly picked photo first, so the book document is
            // saved with a Base64 payload that's already ready to display.
            var finalBase64 = coverBase64
            val picked = pickedImage
            if (picked != null) {
                uploadProgress = true
                when (val result = ImageCodec.encode(context, picked)) {
                    is UploadResult.Success -> {
                        finalBase64 = result.base64
                    }
                    is UploadResult.Failure -> {
                        uploadProgress = false
                        saving = false
                        formError = result.message
                        return@launch
                    }
                }
                uploadProgress = false
            }

            val book = Book(
                id = existing?.id.orEmpty(),
                title = title.trim(),
                author = author.trim(),
                category = category,
                coverColor = existing?.coverColor ?: Catalogs.paletteFor(title),
                coverBase64 = finalBase64,
                status = status,
                shelf = shelf,
                section = level,
                floorId = location.floorId,
                floor = location.floorName,
                block = location.block,
                aisle = location.aisle,
                serial = serial.trim(),
                dateAdded = existing?.dateAdded.orEmpty().ifBlank { today() },
                copies = copies.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                notes = notes.trim(),
                description = description.trim(),
                tags = tags,
                publisher = publisher.trim(),
                language = language,
                pageCount = pageCount.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                rating = existing?.rating ?: 0.0,
                ratingCount = existing?.ratingCount ?: 0
            )

            val error = if (isEdit) repository.updateBook(book) else repository.addBook(book)
            saving = false
            if (error == null) onDone() else formError = error
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CreamBackground)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, enabled = !saving) {
                Icon(Icons.Outlined.ArrowForward, contentDescription = t("رجوع"), tint = TextPrimary)
            }
            Text(
                text = if (isEdit) t("تعديل كتاب") else t("إضافة كتاب جديد"),
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = TextPrimary
            )
        }

        Column(modifier = Modifier.padding(horizontal = 20.dp)) {

            // ---- Cover photo -------------------------------------------------
            Text(t("صورة الغلاف"), color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .width(96.dp)
                        .aspectRatio(0.72f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(existing?.coverColor ?: Catalogs.paletteFor(title))),
                    contentAlignment = Alignment.Center
                ) {
                    val existingBitmap = remember(coverBase64) { ImageCodec.decode(coverBase64) }
                    when {
                        pickedImage != null -> AsyncImage(
                            model = pickedImage,
                            contentDescription = t("الغلاف المختار"),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )
                        existingBitmap != null -> Image(
                            bitmap = existingBitmap.asImageBitmap(),
                            contentDescription = t("غلاف الكتاب"),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )
                        else -> Icon(
                            imageVector = Icons.Outlined.AddAPhoto,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    if (uploadProgress) {
                        Box(
                            modifier = Modifier.matchParentSize().background(Color(0x99000000)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp)
                        }
                    }
                }

                Column(modifier = Modifier.padding(start = 14.dp).weight(1f)) {
                    Surface(
                        onClick = {
                            imagePicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        enabled = !saving,
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceWhite,
                        border = BorderStroke(1.dp, BorderLight)
                    ) {
                        Text(
                            text = if (pickedImage != null || coverBase64.isNotBlank()) t("تغيير الصورة") else t("اختيار صورة"),
                            color = ForestGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                        )
                    }
                    if (pickedImage != null || coverBase64.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            onClick = { pickedImage = null; coverBase64 = "" },
                            enabled = !saving,
                            shape = RoundedCornerShape(10.dp),
                            color = SurfaceWhite,
                            border = BorderStroke(1.dp, BorderLight)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.Delete,
                                    contentDescription = null,
                                    tint = StatusLostText,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(t("إزالة"), color = StatusLostText, fontSize = 13.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = t("اختياري — إن لم تُرفع صورة سيُعرض غلاف ملوّن بحرف العنوان."),
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            // ---- Identity ----------------------------------------------------
            SectionLabel(t("بيانات الكتاب"))
            WujhaTextField(
                value = title,
                onValueChange = { title = it; titleError = null },
                placeholder = t("عنوان الكتاب"),
                enabled = !saving,
                errorText = titleError
            )
            Spacer(Modifier.height(10.dp))
            WujhaTextField(
                value = author,
                onValueChange = { author = it; authorError = null },
                placeholder = t("المؤلف"),
                enabled = !saving,
                errorText = authorError
            )
            Spacer(Modifier.height(12.dp))

            DropdownField(
                label = t("التصنيف"),
                options = categories.map { PickerOption(it.id, it.name) },
                selectedValue = category,
                onSelect = { category = it; categoryError = null },
                errorText = categoryError,
                emptyHint = t("لا توجد تصنيفات — أضفها من إدارة التصنيفات")
            )
            Spacer(Modifier.height(12.dp))

            DropdownField(
                label = t("الحالة"),
                options = BookStatus.entries.map { PickerOption(it.name, t(it.labelAr)) },
                selectedValue = status.name,
                onSelect = { status = BookStatus.from(it) }
            )

            Spacer(Modifier.height(18.dp))

            // ---- Location ----------------------------------------------------
            // Floor, then block, then aisle, then the bookcase standing in
            // that aisle, then the level of that bookcase. Each list is built
            // from the one above it, so a book cannot be filed onto a
            // bookcase that is not where the form says it is.
            SectionLabel(t("الموقع في المكتبة"))
            LocationPickerFields(
                floors = floors,
                selection = location,
                onChange = { next ->
                    location = next
                    // The bookcase belonged to the old place; it no longer applies.
                    if (shelves.none { it.code == shelf && matchesLocation(it, next) }) {
                        shelf = ""
                        level = ""
                    }
                }
            )
            Spacer(Modifier.height(12.dp))

            val candidateShelves = remember(shelves, location) {
                shelves.filter { matchesLocation(it, location) }
            }
            DropdownField(
                label = t("الرف"),
                options = candidateShelves.map {
                    PickerOption(
                        it.code,
                        buildString {
                            append(it.code)
                            if (it.zone.isNotBlank()) append(" — ").append(it.zone)
                            if (it.position > 0) append(t(" (رقم ")).append(it.position).append(")")
                        }
                    )
                },
                selectedValue = shelf,
                onSelect = { code ->
                    shelf = code
                    // Adopt the bookcase's own place, which is the source of
                    // truth, and drop a level the new bookcase does not have.
                    shelves.firstOrNull { it.code == code }?.let { picked ->
                        location = LocationSelection(
                            floorId = picked.floorId,
                            floorName = picked.floor,
                            block = picked.block,
                            aisle = picked.aisle
                        )
                        if (level !in picked.levelNames()) level = ""
                    }
                },
                emptyHint = when {
                    floors.isEmpty() -> t("عرّف الأدوار أولاً من إدارة المواقع")
                    location.floorId.isBlank() -> t("اختر الدور والبلوك والممر أولاً")
                    else -> t("لا توجد رفوف في هذا الممر")
                }
            )
            Spacer(Modifier.height(12.dp))

            val pickedShelf = remember(shelf, shelves) { shelves.firstOrNull { it.code == shelf } }
            DropdownField(
                label = t("مستوى الرف"),
                options = pickedShelf?.levelNames().orEmpty().map { PickerOption(it, t(it)) },
                selectedValue = level,
                onSelect = { level = it },
                emptyHint = t("اختر الرف أولاً")
            )

            Spacer(Modifier.height(18.dp))

            // ---- Publication --------------------------------------------------
            SectionLabel(t("بيانات النشر"))
            DropdownField(
                label = t("اللغة"),
                options = Catalogs.languages.map { PickerOption(it, t(it)) },
                selectedValue = language,
                onSelect = { language = it }
            )
            Spacer(Modifier.height(10.dp))
            WujhaTextField(
                value = publisher,
                onValueChange = { publisher = it },
                placeholder = t("دار النشر"),
                enabled = !saving
            )
            Spacer(Modifier.height(10.dp))
            DropdownField(
                label = t("عدد النسخ"),
                options = Catalogs.copyCounts.map { PickerOption(it.toString(), t("%s نسخة").format(it)) },
                selectedValue = copies,
                onSelect = { copies = it }
            )
            Spacer(Modifier.height(10.dp))
            WujhaTextField(
                value = pageCount,
                onValueChange = { input -> pageCount = input.filter { it.isDigit() }.take(5) },
                placeholder = t("عدد الصفحات"),
                keyboardType = KeyboardType.Number,
                enabled = !saving
            )
            Spacer(Modifier.height(10.dp))
            WujhaTextField(
                value = serial,
                onValueChange = { serial = it },
                placeholder = t("الرقم التسلسلي"),
                enabled = !saving
            )

            Spacer(Modifier.height(18.dp))

            // ---- Description --------------------------------------------------
            SectionLabel(t("الوصف والتصنيفات"))
            WujhaTextField(
                value = description,
                onValueChange = { description = it },
                placeholder = t("نبذة عن الكتاب"),
                enabled = !saving,
                singleLine = false,
                fieldHeight = 110
            )
            Spacer(Modifier.height(12.dp))
            TagChipRow(
                label = t("الوسوم"),
                allTags = Catalogs.suggestedTags,
                selected = tags,
                onToggle = { tag ->
                    tags = if (tags.contains(tag)) tags - tag else tags + tag
                }
            )
            Spacer(Modifier.height(12.dp))
            WujhaTextField(
                value = notes,
                onValueChange = { notes = it },
                placeholder = t("ملاحظات داخلية (اختياري)"),
                enabled = !saving,
                singleLine = false,
                fieldHeight = 80
            )

            Spacer(Modifier.height(20.dp))

            if (formError != null) {
                FormErrorBanner(message = formError.orEmpty())
                Spacer(Modifier.height(12.dp))
            }

            PrimaryButton(
                text = if (isEdit) t("حفظ التعديلات") else t("إضافة الكتاب"),
                onClick = { save() },
                loading = saving
            )

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = TextPrimary,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 10.dp)
    )
}

/** Today's date as yyyy-MM-dd, for the dateAdded field. */
private fun today(): String {
    val now = java.util.Calendar.getInstance()
    return "%04d-%02d-%02d".format(
        now.get(java.util.Calendar.YEAR),
        now.get(java.util.Calendar.MONTH) + 1,
        now.get(java.util.Calendar.DAY_OF_MONTH)
    )
}

/**
 * True when [shelf] stands in the place the form currently describes.
 *
 * A blank part of the selection matches everything, so the bookcase list
 * narrows as the librarian works downwards instead of going empty until all
 * three are chosen.
 */
private fun matchesLocation(
    shelf: com.wujha.admin.data.model.Shelf,
    location: LocationSelection
): Boolean =
    (location.floorId.isBlank() || shelf.floorId == location.floorId) &&
        (location.block.isBlank() || shelf.block == location.block) &&
        (location.aisle.isBlank() || shelf.aisle == location.aisle)

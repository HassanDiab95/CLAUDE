package com.wujha.admin.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.PreferencesProvider
import com.wujha.admin.data.model.Category
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.PrimaryButton
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.components.WujhaTextField
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.StatusLostText
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary
import kotlinx.coroutines.launch

// ---------------------------------------------------------------------------
// إدارة التصنيفات
// ---------------------------------------------------------------------------

/** Categories are what the book form's التصنيف dropdown offers. */
@Composable
fun ManageCategoriesScreen(repository: LibraryRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val categories by repository.categories.collectAsState()
    val books by repository.books.collectAsState()

    var showAdd by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Category?>(null) }

    ScreenScaffold(
        title = t("إدارة التصنيفات"),
        onBack = onBack,
        actionLabel = t("تصنيف"),
        onAction = { showAdd = true }
    ) {
        if (categories.isEmpty()) {
            EmptyView(
                icon = Icons.Outlined.Category,
                title = t("لا توجد تصنيفات"),
                detail = t("أضف تصنيفات مثل الأدب والعلوم ليختار منها الكتاب عند الإضافة."),
                actionLabel = t("إضافة تصنيف"),
                onAction = { showAdd = true }
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(categories) { category ->
                    val count = books.count { it.category == category.id }
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = SurfaceWhite,
                        border = BorderStroke(1.dp, BorderLight)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = category.name,
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = t("%s كتاب").format(count),
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                            IconButton(onClick = { deleting = category }) {
                                Icon(Icons.Outlined.Delete, contentDescription = t("حذف"), tint = StatusLostText)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var nameError by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = SurfaceWhite,
            title = { Text(t("تصنيف جديد"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                WujhaTextField(
                    value = name,
                    onValueChange = { name = it; nameError = null },
                    placeholder = t("اسم التصنيف"),
                    errorText = nameError
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isBlank()) {
                        nameError = t("الرجاء إدخال اسم التصنيف")
                    } else {
                        val value = name.trim()
                        showAdd = false
                        scope.launch { repository.addCategory(Category(name = value, iconKey = "book")) }
                    }
                }) { Text(t("إضافة"), color = ForestGreen, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false }) { Text(t("إلغاء"), color = TextSecondary) }
            }
        )
    }

    val toDelete = deleting
    if (toDelete != null) {
        val count = books.count { it.category == toDelete.id }
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = SurfaceWhite,
            title = { Text(t("حذف %s").format(toDelete.name), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Text(
                    text = if (count > 0) t("يوجد %s كتاب في هذا التصنيف وسيبقى بلا تصنيف.").format(count)
                    else t("لا توجد كتب في هذا التصنيف."),
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch { repository.deleteCategory(toDelete) }
                }) { Text(t("حذف"), color = StatusLostText, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(t("إلغاء"), color = TextSecondary) }
            }
        )
    }
}

// ---------------------------------------------------------------------------
// الإشعارات
// ---------------------------------------------------------------------------

/** Notification switches, stored per device. */
@Composable
fun NotificationSettingsScreen(onBack: () -> Unit) {
    val preferences = PreferencesProvider.preferences
    val settings by preferences.settings.collectAsState()

    ScreenScaffold(title = t("الإشعارات"), onBack = onBack) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Text(
                text = t("تُحفظ هذه الإعدادات على هذا الجهاز فقط."),
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column {
                    settings.forEachIndexed { index, setting ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = setting.label,
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = setting.detail,
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            Switch(
                                checked = setting.enabled,
                                onCheckedChange = { preferences.toggle(setting.key) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = ForestGreen
                                )
                            )
                        }
                        if (index != settings.lastIndex) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp)
                                    .height(1.dp)
                                    .background(BorderLight)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// النسخ الاحتياطي
// ---------------------------------------------------------------------------

/**
 * Exports the whole catalog as JSON and hands it to Android's share sheet,
 * so it can go to Drive, email or a file manager.
 */
@Composable
fun BackupScreen(repository: LibraryRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val books by repository.books.collectAsState()
    val shelves by repository.shelves.collectAsState()
    val members by repository.members.collectAsState()
    val categories by repository.categories.collectAsState()

    ScreenScaffold(title = t("النسخ الاحتياطي"), onBack = onBack) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Text(
                text = t("تصدير نسخة من بيانات المكتبة بصيغة JSON لحفظها خارج التطبيق."),
                color = TextSecondary,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(16.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    BackupCountRow(t("الكتب"), books.size)
                    BackupCountRow(t("الرفوف"), shelves.size)
                    BackupCountRow(t("أعضاء المكتبة"), members.size)
                    BackupCountRow(t("التصنيفات"), categories.size)
                }
            }

            Spacer(Modifier.height(20.dp))
            PrimaryButton(
                text = t("تصدير ومشاركة"),
                onClick = {
                    val json = repository.exportAsJson()
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        putExtra(Intent.EXTRA_SUBJECT, t("نسخة احتياطية - مكتبة وجهة"))
                        putExtra(Intent.EXTRA_TEXT, json)
                    }
                    context.startActivity(Intent.createChooser(intent, t("مشاركة النسخة الاحتياطية")))
                }
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = t("ملاحظة: الاستعادة من نسخة احتياطية غير متاحة من التطبيق — تتم من لوحة تحكم Firebase مباشرة."),
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BackupCountRow(label: String, count: Int) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSecondary, fontSize = 13.sp)
        Text(
            text = count.toString(),
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

// ---------------------------------------------------------------------------
// مساعدة والدعم
// ---------------------------------------------------------------------------

private data class HelpItem(val question: String, val answer: String)

/**
 * Built once when the file loads, so the strings stay in Arabic here and are
 * translated where they are drawn.
 */
private val helpItems = listOf(
    HelpItem(
        "كيف أضيف كتاباً جديداً؟",
        "من تبويب الكتب اضغط زر «إضافة»، ثم املأ البيانات. الحقول ذات القيم المحددة تُختار من قائمة منسدلة، ويمكنك رفع صورة الغلاف من معرض الصور."
    ),
    HelpItem(
        "لماذا لا تظهر الرفوف في قائمة الكتاب؟",
        "لأن الرفوف تُدار من الإعدادات ← إدارة الرفوف. أضف الرف أولاً ثم سيظهر في قائمة الكتاب."
    ),
    HelpItem(
        "ما الفرق بين المستخدمين والمشرفين؟",
        "«المستخدمون» هم أعضاء المكتبة: سجلّ من يحقّ له الاستعارة، معرّفه رقم الهوية، ويُسجَّل من مكتب الاستعارة حتى لو لم يفتح التطبيق، ولا يمنحه ذلك أي صلاحية. أما المشرف فهو حساب في التطبيق تُمنح له صلاحية التعديل من الإعدادات ← المشرفون والصلاحيات."
    ),
    HelpItem(
        "كيف تسير دورة الإعارة؟",
        "من تبويب الإعارة. طلبات تطبيق الزائر تأتي «قيد المراجعة» مع صورة الهوية: تقارن الصورة بالبيانات، تؤكّد المطابقة، ثم توافق فتُحجز نسخة باسم المستعير. عند حضوره تضغط «تسليم الكتاب» فيبدأ العدّ حتى تاريخ الإرجاع، وعند رجوعه تضغط «استرجاع الكتاب» فتعود النسخة للرف. وللعضو الذي لا يملك التطبيق استخدم «إعارة يدوية»."
    ),
    HelpItem(
        "لماذا لا أستطيع إعارة كتاب متوفر؟",
        "لأن المتاح يُحسب من عدد النسخ ناقص المحجوز والمُعار. إن كانت كل النسخ خارج الرف فلا إعارة جديدة حتى تُسترجع واحدة، أو تُضيف نسخة من صفحة الكتاب. ويُرفض كذلك إن كانت عضوية المستعير موقوفة أو تجاوز الحد المسموح من الإعارات."
    ),
    HelpItem(
        "ظهرت رسالة «لا تملك صلاحية الوصول»",
        "يعني أن حسابك لا يملك صلاحية المشرف. أول حساب يسجّل الدخول إلى قاعدة بيانات فارغة يصبح مالك المكتبة تلقائياً، وبعد ذلك يمنح المشرفون الصلاحية لغيرهم من الإعدادات ← المشرفون والصلاحيات."
    ),
    HelpItem(
        "هل تُحفظ البيانات محلياً؟",
        "لا. كل البيانات تُقرأ وتُكتب مباشرة في Cloud Firestore، لذا يحتاج التطبيق اتصالاً بالإنترنت."
    )
)

@Composable
fun HelpScreen(onBack: () -> Unit) {
    ScreenScaffold(title = t("مساعدة والدعم"), onBack = onBack) {
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(helpItems) { item ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = t(item.question),
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = t(item.answer),
                            color = TextSecondary,
                            fontSize = 12.5.sp,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
        }
    }
}

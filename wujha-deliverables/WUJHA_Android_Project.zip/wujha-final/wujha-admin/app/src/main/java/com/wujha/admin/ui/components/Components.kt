package com.wujha.admin.ui.components

import com.wujha.admin.ui.theme.TextOnPrimary
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.model.BookStatus
import com.wujha.admin.data.model.UserStatus
import com.wujha.admin.data.storage.ImageCodec
import com.wujha.admin.data.t
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.StatusActiveDot
import com.wujha.admin.ui.theme.StatusAvailableBg
import com.wujha.admin.ui.theme.StatusAvailableText
import com.wujha.admin.ui.theme.StatusBorrowedBg
import com.wujha.admin.ui.theme.StatusBorrowedText
import com.wujha.admin.ui.theme.StatusLostBg
import com.wujha.admin.ui.theme.StatusLostText
import com.wujha.admin.ui.theme.StatusSuspendedDot
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

/**
 * A book cover.
 *
 * Shows the stored photo when [coverBase64] is set, and falls back to a
 * tinted card bearing the title's first letter when it is not — so a book
 * added without a photo still looks deliberate rather than broken.
 */
@Composable
fun BookCover(
    title: String,
    colorHex: Long,
    modifier: Modifier = Modifier,
    coverBase64: String = ""
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(colorHex)),
        contentAlignment = Alignment.Center
    ) {
        val bitmap = remember(coverBase64) { ImageCodec.decode(coverBase64) }
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
        } else {
            Text(text = title.take(1), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BookStatusBadge(status: BookStatus, modifier: Modifier = Modifier) {
    val (bg, fg) = when (status) {
        BookStatus.AVAILABLE -> StatusAvailableBg to StatusAvailableText
        BookStatus.BORROWED -> StatusBorrowedBg to StatusBorrowedText
        BookStatus.LOST -> StatusLostBg to StatusLostText
    }
    Surface(modifier = modifier, shape = RoundedCornerShape(20.dp), color = bg) {
        Text(
            text = t(status.labelAr),
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun UserStatusDot(status: UserStatus, modifier: Modifier = Modifier) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = modifier) {
        Text(
            text = t(status.labelAr),
            fontSize = 12.sp,
            color = if (status == UserStatus.ACTIVE) StatusActiveDot else StatusSuspendedDot
        )
        androidx.compose.foundation.layout.Spacer(Modifier.width(6.dp))
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (status == UserStatus.ACTIVE) StatusActiveDot else StatusSuspendedDot)
        )
    }
}

@Composable
fun SectionHeader(title: String, icon: ImageVector? = null, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text = title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        if (icon != null) {
            androidx.compose.foundation.layout.Spacer(Modifier.width(6.dp))
            Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth().height(48.dp),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                if (value.isEmpty()) {
                    Text(text = placeholder, color = TextSecondary, fontSize = 14.sp)
                }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = TextPrimary, fontSize = 14.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(ForestGreen)
                )
            }
            Icon(Icons.Outlined.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = if (selected) ForestGreen else SurfaceWhite,
        border = if (selected) null else BorderStroke(1.dp, BorderLight),
        onClick = onClick
    ) {
        Text(
            text = label,
            color = if (selected) TextOnPrimary else TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

data class AdminNavTab(val route: String, val label: String, val icon: ImageVector)

val adminNavTabs = listOf(
    AdminNavTab("settings", t("الإعدادات"), Icons.Outlined.Settings),
    AdminNavTab("users", t("المستخدمين"), Icons.Outlined.People),
    AdminNavTab("loans", t("الإعارة"), Icons.Outlined.SwapHoriz),
    AdminNavTab("books", t("الكتب"), Icons.Outlined.MenuBook),
    AdminNavTab("home", t("الرئيسية"), Icons.Outlined.Home)
)

@Composable
fun AdminBottomBar(currentRoute: String?, onTabSelected: (String) -> Unit) {
    Surface(color = SurfaceWhite, tonalElevation = 4.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
        ) {
            adminNavTabs.forEach { tab ->
                val selected = currentRoute == tab.route
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .then(if (selected) Modifier.background(ForestGreen.copy(alpha = 0.08f)) else Modifier)
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    IconButton(onClick = { onTabSelected(tab.route) }) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.label,
                            tint = if (selected) ForestGreen else TextSecondary
                        )
                    }
                    Text(
                        text = tab.label,
                        fontSize = 11.sp,
                        color = if (selected) ForestGreen else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(
    label: String,
    value: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(tint.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
                }
            }
            androidx.compose.foundation.layout.Spacer(Modifier.height(10.dp))
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = label, fontSize = 11.sp, color = TextSecondary)
        }
    }
}

package com.wujha.admin.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.t
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.StatusLostText
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

/** One selectable option: a stable [value] stored, a human [label] shown. */
data class PickerOption(val value: String, val label: String)

/**
 * A dropdown that replaces free-text entry for fields with a known set of
 * valid values — floors, sections, categories, shelves, statuses.
 *
 * Typing these by hand is how a library ends up with "الطابق الأول" and
 * "الدور الأول" meaning the same shelf but never matching.
 */
@Composable
fun DropdownField(
    label: String,
    options: List<PickerOption>,
    selectedValue: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = t("اختر..."),
    errorText: String? = null,
    emptyHint: String? = null
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = options.firstOrNull { it.value == selectedValue }
    val hasError = errorText != null

    Column(modifier = modifier.fillMaxWidth()) {
        Text(text = label, color = TextSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(5.dp))

        Box {
            Surface(
                onClick = { if (options.isNotEmpty()) expanded = true },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, if (hasError) StatusLostText else BorderLight)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selected?.label
                            ?: if (options.isEmpty()) (emptyHint ?: placeholder) else placeholder,
                        color = if (selected != null) TextPrimary else TextSecondary,
                        fontSize = 14.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = Icons.Outlined.ExpandMore,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.heightIn(max = 280.dp)
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (option.value == selectedValue) {
                                    Icon(
                                        imageVector = Icons.Outlined.Check,
                                        contentDescription = null,
                                        tint = ForestGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                }
                                Text(
                                    text = option.label,
                                    fontSize = 14.sp,
                                    color = if (option.value == selectedValue) ForestGreen else TextPrimary
                                )
                            }
                        },
                        onClick = {
                            onSelect(option.value)
                            expanded = false
                        }
                    )
                }
            }
        }

        if (errorText != null) {
            Text(
                text = errorText,
                color = StatusLostText,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
            )
        }
    }
}

/** Multi-select chips, used for a book's tags. */
@Composable
fun TagChipRow(
    label: String,
    allTags: List<String>,
    selected: List<String>,
    onToggle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(text = label, color = TextSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        // Chunked rows rather than FlowRow, which is still an experimental
        // API in this Compose version and would need an opt-in.
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            allTags.chunked(3).forEach { rowTags ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    rowTags.forEach { tag ->
                        val isOn = selected.contains(tag)
                        Surface(
                            onClick = { onToggle(tag) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(20.dp),
                            color = if (isOn) ForestGreen else SurfaceWhite,
                            border = if (isOn) null else BorderStroke(1.dp, BorderLight)
                        ) {
                            Text(
                                text = tag,
                                color = if (isOn) SurfaceWhite else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp)
                            )
                        }
                    }
                    // Keep the last row's chips the same width as the others.
                    repeat(3 - rowTags.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

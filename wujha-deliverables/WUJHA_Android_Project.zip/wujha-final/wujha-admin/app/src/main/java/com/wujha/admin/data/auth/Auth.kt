package com.wujha.admin.data.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.UserProfileChangeRequest
import com.wujha.admin.data.t
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

/**
 * How the signed-in person authenticated.
 *
 * The admin app offers exactly one route. Google sign-in and guest access
 * belong to the visitor app: a control panel has no use for an account
 * nobody can be held responsible for, and every edit here is written into
 * the activity log against a named person.
 */
enum class SignInMethod { EMAIL }

/** The signed-in person. */
data class AuthUser(
    val uid: String,
    val displayName: String,
    val email: String,
    val method: SignInMethod
) {
    val initial: String get() = displayName.trim().take(1).ifBlank { t("م") }
}

/** Outcome of an auth attempt. [Failure.message] is Arabic, ready to show. */
sealed interface AuthResult {
    data class Success(val user: AuthUser) : AuthResult
    data class Failure(val message: String) : AuthResult
}

object AuthValidator {
    fun emailError(email: String): String? = when {
        email.isBlank() -> t("الرجاء إدخال البريد الإلكتروني")
        !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() ->
            t("صيغة البريد الإلكتروني غير صحيحة")
        else -> null
    }

    fun passwordError(password: String): String? = when {
        password.isBlank() -> t("الرجاء إدخال كلمة المرور")
        password.length < 6 -> t("كلمة المرور يجب أن تكون 6 أحرف على الأقل")
        else -> null
    }

    fun nameError(name: String): String? = when {
        name.isBlank() -> t("الرجاء إدخال الاسم")
        name.trim().length < 2 -> t("الاسم قصير جداً")
        else -> null
    }

    fun confirmError(password: String, confirm: String): String? =
        if (password != confirm) t("كلمتا المرور غير متطابقتين") else null
}

/**
 * Authentication, backed entirely by Firebase Auth.
 *
 * There is no offline fallback: if Firebase cannot be reached the user sees
 * a real error rather than silently signing in to fake local data.
 */
class AuthRepository {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val state = MutableStateFlow<AuthUser?>(null)
    val currentUser: StateFlow<AuthUser?> = state.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            state.value = firebaseAuth.currentUser?.let { fbUser ->
                AuthUser(
                    uid = fbUser.uid,
                    displayName = fbUser.displayName?.takeIf { it.isNotBlank() }
                        ?: fbUser.email?.substringBefore("@")
                        ?: t("مشرف"),
                    email = fbUser.email.orEmpty(),
                    method = SignInMethod.EMAIL
                )
            }
        }
    }

    private fun mapped(): AuthResult {
        val user = state.value
        return if (user != null) AuthResult.Success(user)
        else AuthResult.Failure(t("تعذّر إتمام العملية، حاول مرة أخرى"))
    }

    private fun arabicMessage(e: Throwable): String = when (e) {
        is FirebaseAuthWeakPasswordException -> t("كلمة المرور ضعيفة، استخدم 6 أحرف على الأقل")
        is FirebaseAuthInvalidCredentialsException -> t("البريد الإلكتروني أو كلمة المرور غير صحيحة")
        is FirebaseAuthInvalidUserException -> t("لا يوجد حساب مسجّل بهذا البريد الإلكتروني")
        is FirebaseAuthUserCollisionException -> t("هذا البريد الإلكتروني مسجّل مسبقاً")
        else -> {
            val raw = e.message.orEmpty()
            if (raw.contains("network", true) || raw.contains("UNAVAILABLE", true)) {
                t("تعذّر الاتصال بالخادم، تحقق من الإنترنت")
            } else {
                raw.ifBlank { t("تعذّر إتمام العملية، حاول مرة أخرى") }
            }
        }
    }

    suspend fun signInWithEmail(email: String, password: String): AuthResult = try {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
        mapped()
    } catch (e: Exception) {
        AuthResult.Failure(arabicMessage(e))
    }

    suspend fun signUpWithEmail(name: String, email: String, password: String): AuthResult = try {
        auth.createUserWithEmailAndPassword(email.trim(), password).await()
        auth.currentUser?.updateProfile(
            UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()
        )?.await()
        auth.currentUser?.let { fbUser ->
            state.value = AuthUser(
                uid = fbUser.uid,
                displayName = name.trim(),
                email = fbUser.email.orEmpty(),
                method = SignInMethod.EMAIL
            )
        }
        mapped()
    } catch (e: Exception) {
        AuthResult.Failure(arabicMessage(e))
    }

    suspend fun sendPasswordReset(email: String): AuthResult = try {
        auth.sendPasswordResetEmail(email.trim()).await()
        AuthResult.Failure(t("تم إرسال رابط إعادة التعيين إلى %s").format(email))
    } catch (e: Exception) {
        AuthResult.Failure(arabicMessage(e))
    }

    fun signOut() {
        auth.signOut()
        state.value = null
    }
}

object AuthProviderHolder {

    @Volatile
    private var instance: AuthRepository? = null

    /** Call once from MainActivity.onCreate, after Firebase auto-initialises. */
    fun init() {
        if (instance == null) instance = AuthRepository()
    }

    val repository: AuthRepository
        get() = instance ?: AuthRepository().also { instance = it }
}

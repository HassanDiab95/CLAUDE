package com.wujha.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.admin.data.model.CategoryCount
import com.wujha.admin.data.repository.LibraryRepository
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.EmptyView
import com.wujha.admin.ui.components.ScreenScaffold
import com.wujha.admin.ui.components.SectionHeader
import com.wujha.admin.ui.components.StatBarList
import com.wujha.admin.ui.components.StatTile
import com.wujha.admin.ui.theme.AccentGold
import com.wujha.admin.ui.theme.BorderLight
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextSecondary

/**
 * التقارير والإحصائيات.
 *
 * These are inventory reports, computed from the live catalog. There is no
 * loan history in the database, so nothing here claims borrowing trends it
 * cannot actually measure.
 */
@Composable
fun ReportsScreen(repository: LibraryRepository, onBack: () -> Unit) {
    val books by repository.books.collectAsState()
    val loans by repository.loans.collectAsState()
    val stats = repository.reportStats()
    val loanStats = repository.loanStats()

    ScreenScaffold(title = t("التقارير والإحصائيات"), onBack = onBack) {
        if (books.isEmpty()) {
            EmptyView(
                icon = Icons.Outlined.Assignment,
                title = t("لا توجد بيانات للتقارير"),
                detail = t("أضف كتباً إلى الفهرس وستُحسب الإحصائيات تلقائياً.")
            )
            return@ScreenScaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Transparent),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        label = t("عناوين"),
                        value = stats.totalBooks.toString(),
                        accent = ForestGreen,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        label = t("رفوف"),
                        value = stats.totalShelves.toString(),
                        accent = AccentGold,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        label = t("أعضاء نشطون"),
                        value = "${stats.activeMembers}/${stats.totalMembers}",
                        accent = ForestGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(24.dp))
            }

            item {
                SectionHeader(title = t("حالة الكتب"))
                Spacer(Modifier.height(12.dp))
                ReportCard { StatBarList(values = stats.statusBreakdown, barColor = ForestGreen) }
                Spacer(Modifier.height(24.dp))
            }

            item {
                SectionHeader(title = t("أكبر التصنيفات"))
                Spacer(Modifier.height(12.dp))
                ReportCard { StatBarList(values = stats.topCategories, barColor = AccentGold) }
                Spacer(Modifier.height(24.dp))
            }

            // ---- Borrowing ---------------------------------------------
            // The one part of the report that is about the library's work
            // rather than its contents.
            item {
                SectionHeader(title = t("حركة الإعارة"))
                Spacer(Modifier.height(12.dp))
                ReportCard {
                    StatBarList(
                        values = listOf(
                            CategoryCount(t("مُعارة حالياً"), loanStats.activeLoans),
                            CategoryCount(t("متأخرة"), loanStats.overdueLoans),
                            CategoryCount(t("محجوزة للاستلام"), loanStats.awaitingPickup),
                            CategoryCount(t("طلبات قيد المراجعة"), loanStats.pendingRequests),
                            CategoryCount(t("أُعيدت خلال ٣٠ يوماً"), loanStats.returnedRecently),
                            CategoryCount(t("مفقودة"), loanStats.lostLoans)
                        ),
                        barColor = ForestGreen,
                        emptyLabel = t("لم تُسجّل أي إعارة بعد")
                    )
                }
                Spacer(Modifier.height(24.dp))
            }

            item {
                SectionHeader(title = t("أكثر الكتب إعارة"))
                Spacer(Modifier.height(12.dp))
                ReportCard {
                    StatBarList(
                        values = loanStats.topBorrowed,
                        barColor = AccentGold,
                        emptyLabel = t("لا توجد إعارات لحسابها بعد")
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = t("إجمالي العمليات المسجّلة في سجل الإعارة: %s").format(loans.size),
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(24.dp))
            }

            item {
                SectionHeader(title = t("توزيع الكتب على الرفوف"))
                Spacer(Modifier.height(12.dp))
                ReportCard {
                    StatBarList(
                        values = stats.byShelf,
                        barColor = ForestGreen,
                        emptyLabel = t("لم تُسند الكتب إلى رفوف بعد")
                    )
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    text = t("تُحتسب جميع الأرقام مباشرة من الفهرس الحالي في قاعدة البيانات."),
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ReportCard(content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) { content() }
    }
}

package com.wujha.admin.navigation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.wujha.admin.data.auth.AuthProviderHolder
import com.wujha.admin.data.repository.LibraryRepositoryProvider
import com.wujha.admin.data.repository.SetupState
import com.wujha.admin.data.t
import com.wujha.admin.ui.components.AdminBottomBar
import com.wujha.admin.ui.components.LoanAlertWatcher
import com.wujha.admin.ui.screens.ActivityLogScreen
import com.wujha.admin.ui.screens.BackupScreen
import com.wujha.admin.ui.screens.BookDetailScreen
import com.wujha.admin.ui.screens.BookFormScreen
import com.wujha.admin.ui.screens.DashboardScreen
import com.wujha.admin.ui.screens.FloorEditorScreen
import com.wujha.admin.ui.screens.HelpScreen
import com.wujha.admin.ui.screens.LanguageScreen
import com.wujha.admin.ui.screens.LibraryMapScreen
import com.wujha.admin.ui.screens.LoanDetailScreen
import com.wujha.admin.ui.screens.LoanSettingsScreen
import com.wujha.admin.ui.screens.LoansScreen
import com.wujha.admin.ui.screens.LoginScreen
import com.wujha.admin.ui.screens.ManageAdminsScreen
import com.wujha.admin.ui.screens.ManageBooksScreen
import com.wujha.admin.ui.screens.ManageCategoriesScreen
import com.wujha.admin.ui.screens.ManageFloorsScreen
import com.wujha.admin.ui.screens.ManageShelvesScreen
import com.wujha.admin.ui.screens.ManageUsersScreen
import com.wujha.admin.ui.screens.NewLoanScreen
import com.wujha.admin.ui.screens.NotificationSettingsScreen
import com.wujha.admin.ui.screens.ReportsScreen
import com.wujha.admin.ui.screens.SettingsScreen
import com.wujha.admin.ui.screens.SplashScreen
import com.wujha.admin.ui.screens.SignUpScreen
import com.wujha.admin.ui.theme.ForestGreen
import com.wujha.admin.ui.theme.StatusLostText
import com.wujha.admin.ui.theme.SurfaceWhite
import com.wujha.admin.ui.theme.TextPrimary
import com.wujha.admin.ui.theme.TextSecondary

private const val NEW_BOOK = "new"
private val TAB_ROUTES = setOf("home", "books", "loans", "users", "settings")

@Composable
fun WujhaAdminNavGraph(navController: NavHostController = rememberNavController()) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route?.substringBefore("/")
    val showTabBar = currentRoute in TAB_ROUTES
    val repository = LibraryRepositoryProvider.repository
    val setupState by repository.setup.collectAsState()

    // Where the app goes once the opening screen has had its moment. Reading
    // the signed-in state here, before the splash is shown, means the delay
    // is also the window in which Firebase restores the session.
    val afterSplash = remember {
        if (AuthProviderHolder.repository.currentUser.value != null) "home" else "login"
    }

    fun enterApp() {
        navController.navigate("home") {
            popUpTo(0) { inclusive = true }
            launchSingleTop = true
        }
    }

    fun leaveApp() {
        navController.navigate("login") {
            popUpTo(0) { inclusive = true }
            launchSingleTop = true
        }
    }

    // Switching tabs must not stack them up. The anchor is «home», not the
    // graph's start destination: the start destination is the splash, and the
    // splash is popped the moment it finishes — so popping up to it was a
    // no-op, the stack grew with every tap, and saveState/restoreState never
    // had anything to work with.
    fun openTab(route: String) {
        navController.navigate(route) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    // Alive for the whole session: it turns a request arriving from a
    // visitor's phone into a notification while the app is open.
    LoanAlertWatcher()

    Scaffold(
        bottomBar = {
            if (showTabBar) {
                AdminBottomBar(currentRoute = currentRoute) { route ->
                    if (route != currentRoute) openTab(route)
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "splash",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("splash") {
                SplashScreen(
                    onFinished = {
                        navController.navigate(afterSplash) {
                            popUpTo("splash") { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable("login") {
                LoginScreen(
                    onSignedIn = { enterApp() },
                    onNavigateToSignUp = { navController.navigate("signup") }
                )
            }
            composable("signup") {
                SignUpScreen(
                    onSignedUp = { enterApp() },
                    onBackToLogin = { navController.popBackStack() }
                )
            }

            composable("home") {
                DashboardScreen(
                    repository = repository,
                    onOpenMap = { navController.navigate("map") },
                    onOpenReports = { navController.navigate("reports") },
                    onOpenBooks = { openTab("books") },
                    onOpenLoans = { openTab("loans") }
                )
            }
            composable("books") {
                ManageBooksScreen(
                    repository = repository,
                    onBookClick = { bookId -> navController.navigate("book_detail/$bookId") },
                    onAddBook = { navController.navigate("book_form/$NEW_BOOK") }
                )
            }
            composable("loans") {
                LoansScreen(
                    repository = repository,
                    onOpenLoan = { loanId -> navController.navigate("loan/$loanId") },
                    onNewLoan = { navController.navigate("new_loan") }
                )
            }
            composable("users") {
                ManageUsersScreen(
                    repository = repository,
                    onOpenLoan = { loanId -> navController.navigate("loan/$loanId") },
                    onLendTo = { memberId -> navController.navigate("new_loan?memberId=$memberId") }
                )
            }
            composable("settings") {
                SettingsScreen(
                    repository = repository,
                    onOpen = { key -> navController.navigate(key) },
                    onSignedOut = { leaveApp() }
                )
            }

            composable(
                route = "book_form/{bookId}",
                arguments = listOf(navArgument("bookId") { defaultValue = NEW_BOOK })
            ) { entry ->
                val raw = entry.arguments?.getString("bookId") ?: NEW_BOOK
                BookFormScreen(
                    bookId = raw.takeIf { it != NEW_BOOK },
                    repository = repository,
                    onDone = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                route = "book_detail/{bookId}",
                arguments = listOf(navArgument("bookId") { defaultValue = "" })
            ) { entry ->
                val bookId = entry.arguments?.getString("bookId").orEmpty()
                BookDetailScreen(
                    bookId = bookId,
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    onEdit = { id -> navController.navigate("book_form/$id") },
                    onDeleted = { navController.popBackStack() },
                    onLendBook = { id -> navController.navigate("new_loan?bookId=$id") },
                    onOpenLoan = { loanId -> navController.navigate("loan/$loanId") }
                )
            }

            composable(
                route = "loan/{loanId}",
                arguments = listOf(navArgument("loanId") { defaultValue = "" })
            ) { entry ->
                LoanDetailScreen(
                    loanId = entry.arguments?.getString("loanId").orEmpty(),
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
            // Optional query arguments rather than two routes: the screen is
            // reached empty from الإعارة, with a member from إدارة المستخدمين,
            // and with a book from صفحة الكتاب.
            composable(
                route = "new_loan?memberId={memberId}&bookId={bookId}",
                arguments = listOf(
                    navArgument("memberId") { defaultValue = "" },
                    navArgument("bookId") { defaultValue = "" }
                )
            ) { entry ->
                NewLoanScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    onDone = { navController.popBackStack() },
                    initialMemberId = entry.arguments?.getString("memberId").orEmpty(),
                    initialBookId = entry.arguments?.getString("bookId").orEmpty()
                )
            }

            composable("map") {
                LibraryMapScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable("reports") {
                ReportsScreen(repository = repository, onBack = { navController.popBackStack() })
            }

            // ---- Settings sub-screens -----------------------------------------
            composable("locations") {
                ManageFloorsScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    onOpenFloor = { floorId -> navController.navigate("floor/$floorId") }
                )
            }
            composable(
                route = "floor/{floorId}",
                arguments = listOf(navArgument("floorId") { defaultValue = "" })
            ) { entry ->
                FloorEditorScreen(
                    floorId = entry.arguments?.getString("floorId").orEmpty(),
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
            composable("loan_settings") {
                LoanSettingsScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable("admins") {
                ManageAdminsScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable("language") {
                LanguageScreen(onBack = { navController.popBackStack() })
            }
            composable("shelves") {
                ManageShelvesScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable("categories") {
                ManageCategoriesScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable("notifications") {
                NotificationSettingsScreen(onBack = { navController.popBackStack() })
            }
            composable("backup") {
                BackupScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable("activity") {
                ActivityLogScreen(repository = repository, onBack = { navController.popBackStack() })
            }
            composable("help") {
                HelpScreen(onBack = { navController.popBackStack() })
            }
        }
    }

    // First-login setup: shown only while the very first admin's sign-in is
    // filling the empty database, and again if that was interrupted.
    when (val state = setupState) {
        is SetupState.Running -> AlertDialog(
            onDismissRequest = {},
            containerColor = SurfaceWhite,
            title = { Text(t("جارٍ تجهيز المكتبة"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Column {
                    Text(
                        t("هذه أول مرة تُفتح فيها المكتبة. نُضيف الأدوار والرفوف والتصنيفات والكتب التجريبية إلى قاعدة البيانات. لا تُغلق التطبيق."),
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(14.dp))
                    LinearProgressIndicator(
                        progress = { if (state.total == 0) 0f else state.done.toFloat() / state.total },
                        color = ForestGreen,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(t("%s من %s").format(state.done, state.total), color = TextSecondary)
                }
            },
            confirmButton = {}
        )

        is SetupState.Failed -> AlertDialog(
            onDismissRequest = {},
            containerColor = SurfaceWhite,
            title = { Text(t("توقّف تجهيز المكتبة"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = { Text(state.message, color = StatusLostText) },
            confirmButton = {
                TextButton(onClick = { repository.retrySetup() }) {
                    Text(t("إعادة المحاولة"), color = ForestGreen, fontWeight = FontWeight.SemiBold)
                }
            }
        )

        SetupState.Idle -> Unit
    }

}

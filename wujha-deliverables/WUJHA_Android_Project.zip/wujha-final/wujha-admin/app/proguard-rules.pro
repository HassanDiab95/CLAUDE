# Add project specific ProGuard rules here.
# minifyEnabled is false by default for this project, so these rules are
# not applied unless you switch the release build type to isMinifyEnabled = true.

package com.wujha.user.ui.theme

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** The appearance the user picked. [SYSTEM] follows the phone's own setting. */
enum class ThemeMode(val code: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    fun label(english: Boolean): String = when (this) {
        SYSTEM -> if (english) "Same as device" else "حسب إعداد الجهاز"
        LIGHT -> if (english) "Light" else "فاتح"
        DARK -> if (english) "Dark" else "داكن"
    }

    companion object {
        fun from(code: String?): ThemeMode = entries.firstOrNull { it.code == code } ?: SYSTEM
    }
}

/**
 * Light or dark, for the whole app.
 *
 * Both values are Compose state. Every colour in Color.kt reads [isDark], so
 * choosing an appearance — or the phone switching to night mode while the
 * user is on [ThemeMode.SYSTEM] — recolours every screen at once.
 */
object WujhaThemeState {

    private var mode by mutableStateOf(ThemeMode.SYSTEM)

    /** The phone's own night-mode setting, refreshed in [init]. */
    private var systemDark by mutableStateOf(false)

    private var prefs: SharedPreferences? = null

    /** The appearance the user picked. */
    val current: ThemeMode get() = mode

    /** True when the dark palette is in use. */
    val isDark: Boolean
        get() = when (mode) {
            ThemeMode.SYSTEM -> systemDark
            ThemeMode.LIGHT -> false
            ThemeMode.DARK -> true
        }

    /**
     * Restores the saved choice and reads the phone's night mode. Called from
     * MainActivity.onCreate, which Android re-runs when night mode changes.
     */
    fun init(context: Context) {
        val store = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = store
        mode = ThemeMode.from(store.getString(KEY, ThemeMode.SYSTEM.code))
        systemDark = (context.resources.configuration.uiMode and
            Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun select(next: ThemeMode) {
        if (next == mode) return
        mode = next
        prefs?.edit()?.putString(KEY, next.code)?.apply()
    }

    /** Used by previews and the screenshot renderer. */
    fun force(dark: Boolean) {
        mode = if (dark) ThemeMode.DARK else ThemeMode.LIGHT
    }

    private const val PREFS = "wujha_theme"
    private const val KEY = "mode"
}

package com.wujha.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.LoanDates
import com.wujha.user.data.repository.AccountProvider
import com.wujha.user.data.repository.BookRepository
import com.wujha.user.data.repository.LoansProvider
import com.wujha.user.data.t
import com.wujha.user.ui.components.BookCover
import com.wujha.user.ui.components.IdPhotoField
import com.wujha.user.ui.components.LoadingView
import com.wujha.user.ui.components.PrimaryButton
import com.wujha.user.ui.components.ScreenScaffold
import com.wujha.user.ui.components.WujhaTextField
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackgroundAlt
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenMid
import com.wujha.user.ui.theme.SignalRed
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Asking the library to borrow a book.
 *
 * What this screen is careful about is honesty. It says what the library's
 * rules are before anything is filled in, it says plainly that a human will
 * look at the ID photo and what that photo is used for, and it does not
 * pretend the book is reserved the moment the button is pressed — the
 * request goes into a queue, and the screen says so.
 */
@Composable
fun BorrowRequestScreen(
    bookId: String,
    repository: BookRepository,
    onBack: () -> Unit,
    onSent: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val loansRepository = LoansProvider.repository
    val books by repository.books.collectAsState()
    val policy by loansRepository.policy.collectAsState()
    val myLoans by loansRepository.myLoans.collectAsState()
    val profile by AccountProvider.repository.profile.collectAsState()

    val book = books.firstOrNull { it.id == bookId }

    // What this account has borrowed under before. Once there is one, it is
    // not a suggestion: an account is tied to a single membership card, and
    // the field is filled in and locked rather than left open to a second
    // number that would create a second member for the same person.
    val lockedId = remember(myLoans) { loansRepository.establishedIdNumber() }
    val knownName = remember(myLoans) { loansRepository.establishedName() }

    var name by remember(profile, knownName) {
        mutableStateOf(knownName ?: profile?.name.orEmpty())
    }
    var idNumber by remember(lockedId) { mutableStateOf(lockedId.orEmpty()) }
    var phone by remember { mutableStateOf("") }
    var idPhoto by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var sent by remember { mutableStateOf(false) }

    if (book == null) {
        LoadingView(message = t("جارٍ تحميل الكتاب..."), modifier = Modifier.padding(0.dp))
        return
    }

    // `myLoans` is read above so this follows the live list: a request sent
    // from another device closes this screen's door too.
    val blocked = remember(book, myLoans, policy) { loansRepository.blockedReason(book) }

    ScreenScaffold(title = t("طلب إعارة"), onBack = onBack) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        BookCover(
                            title = book.title,
                            colorHex = book.coverColor,
                            coverBase64 = book.coverBase64,
                            modifier = Modifier.width(56.dp).aspectRatio(0.72f)
                        )
                        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(
                                text = book.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextPrimary
                            )
                            Text(text = book.author, fontSize = 12.sp, color = TextSecondary)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = if (book.isBorrowable) {
                                    t("%s نسخة متاحة من %s").format(book.availableCopies, book.copies)
                                } else {
                                    t("كل النسخ مُعارة حالياً")
                                },
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (book.isBorrowable) ForestGreenMid else SignalRed
                            )
                        }
                    }
                }
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = CreamBackgroundAlt
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Outlined.Info,
                                contentDescription = null,
                                tint = ForestGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = t("شروط الإعارة"),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = TextPrimary
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        RuleLine(t("مدة الإعارة"), t("%s يوماً").format(policy.loanDays))
                        RuleLine(
                            t("لو وافقت المكتبة"),
                            t("تُحجز النسخة باسمك %s أيام للاستلام").format(policy.pickupWindowDays)
                        )
                        RuleLine(
                            t("الحد الأعلى"),
                            t("%s كتب في وقت واحد").format(policy.maxActivePerMember)
                        )
                        RuleLine(
                            t("التجديد"),
                            if (policy.maxRenewals > 0) {
                                t("%s مرة بـ %s يوماً").format(policy.maxRenewals, policy.renewDays)
                            } else {
                                t("غير متاح")
                            }
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = t("الطلب لا يعني الحجز: تراجعه أمينة المكتبة أولاً، وتظهر النتيجة في «إعاراتي»."),
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            if (blocked != null) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = AccentGold.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = blocked,
                            color = TextPrimary,
                            fontSize = 12.5.sp,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
                return@LazyColumn
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = t("بياناتك"),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = t("اكتبها كما هي في الهوية حتى تطابق الصورة المرفقة."),
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        WujhaTextField(
                            value = name,
                            onValueChange = { name = it; error = null },
                            placeholder = t("الاسم الكامل")
                        )
                        Spacer(Modifier.height(10.dp))
                        WujhaTextField(
                            value = idNumber,
                            onValueChange = { input ->
                                idNumber = input.filter { it.isDigit() }.take(12)
                                error = null
                            },
                            placeholder = t("رقم الهوية أو رقم بطاقة العضوية"),
                            keyboardType = KeyboardType.Number,
                            enabled = lockedId == null
                        )
                        if (lockedId != null) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = t("هذا الرقم مرتبط بحسابك من إعارة سابقة ولا يمكن تغييره من هنا. لتعديله راجع أمينة المكتبة."),
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        WujhaTextField(
                            value = phone,
                            onValueChange = { input -> phone = input.filter { it.isDigit() }.take(10) },
                            placeholder = t("رقم الجوال (للتنبيه عند التوفّر)"),
                            keyboardType = KeyboardType.Phone
                        )
                        Spacer(Modifier.height(16.dp))
                        IdPhotoField(
                            base64 = idPhoto,
                            onPicked = { idPhoto = it; error = null },
                            onCleared = { idPhoto = "" },
                            required = policy.requireIdPhoto
                        )
                    }
                }
            }

            val currentError = error
            if (currentError != null) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = SignalRed.copy(alpha = 0.08f)
                    ) {
                        Text(
                            text = currentError,
                            color = SignalRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }

            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                    PrimaryButton(
                        text = t("إرسال الطلب"),
                        onClick = {
                            busy = true
                            error = null
                            scope.launch {
                                val failure = loansRepository.requestLoan(
                                    book = book,
                                    name = name,
                                    idNumber = idNumber,
                                    phone = phone,
                                    idPhotoBase64 = idPhoto
                                )
                                busy = false
                                if (failure == null) sent = true else error = failure
                            }
                        },
                        loading = busy
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = t("بإرسال الطلب أوافق على مطابقة بياناتي بصورة الهوية، وعلى إرجاع الكتاب في موعده."),
                        color = TextSecondary,
                        fontSize = 10.5.sp
                    )
                }
            }
        }
    }

    if (sent) {
        AlertDialog(
            onDismissRequest = { sent = false; onSent() },
            containerColor = SurfaceWhite,
            icon = {
                Icon(
                    Icons.Outlined.CheckCircle,
                    contentDescription = null,
                    tint = ForestGreenMid,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = { Text(t("أُرسل الطلب"), fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Column {
                    Text(
                        text = t("ستراجع أمينة المكتبة طلبك وبياناتك، وتجد النتيجة في «إعاراتي»."),
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = t("لو وافقت المكتبة، تُحجز النسخة باسمك حتى %s.")
                            .format(LoanDates.format(LoanDates.dueDate(policy.pickupWindowDays))),
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { sent = false; onSent() }) {
                    Text(t("عرض إعاراتي"), color = ForestGreen, fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}

@Composable
private fun RuleLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 11.5.sp)
        Text(value, color = TextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
    }
}

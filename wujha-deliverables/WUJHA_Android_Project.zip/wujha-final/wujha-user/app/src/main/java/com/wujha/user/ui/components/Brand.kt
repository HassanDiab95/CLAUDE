package com.wujha.user.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import com.wujha.user.R
import com.wujha.user.data.t
import com.wujha.user.ui.theme.TextSecondary
import com.wujha.user.ui.theme.WujhaThemeState

/**
 * The WUJHA lockup: the open book with its map pin, the Arabic wordmark, and
 * the Latin one underneath.
 *
 * It ships as a transparent PNG rather than being redrawn in Compose, so
 * what appears on screen is the approved mark itself and not an
 * approximation of it.
 *
 * The dark appearance uses a second copy of the artwork in which the deep
 * green is lifted to the dark palette's mint, so the mark stays readable on
 * a dark background. The gold pin and the olive pages are unchanged.
 */
@Composable
fun WujhaLockup(
    modifier: Modifier = Modifier,
    height: Dp = 132.dp,
    tagline: String? = null,
    taglineColor: Color = TextSecondary
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            painter = painterResource(
                id = if (WujhaThemeState.isDark) R.drawable.wujha_lockup_dark else R.drawable.wujha_lockup
            ),
            contentDescription = t("وِجهة"),
            contentScale = ContentScale.Fit,
            modifier = Modifier.heightIn(max = height)
        )
        if (tagline != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                text = tagline,
                color = taglineColor,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }
    }
}

/** The mark on its own, for app bars and compact headers. */
@Composable
fun WujhaMark(modifier: Modifier = Modifier, size: Dp = 32.dp) {
    Image(
        painter = painterResource(
            id = if (WujhaThemeState.isDark) R.drawable.wujha_mark_dark else R.drawable.wujha_mark
        ),
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = modifier.height(size)
    )
}

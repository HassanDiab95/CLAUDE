package com.wujha.user.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.wujha.user.data.DestinationStore
import com.wujha.user.data.auth.AuthProviderHolder
import com.wujha.user.data.repository.BookRepositoryProvider
import com.wujha.user.ui.components.LoanNotificationWatcher
import com.wujha.user.ui.components.WujhaBottomBar
import com.wujha.user.ui.screens.AboutScreen
import com.wujha.user.ui.screens.AccountScreen
import com.wujha.user.ui.screens.BookDetailScreen
import com.wujha.user.ui.screens.BorrowRequestScreen
import com.wujha.user.ui.screens.FavoritesScreen
import com.wujha.user.ui.screens.HomeScreen
import com.wujha.user.ui.screens.LanguageScreen
import com.wujha.user.ui.screens.LoginScreen
import com.wujha.user.ui.screens.MyLoansScreen
import com.wujha.user.ui.screens.NavigationMapScreen
import com.wujha.user.ui.screens.NotificationsScreen
import com.wujha.user.ui.screens.SearchScreen
import com.wujha.user.ui.screens.SplashScreen
import com.wujha.user.ui.screens.SignUpScreen
import com.wujha.user.ui.screens.UserHelpScreen
import com.wujha.user.ui.screens.UserNotificationSettingsScreen

private const val ALL_CATEGORIES = "__all__"
private val TAB_ROUTES = setOf("home", "search", "favorites", "account", "navigation")
private val AUTH_ROUTES = setOf("login", "signup")

@Composable
fun WujhaNavGraph(navController: NavHostController = rememberNavController()) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route?.substringBefore("/")
    val showTabBar = currentRoute in TAB_ROUTES && currentRoute !in AUTH_ROUTES
    val repository = BookRepositoryProvider.repository

    // Where the app goes once the opening screen has had its moment. Reading
    // the signed-in state here, before the splash is shown, means the delay
    // is also the window in which Firebase restores the session.
    val afterSplash = remember {
        if (AuthProviderHolder.repository.currentUser.value != null) "home" else "login"
    }

    fun enterApp() {
        navController.navigate("home") {
            popUpTo(0) { inclusive = true }
            launchSingleTop = true
        }
    }

    fun leaveApp() {
        navController.navigate("login") {
            popUpTo(0) { inclusive = true }
            launchSingleTop = true
        }
    }

    // Switching tabs must not stack them up. The anchor is «home», not the
    // graph's start destination: the start destination is the splash, and the
    // splash is popped the moment it finishes — so popping up to it was a
    // no-op, the stack grew with every tap, and saveState/restoreState never
    // had anything to work with.
    fun openTab(route: String) {
        navController.navigate(route) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }


    // Alive for the whole session, on every tab: it turns a change on the
    // visitor's own loans into a notification while the app is open.
    LoanNotificationWatcher()

    Scaffold(
        bottomBar = {
            if (showTabBar) {
                WujhaBottomBar(currentRoute = currentRoute) { route ->
                    if (route == currentRoute) return@WujhaBottomBar
                    when (route) {
                        // Tapping الوجهة shows where the visitor is, not a
                        // route to whichever book happened to be first.
                        "navigation" -> openTab("navigation")
                        "search" -> openTab("search/$ALL_CATEGORIES")
                        else -> openTab(route)
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "splash",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("splash") {
                SplashScreen(
                    onFinished = {
                        navController.navigate(afterSplash) {
                            popUpTo("splash") { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable("login") {
                LoginScreen(
                    onSignedIn = { enterApp() },
                    onNavigateToSignUp = { navController.navigate("signup") }
                )
            }
            composable("signup") {
                SignUpScreen(
                    onSignedUp = { enterApp() },
                    onBackToLogin = { navController.popBackStack() }
                )
            }

            composable("home") {
                HomeScreen(
                    repository = repository,
                    onBookClick = { id -> navController.navigate("book_detail/$id") },
                    onCategoryClick = { categoryId -> openTab("search/$categoryId") },
                    onOpenSearch = { openTab("search/$ALL_CATEGORIES") },
                    onOpenAccount = { openTab("account") },
                    onOpenNotifications = { navController.navigate("notifications") }
                )
            }
            composable(
                route = "search/{categoryId}",
                arguments = listOf(navArgument("categoryId") { defaultValue = ALL_CATEGORIES })
            ) { entry ->
                val categoryId = entry.arguments?.getString("categoryId") ?: ALL_CATEGORIES
                SearchScreen(
                    repository = repository,
                    onBookClick = { id -> navController.navigate("book_detail/$id") },
                    initialCategoryId = categoryId.takeIf { it != ALL_CATEGORIES }
                )
            }
            composable("favorites") {
                FavoritesScreen(
                    repository = repository,
                    onBookClick = { id -> navController.navigate("book_detail/$id") }
                )
            }
            composable("account") {
                AccountScreen(
                    onSignedOut = { leaveApp() },
                    onOpenFavorites = { openTab("favorites") },
                    onOpen = { key -> navController.navigate(key) }
                )
            }

            composable(
                route = "book_detail/{bookId}",
                arguments = listOf(navArgument("bookId") { defaultValue = "" })
            ) { entry ->
                val bookId = entry.arguments?.getString("bookId").orEmpty()
                BookDetailScreen(
                    bookId = bookId,
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    onLocateBook = {
                        DestinationStore.set(bookId)
                        openTab("navigation")
                    },
                    onSimilarBookClick = { id -> navController.navigate("book_detail/$id") },
                    onBorrow = { id -> navController.navigate("borrow/$id") },
                    onOpenMyLoans = { navController.navigate("my_loans") }
                )
            }
            composable("navigation") {
                NavigationMapScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    onSearch = { openTab("search/$ALL_CATEGORIES") }
                )
            }

            composable(
                route = "borrow/{bookId}",
                arguments = listOf(navArgument("bookId") { defaultValue = "" })
            ) { entry ->
                BorrowRequestScreen(
                    bookId = entry.arguments?.getString("bookId").orEmpty(),
                    repository = repository,
                    onBack = { navController.popBackStack() },
                    // Sending a request leaves the form behind and lands on
                    // the list where the answer will appear.
                    onSent = {
                        navController.navigate("my_loans") {
                            popUpTo("borrow/{bookId}") { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable("my_loans") {
                MyLoansScreen(
                    onBack = { navController.popBackStack() },
                    onOpenBook = { id -> navController.navigate("book_detail/$id") }
                )
            }

            // ---- Account sub-screens -------------------------------------------
            composable("notifications") {
                NotificationsScreen(
                    onBack = { navController.popBackStack() },
                    onOpenLoans = { navController.navigate("my_loans") },
                    onOpenSettings = { navController.navigate("notification_settings") }
                )
            }
            composable("notification_settings") {
                UserNotificationSettingsScreen(onBack = { navController.popBackStack() })
            }
            composable("language") {
                LanguageScreen(onBack = { navController.popBackStack() })
            }
            composable("help") {
                UserHelpScreen(onBack = { navController.popBackStack() })
            }
            composable("about") {
                AboutScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}

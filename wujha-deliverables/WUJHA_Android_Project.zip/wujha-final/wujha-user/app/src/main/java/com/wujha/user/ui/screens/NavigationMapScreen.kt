package com.wujha.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.DestinationStore
import com.wujha.user.data.LibraryPlan
import com.wujha.user.data.Localization
import com.wujha.user.data.repository.BookRepository
import com.wujha.user.data.t
import com.wujha.user.ui.components.EmptyView
import com.wujha.user.ui.components.FloorPlanLegend
import com.wujha.user.ui.components.FloorPlanView
import com.wujha.user.ui.components.LoadingView
import com.wujha.user.ui.components.PrimaryButton
import com.wujha.user.data.model.Floor
import com.wujha.user.data.model.Shelf
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackground
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenMid
import com.wujha.user.ui.theme.ForestGreenWash
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

/**
 * How to get to one book — or where you are standing when there is no book.
 *
 * The tab has two states, and the second one is the point. A visitor who
 * opens الوجهة without having chosen anything has not asked to go anywhere,
 * so the screen says where they are: at the desk by the entrance, with the
 * floor drawn around them and no route. Only once they pick a book from its
 * page does the dashed line appear, and tapping «إنهاء» puts them back at
 * the desk rather than leaving yesterday's walk on the screen.
 *
 * The map itself is the floor the book is actually on, drawn from the live
 * building: its blocks, the corridors between them, the aisles inside them
 * and every bookcase. The numbered steps below say the same thing in words,
 * which is what someone with a phone in one hand actually reads.
 */
@Composable
fun NavigationMapScreen(
    repository: BookRepository,
    onBack: () -> Unit,
    onSearch: () -> Unit
) {
    val allBooks by repository.books.collectAsState()
    val allShelves by repository.shelves.collectAsState()
    val allFloors by repository.floors.collectAsState()
    val destinationId by DestinationStore.bookId.collectAsState()
    val book = allBooks.find { it.id == destinationId }

    // Chosen, but the catalog has not arrived yet — not the same thing as
    // having chosen nothing, so it waits rather than claiming to be at the
    // desk.
    if (destinationId.isNotBlank() && book == null && allBooks.isEmpty()) {
        LoadingView(
            message = t("جارٍ تحميل الوجهة..."),
            modifier = Modifier.background(CreamBackground)
        )
        return
    }

    if (book == null) {
        AtTheDeskScreen(
            shelves = allShelves,
            floors = allFloors,
            books = allBooks,
            onBack = onBack,
            onSearch = onSearch
        )
        return
    }

    val location = remember(book, allShelves, allFloors) { repository.locate(book) }
    val floorIndex = remember(location, allFloors) {
        LibraryPlan.ordered(allFloors).indexOfFirst { it.id == location.floor?.id }.coerceAtLeast(0)
    }
    // The app cannot see where the visitor is inside the building, so it asks:
    // which bookcase are you standing at? Blank means the entrance. The
    // choice belongs to this walk only, and resets when the book changes.
    var startCode by rememberSaveable(book.id) { mutableStateOf("") }
    var choosingStart by rememberSaveable(book.id) { mutableStateOf(false) }
    val startShelf = remember(startCode, allShelves) {
        allShelves.firstOrNull { startCode.isNotBlank() && it.code == startCode }
    }
    val fromFloorIndex = remember(startShelf, allFloors) {
        startShelf?.let { s ->
            LibraryPlan.ordered(allFloors)
                .indexOfFirst { it.id == s.floorId || (s.floorId.isBlank() && it.name == s.floor) }
                .coerceAtLeast(0)
        } ?: 0
    }
    val bookCounts = remember(allBooks) {
        allBooks.filter { it.shelf.isNotBlank() }.groupingBy { it.shelf }.eachCount()
    }
    // The language is a key, not just a read: the written directions are
    // built inside this block, so they have to be rebuilt when it changes.
    val english = Localization.isEnglish
    val map = remember(location, allShelves, allFloors, bookCounts, english, startShelf, fromFloorIndex) {
        LibraryPlan.floorMap(
            floor = location.floor,
            shelves = allShelves,
            bookCounts = bookCounts,
            target = location.shelf,
            fromFloorIndex = fromFloorIndex,
            floorIndex = floorIndex,
            english = english,
            startShelf = startShelf
        )
    }

    Column(modifier = Modifier.fillMaxSize().background(CreamBackground)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Outlined.ArrowForward, contentDescription = t("رجوع"), tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = t("الوصول إلى الكتاب"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimary,
                    maxLines = 1
                )
                Text(text = book.title, fontSize = 12.sp, color = TextSecondary, maxLines = 1)
            }
            Surface(
                // Arriving ends the walk: the tab goes back to showing the
                // desk instead of a route to a book already in hand.
                onClick = { DestinationStore.clear() },
                shape = RoundedCornerShape(10.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Text(
                    text = t("إنهاء"),
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }

        if (!location.isKnown || map.isEmpty) {
            EmptyView(
                icon = Icons.Outlined.Explore,
                title = t("موقع هذا الكتاب غير مسجّل"),
                detail = t("لم يُسند هذا الكتاب إلى رف بعد. اسأل أمين المكتبة، أو جرّب كتاباً آخر.")
            )
            return@Column
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                LocationCard(
                    floor = location.floorName(english),
                    block = location.block?.displayName(english).orEmpty(),
                    aisle = location.aisle?.displayName(english).orEmpty(),
                    shelfCode = location.shelfCode(),
                    level = t(location.level),
                    side = location.shelf?.side.orEmpty().let { if (it.isBlank()) "" else t(it) },
                    zone = location.shelf?.zone.orEmpty()
                )
                Spacer(Modifier.height(14.dp))
            }

            item {
                StartPointCard(
                    startShelf = startShelf,
                    floors = allFloors,
                    english = english,
                    onChange = { choosingStart = true }
                )
                Spacer(Modifier.height(14.dp))
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = t("خريطة %s").format(location.floorName(english)),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            if (map.hasRoute) {
                                Pill(Icons.Outlined.Straighten, t("%s م").format(map.distanceMeters))
                                Spacer(Modifier.width(6.dp))
                                Pill(Icons.Outlined.Schedule, t("%s د").format(map.etaMinutes))
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        FloorPlanView(
                            map = map,
                            modifier = Modifier.fillMaxWidth().aspectRatio(0.95f),
                            english = english
                        )
                        Spacer(Modifier.height(10.dp))
                        FloorPlanLegend(
                            shelfLabel = t("رف"),
                            targetLabel = t("وجهتك"),
                            corridorLabel = t("ممر")
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
            }

            if (map.steps.isNotEmpty()) {
                item {
                    Text(
                        text = t("الخطوات"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                itemsIndexedSteps(map.steps)
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (choosingStart) {
        StartPointDialog(
            shelves = allShelves.filter { it.code != location.shelf?.code }
                .sortedWith(LibraryPlan.shelfOrder(allFloors)),
            floors = allFloors,
            selected = startCode,
            english = english,
            onPick = { code ->
                startCode = code
                choosingStart = false
            },
            onDismiss = { choosingStart = false }
        )
    }
}

/** "floor · block" for a bookcase, read from the live building. */
private fun shelfPlace(shelf: Shelf, floors: List<Floor>, english: Boolean): String {
    val floor = floors.firstOrNull { it.id == shelf.floorId || (shelf.floorId.isBlank() && it.name == shelf.floor) }
    val block = floor?.block(shelf.block)
    return listOfNotNull(
        floor?.displayName(english) ?: shelf.floor.ifBlank { null },
        block?.displayName(english) ?: shelf.block.ifBlank { null }
    ).joinToString(" · ")
}

/**
 * Where the walk begins.
 *
 * There is no indoor positioning, so the route assumes the entrance unless
 * the visitor names the bookcase they are standing at. The card says which
 * one the map is using and offers to change it.
 */
@Composable
private fun StartPointCard(
    startShelf: Shelf?,
    floors: List<Floor>,
    english: Boolean,
    onChange: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(34.dp).clip(CircleShape).background(ForestGreenWash),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.MyLocation,
                        contentDescription = null,
                        tint = ForestGreenMid,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(text = t("نقطة البداية"), color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = if (startShelf == null) t("مدخل المكتبة") else t("الرف %s").format(startShelf.code),
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    if (startShelf != null) {
                        Text(
                            text = shelfPlace(startShelf, floors, english),
                            color = TextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }
                Surface(
                    onClick = onChange,
                    shape = RoundedCornerShape(10.dp),
                    color = ForestGreen
                ) {
                    Text(
                        text = t("تغيير"),
                        color = SurfaceWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
            if (startShelf == null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = t("يبدأ الطريق من المدخل لأن التطبيق لا يحدد موقعك داخل المبنى. إن كنت في مكان آخر فاختر أقرب رف إليك."),
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

/** Picks the bookcase the visitor is standing at — or the entrance. */
@Composable
private fun StartPointDialog(
    shelves: List<Shelf>,
    floors: List<Floor>,
    selected: String,
    english: Boolean,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val shown = remember(shelves, query) {
        val q = query.trim()
        if (q.isEmpty()) shelves else shelves.filter { it.code.contains(q, ignoreCase = true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = {
            Text(t("من أين تبدأ؟"), color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column {
                Text(
                    text = t("التطبيق لا يعرف مكانك داخل المبنى. اختر الرف الأقرب إليك — رمزه مكتوب على جانب الرف — وسيبدأ الطريق منه."),
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text(t("ابحث برمز الرف"), color = TextSecondary, fontSize = 13.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = ForestGreen,
                        unfocusedBorderColor = BorderLight,
                        cursorColor = ForestGreen
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp)) {
                    item(key = "entrance") {
                        StartOption(
                            title = t("مدخل المكتبة"),
                            detail = "",
                            selected = selected.isBlank(),
                            onClick = { onPick("") }
                        )
                    }
                    items(shown, key = { it.id.ifBlank { it.code } }) { shelf ->
                        StartOption(
                            title = t("الرف %s").format(shelf.code),
                            detail = shelfPlace(shelf, floors, english),
                            selected = shelf.code == selected,
                            onClick = { onPick(shelf.code) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(t("إغلاق"), color = ForestGreen) }
        }
    )
}

@Composable
private fun StartOption(title: String, detail: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) ForestGreenWash else SurfaceWhite,
        border = BorderStroke(1.dp, if (selected) ForestGreen else BorderLight)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
            Text(title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            if (detail.isNotBlank()) Text(detail, color = TextSecondary, fontSize = 11.sp)
        }
    }
}

/** The steps, numbered, each in its own card. */
private fun androidx.compose.foundation.lazy.LazyListScope.itemsIndexedSteps(steps: List<String>) {
    steps.forEachIndexed { index, step ->
        item(key = "step_$index") {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                shape = RoundedCornerShape(14.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(24.dp).clip(CircleShape).background(ForestGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${index + 1}",
                            color = SurfaceWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = step,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(start = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun Pill(icon: ImageVector, text: String) {
    Surface(shape = RoundedCornerShape(20.dp), color = ForestGreenWash) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = ForestGreenMid, modifier = Modifier.size(12.dp))
            Text(
                text = text,
                color = ForestGreenMid,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 4.dp)
            )
        }
    }
}

/**
 * The address, from the floor down to the level of the bookcase.
 *
 * Each line is one thing a visitor can check against a sign or a label as
 * they walk, which is why it is a list of labelled rows rather than one
 * sentence.
 */
@Composable
private fun LocationCard(
    floor: String,
    block: String,
    aisle: String,
    shelfCode: String,
    level: String,
    side: String,
    zone: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(34.dp).clip(CircleShape).background(AccentGold),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.LocationOn,
                        contentDescription = null,
                        tint = SurfaceWhite,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = t("مكان الكتاب"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    modifier = Modifier.padding(start = 10.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
            AddressRow(t("الدور"), floor)
            AddressRow(t("البلوك"), block)
            AddressRow(t("الممر"), aisle)
            AddressRow(t("رمز الرف"), shelfCode)
            AddressRow(t("المستوى"), level)
            AddressRow(t("الجهة"), side)
            AddressRow(t("القسم"), zone)
        }
    }
}

@Composable
private fun AddressRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 12.sp)
        Text(value, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * «أنت الآن عند مكتب الاستقبال» — the tab before a destination is chosen.
 *
 * It is a real screen, not an empty state: the plan of the entrance floor is
 * drawn with the green dot on the door, so a visitor standing in the doorway
 * can see the library laid out in front of them and work out where they are
 * before they have searched for anything.
 *
 * There is no indoor positioning in this project — no beacons, no Wi-Fi
 * trilateration — so the honest answer to "where am I" is the one place the
 * app can be sure of: the entrance everyone comes through. Every route is
 * measured from there for the same reason.
 */
@Composable
private fun AtTheDeskScreen(
    shelves: List<com.wujha.user.data.model.Shelf>,
    floors: List<com.wujha.user.data.model.Floor>,
    books: List<com.wujha.user.data.model.Book>,
    onBack: () -> Unit,
    onSearch: () -> Unit
) {
    val english = Localization.isEnglish
    val entranceFloor = remember(floors) { LibraryPlan.ordered(floors).firstOrNull() }
    val bookCounts = remember(books) {
        books.filter { it.shelf.isNotBlank() }.groupingBy { it.shelf }.eachCount()
    }
    // target = null: the plan with no route, which is exactly the picture of
    // standing somewhere without going anywhere yet.
    val map = remember(entranceFloor, shelves, bookCounts, english) {
        LibraryPlan.floorMap(
            floor = entranceFloor,
            shelves = shelves,
            bookCounts = bookCounts,
            target = null,
            english = english
        )
    }

    Column(modifier = Modifier.fillMaxSize().background(CreamBackground)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Outlined.ArrowForward, contentDescription = t("رجوع"), tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = t("الوجهة"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimary,
                    maxLines = 1
                )
                Text(
                    text = t("لم تختر وجهة بعد"),
                    fontSize = 12.sp,
                    color = TextSecondary,
                    maxLines = 1
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(ForestGreenWash),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Outlined.Storefront,
                                    contentDescription = null,
                                    tint = ForestGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(
                                    text = t("أنت الآن عند مكتب الاستقبال"),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = t("عند مدخل المكتبة — نقطة البداية لكل وجهة"),
                                    fontSize = 11.5.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = t("اختر كتاباً من البحث أو من صفحته واضغط «اعرض الطريق إلى الكتاب»، فيُرسم لك الطريق من هنا إلى رفّه خطوة بخطوة."),
                            fontSize = 12.5.sp,
                            color = TextSecondary,
                            lineHeight = 19.sp
                        )
                        Spacer(Modifier.height(14.dp))
                        PrimaryButton(text = t("ابحث عن كتاب"), onClick = onSearch)
                    }
                }
                Spacer(Modifier.height(14.dp))
            }

            if (map.isEmpty) {
                item {
                    EmptyView(
                        icon = Icons.Outlined.Explore,
                        title = t("لم تُعرَّف خريطة المكتبة بعد"),
                        detail = t("ستظهر الخريطة هنا بمجرد أن تضيف إدارة المكتبة الأدوار والرفوف.")
                    )
                }
                return@LazyColumn
            }

            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = t("خريطة %s").format(
                                    entranceFloor?.displayName(english).orEmpty()
                                ),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Pill(Icons.Outlined.LocationOn, t("أنت هنا"))
                        }
                        Spacer(Modifier.height(10.dp))
                        FloorPlanView(
                            map = map,
                            modifier = Modifier.fillMaxWidth().aspectRatio(0.95f),
                            english = english
                        )
                        Spacer(Modifier.height(10.dp))
                        FloorPlanLegend(
                            shelfLabel = t("رف"),
                            targetLabel = t("وجهتك"),
                            corridorLabel = t("ممر")
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = t("التطبيق لا يحدّد موقعك داخل المبنى، فيبدأ الطريق من المدخل ما لم تختر الرف الذي تقف عنده."),
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

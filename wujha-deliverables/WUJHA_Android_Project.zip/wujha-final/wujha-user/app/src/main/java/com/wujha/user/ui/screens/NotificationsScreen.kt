package com.wujha.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.ReportProblem
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.LoanDates
import com.wujha.user.data.notify.LoanEvent
import com.wujha.user.data.notify.LoanEventKind
import com.wujha.user.data.notify.LoanEvents
import com.wujha.user.data.notify.NotificationStoreProvider
import com.wujha.user.data.notify.Notifier
import com.wujha.user.data.repository.LoansProvider
import com.wujha.user.data.t
import com.wujha.user.ui.components.EmptyView
import com.wujha.user.ui.components.ScreenScaffold
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.AccentGoldDark
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenMid
import com.wujha.user.ui.theme.SignalRed
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

/**
 * «الإشعارات» — what happened to this visitor's borrowings.
 *
 * The list is worked out from the loans themselves rather than from
 * messages that were delivered, which is what makes it reliable: a request
 * approved while the app was closed is here the moment it opens, and it is
 * still here next week. The phone's tray is the extra, not the record.
 */
@Composable
fun NotificationsScreen(
    onBack: () -> Unit,
    onOpenLoans: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val repository = LoansProvider.repository
    val loans by repository.myLoans.collectAsState()
    val policy by repository.policy.collectAsState()
    val store = remember { NotificationStoreProvider.store }

    val events = remember(loans, policy) { LoanEvents.from(loans, policy) }

    // Opening the screen is what marks them read, so the badge on «حسابي»
    // means "things you have not looked at", not "things that happened".
    LaunchedEffect(events) { store.markRead(events.map { it.key }) }

    ScreenScaffold(title = t("الإشعارات"), onBack = onBack) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            if (!Notifier.hasPermission(context)) {
                item {
                    Banner(
                        text = t("إشعارات النظام موقوفة لهذا التطبيق من إعدادات الجهاز، لذا لن يصلك تنبيه خارج التطبيق. القائمة هنا تعمل على كل حال."),
                        tint = AccentGoldDark
                    )
                }
            }

            if (events.isEmpty()) {
                item {
                    EmptyView(
                        icon = Icons.Outlined.NotificationsNone,
                        title = t("لا توجد إشعارات"),
                        detail = t("ستظهر هنا نتيجة طلبات الإعارة ومواعيد الإرجاع وكل ما يخصّ إعاراتك.")
                    )
                }
            }

            items(events) { event ->
                EventRow(event = event, onClick = onOpenLoans)
            }

            item {
                Spacer(Modifier.height(12.dp))
                Surface(
                    onClick = onOpenSettings,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Outlined.NotificationsNone,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = t("إعدادات الإشعارات"),
                            color = TextPrimary,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            Icons.Outlined.ChevronLeft,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EventRow(event: LoanEvent, onClick: () -> Unit) {
    val (icon, tint) = look(event.kind)
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Box(
                modifier = Modifier.size(38.dp).clip(CircleShape).background(tint.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
            }
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                Text(
                    text = event.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = TextPrimary
                )
                Spacer(Modifier.height(3.dp))
                Text(text = event.body, fontSize = 12.sp, color = TextSecondary, lineHeight = 18.sp)
                Spacer(Modifier.height(5.dp))
                Text(
                    text = LoanDates.format(event.atMillis),
                    fontSize = 10.5.sp,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun Banner(text: String, tint: Color) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        shape = RoundedCornerShape(14.dp),
        color = tint.copy(alpha = 0.10f)
    ) {
        Text(text = text, color = tint, fontSize = 12.sp, modifier = Modifier.padding(14.dp))
    }
}

private fun look(kind: LoanEventKind): Pair<ImageVector, Color> = when (kind) {
    LoanEventKind.APPROVED -> Icons.Outlined.CheckCircle to ForestGreenMid
    LoanEventKind.ISSUED -> Icons.Outlined.MenuBook to ForestGreen
    LoanEventKind.RENEWED -> Icons.Outlined.Autorenew to AccentGoldDark
    LoanEventKind.DUE_SOON -> Icons.Outlined.Schedule to AccentGold
    LoanEventKind.OVERDUE -> Icons.Outlined.ReportProblem to SignalRed
    LoanEventKind.REJECTED -> Icons.Outlined.ReportProblem to SignalRed
    LoanEventKind.CANCELLED -> Icons.Outlined.Schedule to TextSecondary
    LoanEventKind.RETURNED -> Icons.Outlined.CheckCircle to TextSecondary
}

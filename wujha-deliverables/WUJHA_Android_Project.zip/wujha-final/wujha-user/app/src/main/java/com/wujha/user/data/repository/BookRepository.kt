package com.wujha.user.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.wujha.user.data.LibraryPlan
import com.wujha.user.data.model.Aisle
import com.wujha.user.data.model.Block
import com.wujha.user.data.model.Book
import com.wujha.user.data.model.BookLocation
import com.wujha.user.data.model.Category
import com.wujha.user.data.model.Floor
import com.wujha.user.data.model.Shelf
import com.wujha.user.data.t
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Where the catalog is in its loading lifecycle. */
sealed interface DataStatus {
    data object Loading : DataStatus
    data object Ready : DataStatus
    data class Error(val message: String) : DataStatus
}

/**
 * The visitor-facing catalog, backed by Cloud Firestore.
 *
 * Read-only: this app never writes to `books`, `categories`, `shelves` or
 * `floors`. Reads are live, so a book, a bookcase or a whole new floor added
 * in the admin app appears here without a refresh.
 */
interface BookRepository {
    val books: StateFlow<List<Book>>
    val categories: StateFlow<List<Category>>

    /** Every bookcase, ordered floor → block → aisle → position. */
    val shelves: StateFlow<List<Shelf>>

    /** The building: floors, their blocks, and the aisles inside them. */
    val floors: StateFlow<List<Floor>>

    val status: StateFlow<DataStatus>

    fun getBook(id: String): Book?
    fun getSuggestedBooks(): List<Book>
    fun getSimilarBooks(bookId: String): List<Book>
    fun search(query: String): List<Book>
    fun categoryName(id: String): String

    /** Where [book] is, resolved against the live building. */
    fun locate(book: Book): BookLocation
}

class FirestoreBookRepository : BookRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val bookState = MutableStateFlow<List<Book>>(emptyList())
    private val categoryState = MutableStateFlow<List<Category>>(emptyList())
    private val shelfState = MutableStateFlow<List<Shelf>>(emptyList())
    private val floorState = MutableStateFlow<List<Floor>>(emptyList())
    private val statusState = MutableStateFlow<DataStatus>(DataStatus.Loading)

    override val books: StateFlow<List<Book>> = bookState.asStateFlow()
    override val categories: StateFlow<List<Category>> = categoryState.asStateFlow()
    override val shelves: StateFlow<List<Shelf>> = shelfState.asStateFlow()
    override val floors: StateFlow<List<Floor>> = floorState.asStateFlow()
    override val status: StateFlow<DataStatus> = statusState.asStateFlow()

    private val registrations = mutableListOf<ListenerRegistration>()
    private var sessionUid: String? = null
    private var rawShelves: List<Shelf> = emptyList()

    init {
        // Listeners are attached only once someone is signed in. The rules
        // refuse every read before sign-in, and Firestore cancels a listener
        // for good when its first read is refused — so attaching at
        // construction would leave the app empty after the visitor logs in.
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user?.uid == sessionUid) return@addAuthStateListener
            sessionUid = user?.uid
            registrations.forEach { it.remove() }
            registrations.clear()
            rawShelves = emptyList()
            bookState.value = emptyList()
            categoryState.value = emptyList()
            shelfState.value = emptyList()
            floorState.value = emptyList()
            statusState.value = DataStatus.Loading
            if (user != null) attachListeners()
        }
    }

    private fun attachListeners() {
        registrations += db.collection("books").addSnapshotListener { snap, error ->
            if (error != null) {
                statusState.value = DataStatus.Error(arabicMessage(error))
                return@addSnapshotListener
            }
            bookState.value = snap?.documents?.mapNotNull { it.toBook() }?.sortedBy { it.title }.orEmpty()
            statusState.value = DataStatus.Ready
        }
        registrations += db.collection("categories").addSnapshotListener { snap, error ->
            if (error != null) return@addSnapshotListener
            categoryState.value = snap?.documents?.mapNotNull { it.toCategory() }
                ?.sortedBy { it.name }.orEmpty()
        }
        registrations += db.collection("shelves").addSnapshotListener { snap, error ->
            // The map is optional: a failure here must not blank the catalog.
            if (error != null) return@addSnapshotListener
            rawShelves = snap?.documents?.mapNotNull { it.toShelf() }.orEmpty()
            resortShelves()
        }
        registrations += db.collection("floors").addSnapshotListener { snap, error ->
            if (error != null) return@addSnapshotListener
            floorState.value = LibraryPlan.ordered(
                snap?.documents?.mapNotNull { it.toFloor() }.orEmpty()
            )
            resortShelves()
        }
    }

    private fun resortShelves() {
        shelfState.value = rawShelves.sortedWith(LibraryPlan.shelfOrder(floorState.value))
    }

    private fun arabicMessage(error: Throwable): String {
        val raw = error.message.orEmpty()
        return when {
            raw.contains("PERMISSION_DENIED", true) || raw.contains("permission", true) ->
                t("لا تملك صلاحية عرض الفهرس. تأكد من تسجيل الدخول ومن قواعد Firestore.")
            raw.contains("UNAVAILABLE", true) || raw.contains("network", true) ->
                t("تعذّر الاتصال بالمكتبة. تحقق من اتصال الإنترنت.")
            raw.contains("NOT_FOUND", true) ->
                t("قاعدة البيانات غير موجودة. أنشئ Firestore من لوحة تحكم Firebase.")
            else -> t("حدث خطأ أثناء تحميل الفهرس: %s").format(raw.take(120))
        }
    }

    private fun DocumentSnapshot.toBook(): Book? {
        val title = getString("title") ?: return null
        val rawTags = (get("tags") as? List<*>)?.filterIsInstance<String>()
        return Book(
            id = id,
            title = title,
            author = getString("author").orEmpty(),
            category = getString("category").orEmpty(),
            coverColor = getLong("coverColor") ?: 0xFF1F4E46,
            coverBase64 = getString("coverBase64").orEmpty(),
            rating = getDouble("rating") ?: 0.0,
            ratingCount = (getLong("ratingCount") ?: 0L).toInt(),
            tags = rawTags.orEmpty(),
            description = getString("description").orEmpty(),
            shelf = getString("shelf").orEmpty(),
            section = getString("section").orEmpty(),
            floorId = getString("floorId").orEmpty(),
            floor = getString("floor").orEmpty(),
            block = getString("block").orEmpty(),
            aisle = getString("aisle").orEmpty(),
            publisher = getString("publisher").orEmpty(),
            serial = getString("serial").orEmpty(),
            language = getString("language").orEmpty().ifBlank { "العربية" },
            pageCount = (getLong("pageCount") ?: 0L).toInt(),
            dateAdded = getString("dateAdded").orEmpty(),
            status = getString("status").orEmpty().ifBlank { "AVAILABLE" },
            copies = (getLong("copies") ?: 1L).toInt(),
            onLoan = (getLong("onLoan") ?: 0L).toInt()
        )
    }

    private fun DocumentSnapshot.toShelf(): Shelf? {
        val code = getString("code") ?: return null
        return Shelf(
            id = id,
            code = code,
            floorId = getString("floorId").orEmpty(),
            floor = getString("floor").orEmpty(),
            block = getString("block").orEmpty(),
            aisle = getString("aisle").orEmpty(),
            position = (getLong("position") ?: 0L).toInt(),
            side = getString("side").orEmpty(),
            levels = (getLong("levels") ?: 3L).toInt(),
            zone = getString("zone").orEmpty(),
            capacity = (getLong("capacity") ?: 0L).toInt(),
            notes = getString("notes").orEmpty(),
            section = getString("section").orEmpty()
        )
    }

    /** Reads a floor with the blocks and aisles nested inside its document. */
    private fun DocumentSnapshot.toFloor(): Floor? {
        val name = getString("name") ?: return null
        val rawBlocks = get("blocks") as? List<*>
        val blocks = rawBlocks.orEmpty().mapNotNull { raw ->
            val map = raw as? Map<*, *> ?: return@mapNotNull null
            val rawAisles = map["aisles"] as? List<*>
            Block(
                code = map["code"] as? String ?: return@mapNotNull null,
                name = map["name"] as? String ?: "",
                nameEn = map["nameEn"] as? String ?: "",
                row = (map["row"] as? Number)?.toInt() ?: 0,
                column = (map["column"] as? Number)?.toInt() ?: 0,
                aisles = rawAisles.orEmpty().mapNotNull { rawAisle ->
                    val a = rawAisle as? Map<*, *> ?: return@mapNotNull null
                    Aisle(
                        code = a["code"] as? String ?: return@mapNotNull null,
                        name = a["name"] as? String ?: "",
                        nameEn = a["nameEn"] as? String ?: "",
                        order = (a["order"] as? Number)?.toInt() ?: 0
                    )
                }.sortedBy { it.order }
            )
        }.sortedWith(compareBy({ it.row }, { it.column }))

        return Floor(
            id = id,
            name = name,
            nameEn = getString("nameEn").orEmpty(),
            order = (getLong("order") ?: 0L).toInt(),
            blocks = blocks
        )
    }

    private fun DocumentSnapshot.toCategory(): Category? {
        val name = getString("name") ?: return null
        return Category(id, name, getString("iconKey").orEmpty().ifBlank { "book" })
    }

    override fun getBook(id: String): Book? = bookState.value.find { it.id == id }

    /**
     * Rated books first, then the most recently catalogued.
     *
     * A brand-new library has no ratings at all, and sorting by a column of
     * zeroes just returns whatever happened to be first. Falling back to the
     * newest arrivals gives the visitor something that is actually true.
     */
    override fun getSuggestedBooks(): List<Book> =
        bookState.value
            .sortedWith(compareByDescending<Book> { it.rating }.thenByDescending { it.dateAdded })
            .take(8)

    /** Same category, excluding the book itself. */
    override fun getSimilarBooks(bookId: String): List<Book> {
        val book = getBook(bookId) ?: return emptyList()
        return bookState.value
            .filter { it.id != bookId && it.category == book.category }
            .take(6)
    }

    override fun search(query: String): List<Book> {
        if (query.isBlank()) return bookState.value
        val q = query.trim()
        return bookState.value.filter {
            it.title.contains(q, true) || it.author.contains(q, true) ||
                it.shelf.contains(q, true) ||
                it.tags.any { tag -> tag.contains(q, true) } ||
                categoryName(it.category).contains(q, true)
        }
    }

    override fun categoryName(id: String): String =
        categoryState.value.firstOrNull { it.id == id }?.name ?: id

    override fun locate(book: Book): BookLocation = LibraryPlan.locate(
        shelfCode = book.shelf,
        level = book.section,
        floors = floorState.value,
        shelves = shelfState.value,
        floorFallback = book.floor
    )
}

object BookRepositoryProvider {

    @Volatile
    private var instance: BookRepository? = null

    fun init() {
        if (instance == null) instance = FirestoreBookRepository()
    }

    val repository: BookRepository
        get() = instance ?: FirestoreBookRepository().also { instance = it }
}

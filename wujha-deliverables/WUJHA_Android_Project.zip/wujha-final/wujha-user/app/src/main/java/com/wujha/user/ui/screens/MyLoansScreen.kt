package com.wujha.user.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.LoanDates
import com.wujha.user.data.model.Loan
import com.wujha.user.data.model.LoanStatus
import com.wujha.user.data.repository.LoansProvider
import com.wujha.user.data.t
import com.wujha.user.ui.components.EmptyView
import com.wujha.user.ui.components.ScreenScaffold
import com.wujha.user.ui.components.VisitorLoanBadge
import com.wujha.user.ui.components.VisitorLoanCard
import com.wujha.user.ui.theme.AccentGoldDark
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenMid
import com.wujha.user.ui.theme.SignalRed
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * «إعاراتي» — everything this visitor has asked for or is holding.
 *
 * Split into what is happening now and what has already finished, because
 * those are two different questions: "when do I have to bring this back"
 * and "did I ever read that". The one card that opens into a sheet is the
 * current one, where the two things a borrower can actually do live —
 * withdraw a request, or ask for more time.
 */
@Composable
fun MyLoansScreen(
    onBack: () -> Unit,
    onOpenBook: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val repository = LoansProvider.repository
    val loans by repository.myLoans.collectAsState()
    val policy by repository.policy.collectAsState()

    var selected by remember { mutableStateOf<Loan?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    val current = remember(loans) { loans.filter { it.status.isOpen } }
    val past = remember(loans) { loans.filter { !it.status.isOpen } }
    val overdue = current.count { it.isOverdue }

    ScreenScaffold(title = t("إعاراتي"), onBack = onBack) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            if (loans.isEmpty()) {
                item {
                    EmptyView(
                        icon = Icons.Outlined.MenuBook,
                        title = t("لا توجد إعارات بعد"),
                        detail = t("افتح أي كتاب في المكتبة واضغط «طلب إعارة»، وستظهر طلباتك وإعاراتك هنا.")
                    )
                }
                return@LazyColumn
            }

            if (overdue > 0) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = SignalRed.copy(alpha = 0.09f)
                    ) {
                        Text(
                            text = t("لديك %s كتاب متأخر عن موعد الإرجاع. أعِده إلى المكتبة لتتمكّن من الاستعارة مرة أخرى.")
                                .format(overdue),
                            color = SignalRed,
                            fontSize = 12.5.sp,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = t("الحالية"),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = t("%s من %s مسموحة").format(
                            loans.count { it.holdsCopy },
                            policy.maxActivePerMember
                        ),
                        fontSize = 11.5.sp,
                        color = TextSecondary
                    )
                }
            }

            if (current.isEmpty()) {
                item {
                    Text(
                        text = t("لا توجد إعارات أو طلبات قائمة."),
                        color = TextSecondary,
                        fontSize = 12.5.sp,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                }
            }

            items(current) { loan ->
                VisitorLoanCard(
                    loan = loan,
                    pickupWindowDays = policy.pickupWindowDays,
                    onClick = { selected = loan }
                )
            }

            if (past.isNotEmpty()) {
                item {
                    Text(
                        text = t("السجل"),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = TextPrimary,
                        // One padding overload takes horizontal/vertical and
                        // another takes the four sides; they cannot be mixed.
                        modifier = Modifier.padding(
                            start = 20.dp,
                            end = 20.dp,
                            top = 22.dp,
                            bottom = 6.dp
                        )
                    )
                }
                items(past) { loan ->
                    VisitorLoanCard(
                        loan = loan,
                        pickupWindowDays = policy.pickupWindowDays,
                        onClick = { selected = loan }
                    )
                }
            }
        }
    }

    val active = selected
    if (active != null) {
        // Re-read from the live list: the sheet stays open while a request is
        // approved on the librarian's screen, and it should say so.
        val loan = loans.firstOrNull { it.id == active.id } ?: active
        AlertDialog(
            onDismissRequest = { selected = null; message = null },
            containerColor = SurfaceWhite,
            title = {
                Column {
                    Text(loan.bookTitle, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 16.sp)
                    Spacer(Modifier.height(6.dp))
                    VisitorLoanBadge(loan = loan)
                }
            },
            text = {
                Column {
                    if (loan.status == LoanStatus.APPROVED) {
                        Notice(
                            text = t("النسخة محجوزة باسمك. اذهب إلى المكتبة قبل %s لاستلامها.")
                                .format(
                                    LoanDates.format(
                                        LoanDates.dueDate(policy.pickupWindowDays, loan.decidedAt)
                                    )
                                ),
                            tint = ForestGreenMid
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    if (loan.bookShelf.isNotBlank()) {
                        DetailLine(Icons.Outlined.LocationOn, t("الرف"), loan.bookShelf)
                    }
                    if (loan.bookSerial.isNotBlank()) {
                        DetailLine(Icons.Outlined.Badge, t("الرقم التسلسلي"), loan.bookSerial)
                    }
                    if (loan.issuedAt > 0L) {
                        DetailLine(
                            Icons.Outlined.MenuBook,
                            t("تاريخ الاستلام"),
                            LoanDates.format(loan.issuedAt)
                        )
                    }
                    if (loan.dueAt > 0L && loan.status == LoanStatus.ACTIVE) {
                        DetailLine(
                            Icons.Outlined.Autorenew,
                            t("موعد الإرجاع"),
                            "${LoanDates.format(loan.dueAt)} • ${LoanDates.remainingLabel(loan.dueAt)}"
                        )
                    }
                    if (loan.renewals > 0) {
                        DetailLine(
                            Icons.Outlined.Autorenew,
                            t("التجديدات"),
                            t("%s من %s").format(loan.renewals, policy.maxRenewals)
                        )
                    }
                    if (loan.rejectReason.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Notice(text = loan.rejectReason, tint = SignalRed)
                    }
                    val note = message
                    if (note != null) {
                        Spacer(Modifier.height(8.dp))
                        Notice(text = note, tint = AccentGoldDark)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = t("اعرض صفحة الكتاب لمعرفة طريق الوصول إليه."),
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                }
            },
            confirmButton = {
                when {
                    loan.status == LoanStatus.REQUESTED -> TextButton(
                        enabled = !busy,
                        onClick = {
                            busy = true
                            message = null
                            scope.launch {
                                val failure = repository.cancelRequest(loan)
                                busy = false
                                if (failure == null) selected = null else message = failure
                            }
                        }
                    ) {
                        Text(t("سحب الطلب"), color = SignalRed, fontWeight = FontWeight.SemiBold)
                    }

                    loan.status == LoanStatus.ACTIVE && !loan.renewRequested -> TextButton(
                        enabled = !busy && loan.renewals < policy.maxRenewals && !loan.isOverdue,
                        onClick = {
                            busy = true
                            message = null
                            scope.launch {
                                val failure = repository.requestRenewal(loan)
                                busy = false
                                message = failure ?: t("أُرسل طلب التجديد، وسيظهر الرد هنا.")
                            }
                        }
                    ) {
                        Text(t("طلب تجديد المدة"), color = ForestGreen, fontWeight = FontWeight.SemiBold)
                    }

                    else -> TextButton(onClick = { selected = null; message = null }) {
                        Text(t("إغلاق"), color = TextSecondary)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { selected = null; message = null; onOpenBook(loan.bookId) }) {
                    Text(t("صفحة الكتاب"), color = ForestGreenMid)
                }
            }
        )
    }
}

@Composable
private fun Notice(text: String, tint: androidx.compose.ui.graphics.Color) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = tint.copy(alpha = 0.10f)
    ) {
        Text(
            text = text,
            color = tint,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
        )
    }
}

@Composable
private fun DetailLine(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

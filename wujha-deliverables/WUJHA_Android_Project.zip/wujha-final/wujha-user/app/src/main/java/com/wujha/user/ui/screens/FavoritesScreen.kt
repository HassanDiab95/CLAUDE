package com.wujha.user.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.repository.BookRepository
import com.wujha.user.data.repository.FavoritesProvider
import com.wujha.user.data.t
import com.wujha.user.ui.components.BookListRow
import com.wujha.user.ui.components.EmptyView
import com.wujha.user.ui.theme.CreamBackground
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

/**
 * Saved books. Favourites live under the signed-in user's own Firestore
 * document, so they follow the person to any device they sign in on.
 */
@Composable
fun FavoritesScreen(repository: BookRepository, onBookClick: (String) -> Unit) {
    val favoritesRepo = FavoritesProvider.repository
    val favoriteIds by favoritesRepo.favorites.collectAsState()
    val allBooks by repository.books.collectAsState()

    val books = allBooks.filter { favoriteIds.contains(it.id) }

    Column(modifier = Modifier.fillMaxSize().background(CreamBackground)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(t("مفضلاتي"), color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text("(${books.size})", color = TextSecondary, fontSize = 14.sp)
        }

        if (books.isEmpty()) {
            EmptyView(
                icon = Icons.Outlined.BookmarkBorder,
                title = t("لا توجد كتب في مفضلاتك بعد"),
                detail = t("اضغطي على أيقونة الحفظ في صفحة أي كتاب لإضافته هنا.")
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(books) { book ->
                    BookListRow(
                        book = book,
                        isFavorite = true,
                        onClick = { onBookClick(book.id) },
                        onToggleFavorite = { favoritesRepo.toggle(book.id) }
                    )
                }
            }
        }
    }
}

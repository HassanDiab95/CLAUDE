package com.wujha.user.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PendingActions
import androidx.compose.material.icons.outlined.ReportProblem
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.LoanDates
import com.wujha.user.data.model.Loan
import com.wujha.user.data.model.LoanStatus
import com.wujha.user.data.storage.ImageCodec
import com.wujha.user.data.storage.PhotoKind
import com.wujha.user.data.storage.UploadResult
import com.wujha.user.data.t
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.AccentGoldDark
import com.wujha.user.ui.theme.AccentGoldWash
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackgroundAlt
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenMid
import com.wujha.user.ui.theme.ForestGreenWash
import com.wujha.user.ui.theme.SignalRed
import com.wujha.user.ui.theme.StatusLostBg
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * How a loan reads to the person who asked for it.
 *
 * The words differ from the admin app's on purpose. A librarian sees
 * «بانتظار الاستلام» because a copy is sitting on her desk; the borrower
 * sees «جاهز للاستلام» because what matters to them is that they can come
 * and collect it. Same status, two different pieces of news.
 */
private data class VisitorLook(
    val label: String,
    val background: Color,
    val foreground: Color,
    val icon: ImageVector
)

@Composable
private fun lookOf(loan: Loan): VisitorLook = when {
    loan.isOverdue -> VisitorLook(
        label = t("متأخر عن موعد الإرجاع"),
        background = StatusLostBg,
        foreground = SignalRed,
        icon = Icons.Outlined.ReportProblem
    )

    loan.status == LoanStatus.REQUESTED -> VisitorLook(
        label = t("بانتظار موافقة المكتبة"),
        background = AccentGoldWash,
        foreground = AccentGoldDark,
        icon = Icons.Outlined.PendingActions
    )

    loan.status == LoanStatus.APPROVED -> VisitorLook(
        label = t("جاهز للاستلام"),
        background = ForestGreenWash,
        foreground = ForestGreenMid,
        icon = Icons.Outlined.CheckCircle
    )

    loan.status == LoanStatus.ACTIVE -> VisitorLook(
        label = t("بين يديك"),
        background = ForestGreen.copy(alpha = 0.12f),
        foreground = ForestGreen,
        icon = Icons.Outlined.MenuBook
    )

    loan.status == LoanStatus.RETURNED -> VisitorLook(
        label = t("أُعيد للمكتبة"),
        background = CreamBackgroundAlt,
        foreground = TextSecondary,
        icon = Icons.Outlined.CheckCircle
    )

    loan.status == LoanStatus.REJECTED -> VisitorLook(
        label = t("لم تُقبل"),
        background = StatusLostBg,
        foreground = SignalRed,
        icon = Icons.Outlined.ReportProblem
    )

    loan.status == LoanStatus.LOST -> VisitorLook(
        label = t("مسجّل كمفقود"),
        background = StatusLostBg,
        foreground = SignalRed,
        icon = Icons.Outlined.ReportProblem
    )

    else -> VisitorLook(
        label = t("ملغى"),
        background = CreamBackgroundAlt,
        foreground = TextSecondary,
        icon = Icons.Outlined.Schedule
    )
}

/** The pill on a borrowing, in the borrower's words. */
@Composable
fun VisitorLoanBadge(loan: Loan, modifier: Modifier = Modifier) {
    val look = lookOf(loan)
    Surface(modifier = modifier, shape = RoundedCornerShape(20.dp), color = look.background) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(look.icon, contentDescription = null, tint = look.foreground, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(5.dp))
            Text(
                text = look.label,
                color = look.foreground,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/**
 * One borrowing in «إعاراتي».
 *
 * The line under the title is whichever date the borrower actually needs:
 * when a request was sent, by when a held copy must be collected, or how
 * long is left before a book has to go back.
 */
@Composable
fun VisitorLoanCard(
    loan: Loan,
    pickupWindowDays: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val look = lookOf(loan)
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(42.dp).clip(CircleShape).background(look.background),
                contentAlignment = Alignment.Center
            ) {
                Icon(look.icon, contentDescription = null, tint = look.foreground, modifier = Modifier.size(20.dp))
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    text = loan.bookTitle,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = when {
                        loan.status == LoanStatus.REQUESTED ->
                            t("أُرسل الطلب %s").format(LoanDates.format(loan.requestedAt))
                        loan.status == LoanStatus.APPROVED ->
                            t("استلمه قبل %s").format(
                                LoanDates.format(LoanDates.dueDate(pickupWindowDays, loan.decidedAt))
                            )
                        loan.status == LoanStatus.ACTIVE ->
                            "${t("يُعاد في %s").format(LoanDates.format(loan.dueAt))} • ${LoanDates.remainingLabel(loan.dueAt)}"
                        loan.status == LoanStatus.RETURNED ->
                            t("أُعيد في %s").format(LoanDates.format(loan.returnedAt))
                        else -> loan.rejectReason.ifBlank { LoanDates.format(loan.sortKey) }
                    },
                    fontSize = 11.5.sp,
                    color = if (loan.isOverdue) SignalRed else TextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (loan.renewRequested && loan.status == LoanStatus.ACTIVE) {
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Outlined.Autorenew,
                            contentDescription = null,
                            tint = AccentGoldDark,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = t("طلب التجديد بانتظار الرد"),
                            fontSize = 10.5.sp,
                            color = AccentGoldDark
                        )
                    }
                }
            }
            VisitorLoanBadge(loan)
        }
    }
}

/**
 * Picks the photo of the ID card that goes with a borrowing request.
 *
 * The picker is Android's own `PickVisualMedia`, which hands back the one
 * image the person chose and nothing else — so the app never asks for
 * permission to read their gallery, and never sees a photo they did not
 * deliberately pick. The image is downscaled and compressed on the device
 * before it goes anywhere.
 */
@Composable
fun IdPhotoField(
    base64: String,
    onPicked: (String) -> Unit,
    onCleared: () -> Unit,
    modifier: Modifier = Modifier,
    required: Boolean = true
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null && !busy) {
            busy = true
            error = null
            scope.launch {
                when (val result = ImageCodec.encode(context, uri, PhotoKind.DOCUMENT)) {
                    is UploadResult.Success -> onPicked(result.base64)
                    is UploadResult.Failure -> error = result.message
                }
                busy = false
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Outlined.Badge,
                contentDescription = null,
                tint = ForestGreenMid,
                modifier = Modifier.size(17.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = if (required) t("صورة الهوية (مطلوبة)") else t("صورة الهوية (اختيارية)"),
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = t("تُستخدم لمطابقة الاسم ورقم الهوية فقط، وتُحذف تلقائياً بعد إغلاق الإعارة."),
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(Modifier.height(10.dp))

        val bitmap = remember(base64) { ImageCodec.decode(base64) }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.58f)
                .clip(RoundedCornerShape(14.dp))
                .background(CreamBackgroundAlt),
            contentAlignment = Alignment.Center
        ) {
            when {
                busy -> CircularProgressIndicator(color = ForestGreen, strokeWidth = 2.dp)
                bitmap != null -> Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = t("صورة الهوية"),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth()
                )
                else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Outlined.AddAPhoto,
                        contentDescription = null,
                        tint = if (required) AccentGold else TextSecondary,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(t("لم تُرفق صورة بعد"), color = TextSecondary, fontSize = 11.5.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row {
            Surface(
                onClick = {
                    picker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                enabled = !busy,
                shape = RoundedCornerShape(12.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Text(
                    text = if (base64.isBlank()) t("اختيار صورة") else t("تغيير الصورة"),
                    color = ForestGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                )
            }
            if (base64.isNotBlank()) {
                Spacer(Modifier.width(8.dp))
                Surface(
                    onClick = onCleared,
                    enabled = !busy,
                    shape = RoundedCornerShape(12.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Text(
                        text = t("إزالة"),
                        color = SignalRed,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                    )
                }
            }
        }

        val currentError = error
        if (currentError != null) {
            Spacer(Modifier.height(6.dp))
            Text(currentError, color = SignalRed, fontSize = 11.sp)
        } else if (base64.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = t("حجم الصورة %s ك.ب").format(ImageCodec.storedKilobytes(base64)),
                color = TextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

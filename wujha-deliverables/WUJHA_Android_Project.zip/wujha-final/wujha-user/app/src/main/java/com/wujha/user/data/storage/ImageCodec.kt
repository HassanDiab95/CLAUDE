package com.wujha.user.data.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** Result of preparing a photo: either its Base64 payload, or an Arabic reason. */
sealed interface UploadResult {
    data class Success(val base64: String) : UploadResult
    data class Failure(val message: String) : UploadResult
}

/**
 * How hard to squeeze a particular kind of photo.
 *
 * A Firestore document is capped at 1 MiB and Base64 inflates bytes by about
 * a third, so the ceiling below is on the raw JPEG: a cover leaves plenty of
 * room for the rest of the book, and an avatar is small enough that a list of
 * fifty of them still loads quickly.
 */
enum class PhotoKind(val maxDimension: Int, val targetBytes: Int) {
    /** A book cover, shown as large as half the screen. */
    COVER(700, 450 * 1024),

    /** A profile photo, never shown bigger than a thumbnail. */
    AVATAR(360, 90 * 1024),

    /**
     * A photo of an ID card, attached to a borrowing request.
     *
     * Allowed to be larger than a cover because a librarian has to *read*
     * it — a name and a ten-digit number have to survive the compression,
     * or the review step is theatre. It is still kept well inside the
     * document limit, and it is erased as soon as the loan ends.
     */
    DOCUMENT(1000, 300 * 1024)
}

/**
 * Turns a photo the person picked into a Base64 JPEG string that lives
 * directly on a Firestore document — no Firebase Storage bucket involved.
 *
 * Everything is decoded from one in-memory copy of the file: some content
 * providers (cloud-backed gallery items, a few file managers) only allow a
 * `content://` Uri to be opened once, so reopening it part-way through would
 * fail on exactly the photos people most often pick.
 */
object ImageCodec {

    suspend fun encode(
        context: Context,
        uri: Uri,
        kind: PhotoKind = PhotoKind.COVER
    ): UploadResult = withContext(Dispatchers.Default) {
        try {
            val raw = readAllBytes(context, uri)
                ?: return@withContext UploadResult.Failure("تعذّر فتح الصورة المختارة، جرّب اختيارها مرة أخرى.")
            if (raw.isEmpty()) {
                return@withContext UploadResult.Failure("الملف المختار فارغ أو غير صالح.")
            }

            val bitmap = decodeDownsampled(raw, kind.maxDimension)
                ?: return@withContext UploadResult.Failure("تعذّرت قراءة الصورة، جرّب صورة بصيغة أخرى (JPEG أو PNG).")

            val rotated = applyExifRotation(bitmap, raw)
            val squared = if (kind == PhotoKind.AVATAR) cropToSquare(rotated) else rotated
            val jpegBytes = compressToBudget(squared, kind.targetBytes)

            if (jpegBytes.size > kind.targetBytes) {
                UploadResult.Failure("الصورة كبيرة جدًا حتى بعد الضغط، جرّب صورة أخرى.")
            } else {
                UploadResult.Success(Base64.encodeToString(jpegBytes, Base64.NO_WRAP))
            }
        } catch (e: OutOfMemoryError) {
            UploadResult.Failure("الصورة كبيرة جدًا على الذاكرة، جرّب صورة أصغر.")
        } catch (e: Exception) {
            UploadResult.Failure("تعذّرت معالجة الصورة: ${e.message.orEmpty().take(100)}")
        }
    }

    /** Decodes a stored Base64 photo. Returns null for an empty or corrupt value. */
    fun decode(base64: String): Bitmap? {
        if (base64.isBlank()) return null
        return try {
            val bytes = Base64.decode(base64, Base64.NO_WRAP)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            null
        }
    }

    /** Roughly how many kilobytes a stored photo occupies on its document. */
    fun storedKilobytes(base64: String): Int = (base64.length * 3 / 4) / 1024

    // ---------------------------------------------------------------------

    private fun readAllBytes(context: Context, uri: Uri): ByteArray? =
        context.contentResolver.openInputStream(uri)?.use { it.readBytes() }

    private fun decodeDownsampled(raw: ByteArray, maxDimension: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (
            bounds.outWidth / (sample * 2) >= maxDimension ||
            bounds.outHeight / (sample * 2) >= maxDimension
        ) {
            sample *= 2
        }

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val sampled = BitmapFactory.decodeByteArray(raw, 0, raw.size, opts) ?: return null

        val longest = maxOf(sampled.width, sampled.height)
        if (longest <= maxDimension) return sampled
        val scale = maxDimension.toFloat() / longest
        return Bitmap.createScaledBitmap(
            sampled,
            (sampled.width * scale).toInt().coerceAtLeast(1),
            (sampled.height * scale).toInt().coerceAtLeast(1),
            true
        )
    }

    /** Rotates or flips per the file's EXIF orientation tag, if it has one. */
    private fun applyExifRotation(bitmap: Bitmap, raw: ByteArray): Bitmap {
        val orientation = try {
            ExifInterface(ByteArrayInputStream(raw))
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        if (orientation == ExifInterface.ORIENTATION_NORMAL ||
            orientation == ExifInterface.ORIENTATION_UNDEFINED
        ) {
            return bitmap
        }

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            else -> return bitmap
        }
        return try {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } catch (e: Exception) {
            bitmap
        }
    }

    /** Centre-crops to a square, so an avatar fills its circle at any aspect. */
    private fun cropToSquare(bitmap: Bitmap): Bitmap {
        val side = minOf(bitmap.width, bitmap.height)
        if (side == bitmap.width && side == bitmap.height) return bitmap
        return try {
            Bitmap.createBitmap(
                bitmap,
                (bitmap.width - side) / 2,
                (bitmap.height - side) / 2,
                side,
                side
            )
        } catch (e: Exception) {
            bitmap
        }
    }

    /** JPEG, dropping quality until it fits the budget or quality bottoms out. */
    private fun compressToBudget(bitmap: Bitmap, targetBytes: Int): ByteArray {
        var quality = 85
        var bytes: ByteArray
        do {
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            bytes = out.toByteArray()
            quality -= 15
        } while (bytes.size > targetBytes && quality >= 25)
        return bytes
    }
}

package com.wujha.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.repository.BookRepository
import com.wujha.user.data.repository.DataStatus
import com.wujha.user.data.repository.FavoritesProvider
import com.wujha.user.data.t
import com.wujha.user.ui.components.BookListRow
import com.wujha.user.ui.components.EmptyView
import com.wujha.user.ui.components.ErrorView
import com.wujha.user.ui.components.LoadingView
import com.wujha.user.ui.components.SearchField
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackground
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

private const val ALL_CATEGORIES = "__all__"

@Composable
fun SearchScreen(
    repository: BookRepository,
    onBookClick: (String) -> Unit,
    initialCategoryId: String? = null
) {
    val favoritesRepo = FavoritesProvider.repository
    val favoriteIds by favoritesRepo.favorites.collectAsState()

    val books by repository.books.collectAsState()
    val categories by repository.categories.collectAsState()
    val status by repository.status.collectAsState()

    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(initialCategoryId ?: ALL_CATEGORIES) }

    val results = remember(query, selectedCategory, books) {
        repository.search(query).filter { book ->
            selectedCategory == ALL_CATEGORIES || book.category == selectedCategory
        }
    }

    if (status is DataStatus.Error) {
        ErrorView(
            message = (status as DataStatus.Error).message,
            modifier = Modifier.background(CreamBackground)
        )
        return
    }
    if (status is DataStatus.Loading && books.isEmpty()) {
        LoadingView(modifier = Modifier.background(CreamBackground))
        return
    }

    Column(modifier = Modifier.fillMaxSize().background(CreamBackground)) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            Text(t("بحث"), color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            SearchField(
                value = query,
                onValueChange = { query = it },
                placeholder = t("ابحثي عن كتاب، مُؤلف، أو قسم...")
            )
        }

        if (categories.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    CategoryFilterChip(
                        label = t("الكل"),
                        selected = selectedCategory == ALL_CATEGORIES,
                        onClick = { selectedCategory = ALL_CATEGORIES }
                    )
                }
                items(categories) { category ->
                    CategoryFilterChip(
                        label = category.name,
                        selected = selectedCategory == category.id,
                        onClick = {
                            selectedCategory =
                                if (selectedCategory == category.id) ALL_CATEGORIES else category.id
                        }
                    )
                }
            }
        }

        Text(
            text = t("%s نتيجة").format(results.size),
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
        )

        if (results.isEmpty()) {
            EmptyView(
                icon = Icons.Outlined.Search,
                title = t("لا توجد نتائج مطابقة"),
                detail = t("جرّبي كلمات أخرى أو اختاري قسماً مختلفاً.")
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(results) { book ->
                    BookListRow(
                        book = book,
                        isFavorite = favoriteIds.contains(book.id),
                        onClick = { onBookClick(book.id) },
                        onToggleFavorite = { favoritesRepo.toggle(book.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryFilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (selected) ForestGreen else SurfaceWhite,
        border = if (selected) null else BorderStroke(1.dp, BorderLight)
    ) {
        Text(
            text = label,
            color = if (selected) SurfaceWhite else TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

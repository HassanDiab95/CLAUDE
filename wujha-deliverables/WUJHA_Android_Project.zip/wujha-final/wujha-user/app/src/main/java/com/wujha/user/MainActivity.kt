package com.wujha.user

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.wujha.user.data.Localization
import com.wujha.user.data.PreferencesProvider
import com.wujha.user.data.auth.AuthProviderHolder
import com.wujha.user.data.notify.NotificationStoreProvider
import com.wujha.user.data.repository.AccountProvider
import com.wujha.user.data.repository.BookRepositoryProvider
import com.wujha.user.data.repository.FavoritesProvider
import com.wujha.user.data.repository.LoansProvider
import com.wujha.user.navigation.WujhaNavGraph
import com.wujha.user.ui.theme.WujhaTheme
import com.wujha.user.ui.theme.WujhaThemeState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Firebase auto-initialises from google-services.json before onCreate.
        // The repositories attach their Firestore listeners on construction.
        AuthProviderHolder.init()
        BookRepositoryProvider.init()
        FavoritesProvider.init()
        AccountProvider.init()
        LoansProvider.init()
        PreferencesProvider.init(applicationContext)
        NotificationStoreProvider.init(applicationContext)
        Localization.init(applicationContext)

        // Light or dark: the saved choice, plus the phone's night mode. Android
        // re-creates the activity when night mode changes, so this re-runs.
        WujhaThemeState.init(this)

        enableEdgeToEdge()
        setContent {
            WujhaTheme {
                // Dark status-bar icons on the light palette, light ones on the dark.
                val dark = WujhaThemeState.isDark
                SideEffect {
                    WindowCompat.getInsetsController(window, window.decorView).apply {
                        isAppearanceLightStatusBars = !dark
                        isAppearanceLightNavigationBars = !dark
                    }
                }
                Surface(modifier = Modifier.fillMaxSize()) {
                    WujhaNavGraph()
                }
            }
        }
    }
}

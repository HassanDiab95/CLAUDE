package com.wujha.user.data.notify

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * What this device has already shown, and what the person has already read.
 *
 * Two different questions, so two different sets. `posted` stops the same
 * approval from being pushed into the tray again on every launch; `read`
 * drives the little number beside «الإشعارات» and is cleared by opening the
 * screen. Both are per-device on purpose: a notification is a thing that
 * happened on a phone, not a fact about the library.
 */
class NotificationStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("wujha_user_notifications", Context.MODE_PRIVATE)

    private val unreadState = MutableStateFlow(0)

    /** How many events the person has not opened the screen on yet. */
    val unread: StateFlow<Int> = unreadState.asStateFlow()

    /**
     * True once this device has gone through the list at least once.
     *
     * The first launch after installing (or after signing in to an account
     * with history) would otherwise fire a notification for every past
     * loan at once. The first pass records the keys silently; only what
     * happens after that is news.
     */
    fun hasBaseline(): Boolean = prefs.getBoolean(BASELINE, false)

    fun setBaseline() {
        prefs.edit().putBoolean(BASELINE, true).apply()
    }

    fun wasPosted(key: String): Boolean = prefs.getStringSet(POSTED, emptySet())!!.contains(key)

    fun markPosted(keys: Collection<String>) {
        if (keys.isEmpty()) return
        // A new set every time: SharedPreferences explicitly does not promise
        // to notice a set that was mutated in place.
        val updated = prefs.getStringSet(POSTED, emptySet())!!.toMutableSet()
        updated += keys
        prefs.edit().putStringSet(POSTED, trim(updated)).apply()
    }

    fun isRead(key: String): Boolean = prefs.getStringSet(READ, emptySet())!!.contains(key)

    /** Called when the notifications screen is opened. */
    fun markRead(keys: Collection<String>) {
        val updated = prefs.getStringSet(READ, emptySet())!!.toMutableSet()
        updated += keys
        prefs.edit().putStringSet(READ, trim(updated)).apply()
        unreadState.value = 0
    }

    /** Recomputes the badge from the events currently derived from the data. */
    fun refreshUnread(keys: Collection<String>) {
        val read = prefs.getStringSet(READ, emptySet())!!
        unreadState.value = keys.count { it !in read }
    }

    /**
     * Keeps the stored sets from growing without end.
     *
     * Only the newest keys can still match a live event — an older one
     * belongs to a loan that has long since left the list — so the set is
     * capped and the oldest entries are dropped.
     */
    private fun trim(keys: MutableSet<String>): Set<String> =
        if (keys.size <= LIMIT) keys else keys.toList().takeLast(LIMIT).toSet()

    private companion object {
        const val POSTED = "posted_keys"
        const val BASELINE = "baseline_done"
        const val READ = "read_keys"
        const val LIMIT = 300
    }
}

object NotificationStoreProvider {

    @Volatile
    private var instance: NotificationStore? = null

    /** Called once from MainActivity. */
    fun init(context: Context) {
        if (instance == null) instance = NotificationStore(context)
    }

    val store: NotificationStore
        get() = instance ?: error("NotificationStoreProvider.init(context) must be called first")
}

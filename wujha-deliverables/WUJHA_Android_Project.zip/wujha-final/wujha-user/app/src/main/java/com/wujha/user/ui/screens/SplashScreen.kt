package com.wujha.user.ui.screens

import com.wujha.user.ui.theme.WujhaThemeState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.R
import com.wujha.user.data.t
import com.wujha.user.ui.components.WujhaLockup
import com.wujha.user.ui.theme.CreamBackground
import com.wujha.user.ui.theme.CreamBackgroundAlt
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenMid
import kotlinx.coroutines.delay

/** How long the opening screen holds before the app moves on. */
const val SPLASH_DURATION_MS = 3500L

/**
 * The opening screen.
 *
 * It holds for three and a half seconds and then hands over — long enough to read the
 * name, short enough not to feel like a wait. The delay is the only thing
 * keeping it on screen: the repositories have already begun listening to
 * Firestore by the time this appears, so the pause is spent loading rather
 * than idling.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(SPLASH_DURATION_MS)
        onFinished()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.library_background),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            CreamBackground.copy(alpha = if (WujhaThemeState.isDark) 0.84f else 0.54f),
                            CreamBackground.copy(alpha = if (WujhaThemeState.isDark) 0.78f else 0.44f),
                            CreamBackgroundAlt.copy(alpha = if (WujhaThemeState.isDark) 0.90f else 0.70f)
                        )
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            WujhaLockup(height = 186.dp)
            Spacer(Modifier.height(18.dp))
            Text(
                text = t("مكتبتك .. الوجهة الأسهل"),
                color = ForestGreenMid,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(44.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(32.dp),
                color = ForestGreen,
                strokeWidth = 3.dp
            )
        }
    }
}

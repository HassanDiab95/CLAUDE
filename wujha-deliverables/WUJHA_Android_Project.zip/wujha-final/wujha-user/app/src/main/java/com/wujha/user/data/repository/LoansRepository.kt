package com.wujha.user.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.wujha.user.data.LoanDates
import com.wujha.user.data.model.Book
import com.wujha.user.data.model.Loan
import com.wujha.user.data.model.LoanChannel
import com.wujha.user.data.model.LoanPolicy
import com.wujha.user.data.model.LoanStatus
import com.wujha.user.data.t
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

/**
 * The visitor's own borrowings.
 *
 * This repository can see exactly one person's loans and nobody else's. The
 * query asks for `requesterUid == me` and the security rules refuse any
 * query that does not, which is the same boundary from both sides — so a
 * visitor cannot list the library's loans even by asking for them.
 *
 * That boundary is also why availability is read off the book document
 * rather than counted here: the number of copies out is the sum of
 * everybody's loans, and everybody's loans are precisely what this device
 * is not allowed to see.
 */
class LoansRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val loanState = MutableStateFlow<List<Loan>>(emptyList())
    private val policyState = MutableStateFlow(LoanPolicy.DEFAULT)

    /** This visitor's loans and requests, newest first. */
    val myLoans: StateFlow<List<Loan>> = loanState.asStateFlow()

    /** The library's borrowing rules, so the app can state them up front. */
    val policy: StateFlow<LoanPolicy> = policyState.asStateFlow()

    private val registrations = mutableListOf<ListenerRegistration>()
    private var boundUid: String? = null

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user?.uid == boundUid) return@addAuthStateListener
            boundUid = user?.uid
            registrations.forEach { it.remove() }
            registrations.clear()
            loanState.value = emptyList()
            policyState.value = LoanPolicy.DEFAULT
            if (user != null) attach(user.uid)
        }
    }

    private fun attach(uid: String) {
        // Ordering is done on the device. Firestore needs a composite index
        // for an equality filter plus an orderBy on another field, and asking
        // the library to create one by hand in the console — for a list that
        // is never longer than a handful of rows — would be a poor trade.
        registrations += db.collection(LOANS)
            .whereEqualTo("requesterUid", uid)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                loanState.value = snap?.documents
                    ?.mapNotNull { it.toLoan() }
                    ?.sortedByDescending { it.sortKey }
                    .orEmpty()
            }

        registrations += db.collection(META).document(LOAN_POLICY_DOC)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                policyState.value = if (snap != null && snap.exists()) {
                    LoanPolicy.from(
                        loanDays = snap.getLong("loanDays"),
                        maxRenewals = snap.getLong("maxRenewals"),
                        renewDays = snap.getLong("renewDays"),
                        maxActivePerMember = snap.getLong("maxActivePerMember"),
                        pickupWindowDays = snap.getLong("pickupWindowDays"),
                        requireIdPhoto = snap.getBoolean("requireIdPhoto"),
                        overdueSuspendDays = snap.getLong("overdueSuspendDays")
                    )
                } else {
                    LoanPolicy.DEFAULT
                }
            }
    }

    private fun DocumentSnapshot.toLoan(): Loan? {
        val bookId = getString("bookId") ?: return null
        if (getString("bookTitle").isNullOrBlank()) return null
        return Loan(
            id = id,
            bookId = bookId,
            bookTitle = getString("bookTitle").orEmpty(),
            bookSerial = getString("bookSerial").orEmpty(),
            bookShelf = getString("bookShelf").orEmpty(),
            memberId = getString("memberId").orEmpty(),
            memberName = getString("memberName").orEmpty(),
            memberIdNumber = getString("memberIdNumber").orEmpty(),
            memberPhone = getString("memberPhone").orEmpty(),
            requesterUid = getString("requesterUid").orEmpty(),
            status = LoanStatus.from(getString("status")),
            channel = LoanChannel.from(getString("channel")),
            idPhotoBase64 = getString("idPhotoBase64").orEmpty(),
            idVerified = getBoolean("idVerified") ?: false,
            idVerifiedBy = getString("idVerifiedBy").orEmpty(),
            requestedAt = getLong("requestedAt") ?: 0L,
            decidedAt = getLong("decidedAt") ?: 0L,
            issuedAt = getLong("issuedAt") ?: 0L,
            dueAt = getLong("dueAt") ?: 0L,
            returnedAt = getLong("returnedAt") ?: 0L,
            renewals = (getLong("renewals") ?: 0L).toInt(),
            renewRequested = getBoolean("renewRequested") ?: false,
            decidedBy = getString("decidedBy").orEmpty(),
            issuedBy = getString("issuedBy").orEmpty(),
            returnedBy = getString("returnedBy").orEmpty(),
            rejectReason = getString("rejectReason").orEmpty(),
            notes = getString("notes").orEmpty()
        )
    }

    /** Requests and loans still in progress. */
    fun openLoans(): List<Loan> = loanState.value.filter { it.status.isOpen }

    /** How many copies this visitor is holding or has been promised. */
    fun heldCount(): Int = loanState.value.count { it.holdsCopy }

    /**
     * The ID number this account has already borrowed under, if any.
     *
     * An account belongs to a person, and a person has one card. Letting the
     * same account send a second request under a different number is how the
     * members list ends up with two rows for one human being — so the number
     * is read back from this account's own history and reused.
     *
     * A request the librarian has already matched to a membership wins over
     * one still waiting to be reviewed, because that one is confirmed.
     */
    fun establishedIdNumber(): String? {
        val mine = loanState.value.filter { it.memberIdNumber.isNotBlank() }
        return mine.filter { it.memberId.isNotBlank() }.maxByOrNull { it.sortKey }?.memberIdNumber
            ?: mine.maxByOrNull { it.sortKey }?.memberIdNumber
    }

    /** The name that went with it, so the form does not ask again. */
    fun establishedName(): String? {
        val mine = loanState.value.filter { it.memberName.isNotBlank() }
        return mine.filter { it.memberId.isNotBlank() }.maxByOrNull { it.sortKey }?.memberName
            ?: mine.maxByOrNull { it.sortKey }?.memberName
    }

    /** This visitor's open request or loan on one book, if any. */
    fun openLoanFor(bookId: String): Loan? =
        loanState.value.firstOrNull { it.bookId == bookId && it.status.isOpen }

    /**
     * Why this visitor cannot ask for this book right now, or null if they
     * can.
     *
     * Everything here is also enforced on the librarian's side when the
     * request is approved — that is where it counts. The point of repeating
     * it is that "all copies are out" is a far better thing to read before
     * filling in a form than after waiting a day for an answer.
     */
    fun blockedReason(book: Book): String? {
        val user = auth.currentUser
        val limit = policyState.value.maxActivePerMember
        return when {
            user == null -> t("سجّل الدخول أولاً لطلب الإعارة.")
            user.isAnonymous -> t("جلسة الزائر للتصفّح فقط. أنشئ حساباً بالبريد الإلكتروني لتتمكّن من طلب الإعارة.")
            openLoanFor(book.id) != null -> t("لديك طلب أو إعارة قائمة على هذا الكتاب.")
            !book.isBorrowable -> t("كل نسخ هذا الكتاب مُعارة حالياً. تابع صفحته وسيُفتح الطلب عند توفّر نسخة.")
            heldCount() >= limit -> t("وصلت إلى الحد الأعلى (%s) من الكتب في وقت واحد.").format(limit)
            else -> null
        }
    }

    /**
     * Sends a borrowing request, with the photo of the ID card attached.
     *
     * The photo is the whole reason this is a request rather than a
     * self-service loan: nobody is handed a book because they typed a number
     * into an app, so what this creates is a claim for a librarian to check
     * against a real card. It is stored on the request document and erased
     * the moment the loan closes.
     */
    suspend fun requestLoan(
        book: Book,
        name: String,
        idNumber: String,
        phone: String,
        idPhotoBase64: String
    ): String? {
        val user = auth.currentUser ?: return t("سجّل الدخول أولاً لطلب الإعارة.")
        blockedReason(book)?.let { return it }

        val cleanName = name.trim()
        val cleanId = idNumber.trim()
        if (cleanName.isBlank()) return t("أدخل الاسم كما هو مكتوب في الهوية.")
        if (cleanId.length < MIN_ID_LENGTH) {
            return t("أدخل رقم هوية صحيحاً (%s أرقام على الأقل).").format(MIN_ID_LENGTH)
        }
        // One account, one card. The admin app refuses the mismatch too, but
        // being told here — before the request is sent and waited on — is the
        // difference between a correction and a wasted day.
        val established = establishedIdNumber()
        if (established != null && established != cleanId) {
            return t("حسابك مرتبط برقم الهوية %s، ولا يمكن استخدام رقم آخر. راجع أمينة المكتبة لتعديل بياناتك.")
                .format(established)
        }
        if (policyState.value.requireIdPhoto && idPhotoBase64.isBlank()) {
            return t("أرفق صورة واضحة للهوية أو بطاقة العضوية لتتمكّن أمينة المكتبة من التحقق.")
        }

        val loan = Loan(
            bookId = book.id,
            bookTitle = book.title,
            bookSerial = book.serial,
            bookShelf = book.shelf,
            memberName = cleanName,
            memberIdNumber = cleanId,
            memberPhone = phone.trim(),
            requesterUid = user.uid,
            status = LoanStatus.REQUESTED,
            channel = LoanChannel.APP,
            idPhotoBase64 = idPhotoBase64,
            requestedAt = LoanDates.now()
        )

        return try {
            db.collection(LOANS).add(loan.toMap()).await()
            null
        } catch (e: Exception) {
            message(e)
        }
    }

    /**
     * Withdraws a request that has not been answered yet.
     *
     * Only a request. Once a copy has been set aside the visitor's device is
     * no longer the right place to release it — that changes how many copies
     * the library has on the shelf, which only the admin app may write.
     */
    suspend fun cancelRequest(loan: Loan): String? {
        if (loan.status != LoanStatus.REQUESTED) {
            return t("لا يمكن إلغاء الطلب بعد موافقة المكتبة. راجع أمينة المكتبة.")
        }
        return try {
            db.collection(LOANS).document(loan.id).update(
                mapOf(
                    "status" to LoanStatus.CANCELLED.name,
                    "decidedAt" to LoanDates.now(),
                    "rejectReason" to t("ألغى مقدّم الطلب طلبه"),
                    "idPhotoBase64" to ""
                )
            ).await()
            null
        } catch (e: Exception) {
            message(e)
        }
    }

    /** Asks the library for more time; the answer comes from the librarian. */
    suspend fun requestRenewal(loan: Loan): String? {
        val policy = policyState.value
        if (loan.status != LoanStatus.ACTIVE) return t("لا يمكن طلب التجديد إلا لكتاب بين يديك.")
        if (loan.renewals >= policy.maxRenewals) {
            return t("استُهلك عدد التجديدات المسموح (%s) لهذه الإعارة.").format(policy.maxRenewals)
        }
        if (loan.isOverdue) {
            return t("الإعارة متأخرة ولا تُجدَّد. أعِد الكتاب إلى المكتبة أولاً.")
        }
        if (loan.renewRequested) return t("طلب التجديد مُرسل بالفعل وبانتظار الرد.")
        return try {
            db.collection(LOANS).document(loan.id)
                .update(mapOf("renewRequested" to true)).await()
            null
        } catch (e: Exception) {
            message(e)
        }
    }

    private fun message(error: Throwable): String {
        val raw = error.message.orEmpty()
        return when {
            raw.contains("PERMISSION_DENIED", true) || raw.contains("permission", true) ->
                t("لم تُقبل العملية. تأكد من تسجيل الدخول بحساب كامل، ثم أعد المحاولة.")
            raw.contains("UNAVAILABLE", true) || raw.contains("network", true) ->
                t("تعذّر الاتصال بالمكتبة. تحقق من اتصال الإنترنت.")
            else -> t("تعذّر إتمام العملية: %s").format(raw.take(120))
        }
    }

    private companion object {
        const val LOANS = "loans"
        const val META = "meta"
        const val LOAN_POLICY_DOC = "loanPolicy"

        /** Shortest ID number the form will accept. */
        const val MIN_ID_LENGTH = 6
    }
}

object LoansProvider {

    @Volatile
    private var instance: LoansRepository? = null

    /** Called once from MainActivity, after Firebase has initialised. */
    fun init() {
        if (instance == null) instance = LoansRepository()
    }

    val repository: LoansRepository
        get() = instance ?: LoansRepository().also { instance = it }
}

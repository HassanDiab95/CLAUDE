package com.wujha.user.ui.components

import com.wujha.user.ui.theme.WujhaThemeState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wujha.user.R
import com.wujha.user.ui.theme.CreamBackground
import com.wujha.user.ui.theme.CreamBackgroundAlt

/**
 * The backdrop every screen outside the app wears: a photograph of the
 * library under a cream wash (a dark one in the dark appearance, where the
 * logo switches to its light-on-dark artwork).
 *
 * The wash is cream and not green because of the logo. The mark is dark
 * green artwork, so it needs a light ground to read on — over a dark wash it
 * disappears into it. Keeping the wash light also leaves the library itself
 * visible, which is the point of using the photograph at all; it is only
 * strong enough to stop the shelves and sunlight competing with the form.
 *
 * It deepens towards the foot of the page, where the white card and the
 * links sit and need the most separation.
 *
 * Content is handed a column that already scrolls, so a keyboard opening on
 * a short phone cannot trap a field off-screen.
 */
@Composable
fun AuthScreenColumn(
    modifier: Modifier = Modifier,
    horizontalPadding: Dp = 22.dp,
    verticalPadding: Dp = 0.dp,
    horizontalAlignment: Alignment.Horizontal = Alignment.CenterHorizontally,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.library_background),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            CreamBackground.copy(alpha = if (WujhaThemeState.isDark) 0.86f else 0.62f),
                            CreamBackground.copy(alpha = if (WujhaThemeState.isDark) 0.80f else 0.50f),
                            CreamBackgroundAlt.copy(alpha = if (WujhaThemeState.isDark) 0.92f else 0.82f)
                        )
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = horizontalPadding, vertical = verticalPadding),
            horizontalAlignment = horizontalAlignment,
            content = content
        )
    }
}

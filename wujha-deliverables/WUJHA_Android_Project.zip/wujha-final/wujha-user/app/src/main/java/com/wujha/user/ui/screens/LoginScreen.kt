package com.wujha.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.auth.AuthProviderHolder
import com.wujha.user.data.auth.AuthResult
import com.wujha.user.data.auth.AuthValidator
import com.wujha.user.data.t
import com.wujha.user.ui.auth.rememberGoogleSignIn
import com.wujha.user.ui.components.AuthScreenColumn
import com.wujha.user.ui.components.FormErrorBanner
import com.wujha.user.ui.components.GoogleButton
import com.wujha.user.ui.components.LabeledDivider
import com.wujha.user.ui.components.SecondaryButton
import com.wujha.user.ui.components.WujhaLockup
import com.wujha.user.ui.components.WujhaTextField
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenWash
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextOnBackdrop
import com.wujha.user.ui.theme.TextOnBackdropMuted
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * The way in.
 *
 * Laid out as the brand sheet shows it: the lockup on cream, a short
 * tagline, then one white card holding the whole form. Everything the person
 * has to touch is inside that card, so the eye never has to hunt across the
 * page for the next step.
 */
@Composable
fun LoginScreen(
    onSignedIn: () -> Unit,
    onNavigateToSignUp: () -> Unit
) {
    val repository = AuthProviderHolder.repository
    val scope = rememberCoroutineScope()

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    /** Runs an auth call, showing the spinner and surfacing any failure. */
    fun attempt(block: suspend () -> AuthResult) {
        if (loading) return
        formError = null
        notice = null
        loading = true
        scope.launch {
            when (val result = block()) {
                is AuthResult.Success -> {
                    loading = false
                    onSignedIn()
                }
                is AuthResult.Failure -> {
                    loading = false
                    formError = result.message
                }
            }
        }
    }

    val launchGoogleSignIn = rememberGoogleSignIn { outcome ->
        if (outcome.errorMessage != null) {
            formError = outcome.errorMessage
            loading = false
        } else {
            attempt { repository.signInWithGoogle(outcome.idToken) }
        }
    }

    fun submit() {
        emailError = AuthValidator.emailError(email)
        passwordError = AuthValidator.passwordError(password)
        if (emailError != null || passwordError != null) return
        attempt { repository.signInWithEmail(email, password) }
    }

    AuthScreenColumn {
        Spacer(Modifier.height(36.dp))
        WujhaLockup(
            tagline = t("مكتبتك .. الوجهة الأسهل"),
            taglineColor = TextOnBackdrop
        )
        Spacer(Modifier.height(26.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = SurfaceWhite,
            border = BorderStroke(1.dp, BorderLight)
        ) {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) {
                Text(
                    text = t("تسجيل الدخول"),
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(16.dp))

                WujhaTextField(
                    value = email,
                    onValueChange = { email = it; emailError = null; formError = null },
                    placeholder = t("البريد الإلكتروني"),
                    leadingIcon = Icons.Outlined.Email,
                    keyboardType = KeyboardType.Email,
                    enabled = !loading,
                    errorText = emailError
                )
                Spacer(Modifier.height(12.dp))
                WujhaTextField(
                    value = password,
                    onValueChange = { password = it; passwordError = null; formError = null },
                    placeholder = t("كلمة المرور"),
                    leadingIcon = Icons.Outlined.Lock,
                    isPassword = true,
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done,
                    enabled = !loading,
                    errorText = passwordError
                )

                if (formError != null) {
                    Spacer(Modifier.height(12.dp))
                    FormErrorBanner(message = formError.orEmpty())
                }
                val currentNotice = notice
                if (currentNotice != null) {
                    Spacer(Modifier.height(12.dp))
                    Surface(shape = RoundedCornerShape(12.dp), color = ForestGreenWash) {
                        Text(
                            text = currentNotice,
                            color = ForestGreen,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))
                SignInButton(loading = loading, onClick = { submit() })

                Spacer(Modifier.height(6.dp))
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    TextButton(
                        onClick = {
                            val error = AuthValidator.emailError(email)
                            if (error != null) {
                                emailError = error
                            } else {
                                loading = true
                                scope.launch {
                                    val result = repository.sendPasswordReset(email)
                                    loading = false
                                    notice = (result as? AuthResult.Failure)?.message
                                }
                            }
                        },
                        enabled = !loading
                    ) {
                        Text(t("نسيت كلمة المرور؟"), color = AccentGold, fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.height(10.dp))
                LabeledDivider(text = t("أو"))
                Spacer(Modifier.height(14.dp))
                GoogleButton(
                    text = t("المتابعة باستخدام Google"),
                    onClick = { launchGoogleSignIn() },
                    enabled = !loading
                )
                Spacer(Modifier.height(10.dp))
                SecondaryButton(
                    text = t("الدخول كزائر (تصفّح فقط)"),
                    onClick = { attempt { repository.signInAsGuest() } },
                    leadingIcon = Icons.Outlined.PersonOutline,
                    iconTint = TextSecondary,
                    enabled = !loading
                )

            }
        }

        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("ليس لديك حساب؟"), color = TextOnBackdropMuted, fontSize = 13.sp)
            TextButton(onClick = onNavigateToSignUp, enabled = !loading) {
                Text(
                    text = t("إنشاء حساب جديد"),
                    color = ForestGreen,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(Modifier.height(32.dp))
    }
}

/**
 * The primary action, drawn as the brand sheet shows it: a full-width dark
 * green pill with a chevron pointing the way forward.
 */
@Composable
private fun SignInButton(loading: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        enabled = !loading,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = ForestGreen
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = SurfaceWhite,
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = Icons.Outlined.ChevronLeft,
                    contentDescription = null,
                    tint = SurfaceWhite,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = t("تسجيل الدخول"),
                    color = SurfaceWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 6.dp)
                )
            }
        }
    }
}

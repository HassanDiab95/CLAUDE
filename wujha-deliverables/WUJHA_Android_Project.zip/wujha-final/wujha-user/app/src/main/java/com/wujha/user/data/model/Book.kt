package com.wujha.user.data.model

/**
 * A library book as the visitor sees it, including where to find it.
 *
 * Every property has a default so a partially-filled Firestore document
 * reads as defaults rather than throwing. [coverBase64] is the cover photo
 * the admin app stored on the document; when it is empty the UI falls back
 * to [coverColor].
 */
data class Book(
    val id: String = "",
    val title: String = "",
    val author: String = "",
    val category: String = "",
    val coverColor: Long = 0xFF1F4E46,
    val coverBase64: String = "",
    val rating: Double = 0.0,
    val ratingCount: Int = 0,
    val tags: List<String> = emptyList(),
    val description: String = "",

    // ---- Where it is ---------------------------------------------------
    // The bookcase is the real answer: `shelf` plus `level` is enough for
    // LibraryPlan to resolve the floor, block and aisle from the live
    // building. The three fields after them are a snapshot of that answer at
    // the time of cataloguing, kept only so a book whose bookcase was deleted
    // still says roughly where it used to be.
    val shelf: String = "",
    val section: String = "",
    val floorId: String = "",
    val floor: String = "",
    val block: String = "",
    val aisle: String = "",

    val publisher: String = "",
    /** The library's own number for the copy, e.g. "WJ-0023". */
    val serial: String = "",
    val language: String = "العربية",
    val pageCount: Int = 0,
    /** When the library catalogued it, "YYYY-MM-DD". */
    val dateAdded: String = "",
    val status: String = "AVAILABLE",

    /** How many copies the library holds of this title. */
    val copies: Int = 1,

    /**
     * How many of those copies are off the shelf — held for someone or out
     * on loan. Maintained by the admin app inside its loan transactions.
     *
     * This is why it is on the book document rather than counted from the
     * loans: a visitor may only read their own loans, so their device could
     * never add up everybody else's.
     */
    val onLoan: Int = 0
) {
    val isAvailable: Boolean get() = status == "AVAILABLE"

    /** Copies that could be borrowed today. */
    val availableCopies: Int get() = (copies - onLoan).coerceAtLeast(0)

    /** True while the library has a copy to lend. */
    val isBorrowable: Boolean get() = status != "LOST" && availableCopies > 0

    val statusLabel: String get() = when (status) {
        "BORROWED" -> "مستعار"
        "LOST" -> "مفقود"
        else -> "متوفر"
    }

    /** One line on whether it can be borrowed right now. */
    val availabilityLabel: String get() = when {
        status == "LOST" -> "مفقود"
        availableCopies <= 0 -> "كل النسخ مُعارة حالياً"
        else -> "متاح للاستعارة"
    }
}

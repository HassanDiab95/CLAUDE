package com.wujha.user.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The book the visitor is walking to right now — and nothing else.
 *
 * The الوجهة tab used to be handed whichever book happened to be first in
 * the catalog, which meant tapping it showed a confident route to a book
 * nobody had asked for. A destination is something a person chooses, so it
 * is held here: set when they tap «اعرض الطريق إلى الكتاب», and cleared the
 * moment they tap «إنهاء» — after which the tab shows them standing at the
 * desk with no route, which is the truth.
 *
 * Deliberately in memory only. A walk across a library does not outlive the
 * app being closed, and restoring yesterday's route on launch would be the
 * same wrong answer in a different form.
 */
object DestinationStore {

    private val state = MutableStateFlow("")

    /** The chosen book's id, or empty while the visitor has chosen none. */
    val bookId: StateFlow<String> = state.asStateFlow()

    fun set(id: String) {
        state.value = id
    }

    /** Called when the visitor arrives, or gives up on the walk. */
    fun clear() {
        state.value = ""
    }
}

package com.wujha.user.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.wujha.user.data.PreferencesProvider
import com.wujha.user.data.notify.LoanEventKind
import com.wujha.user.data.notify.LoanEvents
import com.wujha.user.data.notify.NotificationStoreProvider
import com.wujha.user.data.notify.Notifier
import com.wujha.user.data.repository.LoansProvider

/**
 * Watches the visitor's own loans and tells them what changed.
 *
 * It sits in the navigation graph rather than in a screen, so it is alive
 * for as long as the app is, whichever tab is open. There is no service and
 * no push: the Firestore listener is already streaming this visitor's loans,
 * and a librarian's approval arrives on it within a second — this turns that
 * into a notification the person can actually see.
 *
 * Nothing is posted twice, because each event carries a key derived from the
 * loan and the stamp that caused it, and the store remembers which keys have
 * already been shown on this device.
 */
@Composable
fun LoanNotificationWatcher() {
    val context = LocalContext.current
    val repository = LoansProvider.repository
    val loans by repository.myLoans.collectAsState()
    val policy by repository.policy.collectAsState()
    val settings by PreferencesProvider.preferences.settings.collectAsState()
    val store = remember { NotificationStoreProvider.store }

    // Android 13 and up: without this the tray stays empty however correct
    // the rest of this is. Asked once, on the first launch that gets here.
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* granted or not, the in-app list still works */ }

    LaunchedEffect(Unit) {
        Notifier.ensureChannel(context)
        if (Notifier.needsPermission() && !Notifier.hasPermission(context)) {
            permissionLauncher.launch(Notifier.permission)
        }
    }

    LaunchedEffect(loans, policy, settings) {
        val events = LoanEvents.from(loans, policy)
        store.refreshUnread(events.map { it.key })

        val enabled = settings.associate { it.key to it.enabled }
        val fresh = events.filter { !store.wasPosted(it.key) }

        // First run on this device: record what already happened without
        // announcing any of it.
        if (!store.hasBaseline()) {
            store.markPosted(fresh.map { it.key })
            store.setBaseline()
            return@LaunchedEffect
        }

        fresh.forEach { event ->
            val allowed = when (event.kind) {
                LoanEventKind.DUE_SOON, LoanEventKind.OVERDUE ->
                    enabled[KEY_REMINDERS] ?: true
                else -> enabled[KEY_LOANS] ?: true
            }
            if (allowed) Notifier.post(context, event)
        }

        // Marked whether or not they were posted: a switch that is off means
        // "do not tell me", not "tell me later in a burst".
        store.markPosted(fresh.map { it.key })
    }
}

private const val KEY_LOANS = "notify_loans"
private const val KEY_REMINDERS = "notify_reminders"

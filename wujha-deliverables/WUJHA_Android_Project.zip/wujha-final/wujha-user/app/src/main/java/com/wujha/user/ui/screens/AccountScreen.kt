package com.wujha.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.Localization
import com.wujha.user.data.auth.AuthProviderHolder
import com.wujha.user.data.repository.AccountProvider
import com.wujha.user.data.repository.FavoritesProvider
import com.wujha.user.data.notify.NotificationStoreProvider
import com.wujha.user.data.repository.LoansProvider
import com.wujha.user.data.t
import com.wujha.user.ui.auth.clearGoogleSession
import com.wujha.user.ui.components.PrimaryButton
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.components.ProfileAvatar
import com.wujha.user.ui.components.ProfilePhotoPicker
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackground
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenLight
import com.wujha.user.ui.theme.StatusLostText
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

/**
 * Profile tab: who is signed in, how, saved-book count, settings and sign out.
 */
@Composable
fun AccountScreen(
    onSignedOut: () -> Unit,
    onOpenFavorites: () -> Unit,
    onOpen: (String) -> Unit
) {
    val repository = AuthProviderHolder.repository
    val context = LocalContext.current
    val user by repository.currentUser.collectAsState()
    val favorites by FavoritesProvider.repository.favorites.collectAsState()
    val myLoans by LoansProvider.repository.myLoans.collectAsState()
    val unreadNotifications by NotificationStoreProvider.store.unread.collectAsState()
    val accountRepository = AccountProvider.repository
    val profile by accountRepository.profile.collectAsState()

    var showSignOutDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CreamBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Text(t("حسابي"), color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = SurfaceWhite,
            border = BorderStroke(1.dp, BorderLight)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProfileAvatar(
                    photoBase64 = profile?.photoBase64.orEmpty(),
                    initial = user?.initial ?: t("ز"),
                    size = 56.dp,
                    background = ForestGreenLight,
                    foreground = ForestGreen
                )
                Spacer(Modifier.size(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = profile?.name?.takeIf { it.isNotBlank() } ?: user?.displayName ?: t("زائر"),
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = when {
                            user == null -> t("غير مسجّل")
                            user?.isGuest == true -> t("جلسة زائر")
                            user?.email.isNullOrBlank() -> t("حساب مسجّل")
                            else -> user?.email.orEmpty()
                        },
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                    Surface(shape = RoundedCornerShape(8.dp), color = ForestGreenLight) {
                        Text(
                            text = when (user?.method?.name) {
                                "GOOGLE" -> t("تم الدخول عبر Google")
                                "EMAIL" -> t("تم الدخول بالبريد الإلكتروني")
                                "GUEST" -> t("دخول كزائر")
                                else -> t("غير مسجّل")
                            },
                            color = ForestGreen,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        if (user != null && user?.isGuest != true) {
            Spacer(Modifier.height(12.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = t("الصورة الشخصية"),
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = t("تُحفظ الصورة مع حسابك مباشرة، وتظهر لك على كل جهاز تسجّل الدخول منه."),
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    ProfilePhotoPicker(
                        photoBase64 = profile?.photoBase64.orEmpty(),
                        initial = user?.initial ?: t("ز"),
                        accountRepository = accountRepository
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        if (user?.isGuest == true) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = AccentGold.copy(alpha = 0.10f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        t("أنت تتصفحين كزائر"),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        t("أنشئي حساباً للاحتفاظ بمفضلاتك على كل أجهزتك."),
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = SurfaceWhite,
            border = BorderStroke(1.dp, BorderLight)
        ) {
            Column {
                AccountRow(Icons.Outlined.BookmarkBorder, t("مفضلاتي"), t("%s كتاب").format(favorites.size), onOpenFavorites)
                RowDivider()
                // The trailing text is the number that matters: how many
                // books are in this person's hands or waiting for them.
                AccountRow(
                    Icons.Outlined.SwapHoriz,
                    t("إعاراتي"),
                    myLoans.count { it.status.isOpen }.let { open ->
                        if (open == 0) t("لا توجد إعارات") else t("%s قائمة").format(open)
                    }
                ) { onOpen("my_loans") }
                RowDivider()
                AccountRow(
                    Icons.Outlined.NotificationsNone,
                    t("الإشعارات"),
                    if (unreadNotifications > 0) t("%s جديد").format(unreadNotifications) else ""
                ) { onOpen("notifications") }
                RowDivider()
                AccountRow(
                    Icons.Outlined.Language,
                    t("اللغة والمظهر"),
                    Localization.language.label(Localization.isEnglish)
                ) { onOpen("language") }
                RowDivider()
                AccountRow(Icons.Outlined.HelpOutline, t("المساعدة والدعم"), "", { onOpen("help") })
                RowDivider()
                AccountRow(Icons.Outlined.Info, t("عن التطبيق"), t("الإصدار 1.0"), { onOpen("about") })
            }
        }

        Spacer(Modifier.height(20.dp))
        PrimaryButton(text = t("تسجيل الخروج"), onClick = { showSignOutDialog = true })
        Spacer(Modifier.height(24.dp))
    }

    if (showSignOutDialog) {
        AlertDialog(
            onDismissRequest = { showSignOutDialog = false },
            containerColor = SurfaceWhite,
            title = { Text(t("تسجيل الخروج"), fontWeight = FontWeight.Bold) },
            text = { Text(t("هل أنت متأكدة من تسجيل الخروج من حسابك؟")) },
            confirmButton = {
                TextButton(onClick = {
                    showSignOutDialog = false
                    repository.signOut()
                    clearGoogleSession(context)
                    onSignedOut()
                }) {
                    Text(t("تسجيل الخروج"), color = StatusLostText, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutDialog = false }) {
                    Text(t("إلغاء"), color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun AccountRow(icon: ImageVector, label: String, trailing: String, onClick: () -> Unit) {
    Surface(onClick = onClick, color = SurfaceWhite) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
            Spacer(Modifier.size(12.dp))
            Text(label, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
            if (trailing.isNotBlank()) {
                Text(trailing, color = TextSecondary, fontSize = 12.sp)
            }
            Icon(
                Icons.Outlined.ChevronLeft,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun RowDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(1.dp)
            .background(BorderLight)
    )
}

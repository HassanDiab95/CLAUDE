package com.wujha.user.ui.auth

import android.app.Activity
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.CommonStatusCodes
import com.wujha.user.data.auth.AuthProviderHolder
import com.wujha.user.data.t

/** What came back from the Google account picker. */
data class GoogleSignInOutcome(
    val idToken: String?,
    val displayName: String,
    val email: String,
    val errorMessage: String?
)

/**
 * Gives you a `launch()` lambda that opens the Google account picker and
 * reports the result to [onOutcome].
 *
 * When Firebase is not configured yet there is no Web client ID, so instead
 * of showing a picker that cannot work this reports a demo outcome straight
 * away — that is what lets the Google button do something sensible before
 * you have set up Firebase.
 */
@Composable
fun rememberGoogleSignIn(onOutcome: (GoogleSignInOutcome) -> Unit): () -> Unit {
    val context = LocalContext.current
    val callback = rememberUpdatedState(onOutcome)

    val webClientId = remember(context) { AuthProviderHolder.googleWebClientId(context) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != Activity.RESULT_OK) {
            callback.value(
                GoogleSignInOutcome(null, "", "", t("تم إلغاء تسجيل الدخول عبر Google"))
            )
            return@rememberLauncherForActivityResult
        }
        try {
            val account = GoogleSignIn
                .getSignedInAccountFromIntent(result.data)
                .getResult(ApiException::class.java)
            callback.value(
                GoogleSignInOutcome(
                    idToken = account?.idToken,
                    displayName = account?.displayName.orEmpty(),
                    email = account?.email.orEmpty(),
                    errorMessage = null
                )
            )
        } catch (e: ApiException) {
            // Code 10 is DEVELOPER_ERROR, and in practice it means one thing:
            // this build's SHA-1 is not registered against this package name
            // in the Firebase project. Saying so is more use than the number,
            // because the number sends people looking in the wrong place.
            val message = if (e.statusCode == CommonStatusCodes.DEVELOPER_ERROR) {
                t("بصمة SHA-1 لهذا التطبيق غير مسجّلة في مشروع Firebase. أضفها من إعدادات المشروع ثم أعد تنزيل google-services.json.")
            } else {
                t("فشل تسجيل الدخول عبر Google (رمز الخطأ: %s)").format(e.statusCode)
            }
            callback.value(GoogleSignInOutcome(null, "", "", message))
        }
    }

    return remember(webClientId, context) {
        {
            if (webClientId == null) {
                // No Web client ID means google-services.json predates enabling
                // Google sign-in in the Firebase console.
                callback.value(
                    GoogleSignInOutcome(
                        null, "", "",
                        t("تسجيل الدخول عبر Google غير مُعدّ. فعّل Google في Firebase ثم أعد تنزيل google-services.json.")
                    )
                )
            } else {
                val options = GoogleSignInOptions
                    .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(webClientId)
                    .requestEmail()
                    .build()
                val client = GoogleSignIn.getClient(context, options)
                // Sign out first so the account picker always appears.
                client.signOut()
                launcher.launch(client.signInIntent)
            }
        }
    }
}

/** Clears the cached Google account so the next sign-in shows the picker. */
fun clearGoogleSession(context: Context) {
    runCatching {
        val options = GoogleSignInOptions
            .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()
        GoogleSignIn.getClient(context.applicationContext, options).signOut()
    }
}

package com.wujha.user.data.model

/**
 * How the building is described.
 *
 * A floor (دور) holds one or more blocks (بلوك). Blocks sit on a grid, and
 * the gaps between them are the corridors (ممرات) a visitor walks along.
 * Inside a block, bookcases are arranged in aisles; a bookcase has levels,
 * and a book sits on one of them.
 *
 * ```
 *  الدور الأول
 *  ┌──────────┐  ممر  ┌──────────┐
 *  │  بلوك A  │       │  بلوك B  │     row 0
 *  └──────────┘       └──────────┘
 *        ممر رئيسي  (the corridor between the rows)
 *  ┌──────────┐  ممر  ┌──────────┐
 *  │  بلوك C  │       │  بلوك D  │     row 1
 *  └──────────┘       └──────────┘
 *              ▲ المدخل
 * ```
 *
 * All of this lives in the `floors` collection, one document per floor, so
 * a librarian can describe a real building without anyone editing code.
 */

/** A row of bookcases inside a block. */
data class Aisle(
    /** Short code, unique inside its block, e.g. "A1". */
    val code: String = "",
    /** Arabic name shown to visitors, e.g. "ممر الروايات". */
    val name: String = "",
    val nameEn: String = "",
    val order: Int = 0
) {
    fun displayName(english: Boolean): String =
        if (english) nameEn.ifBlank { code } else name.ifBlank { code }

    fun toMap(): Map<String, Any> =
        mapOf("code" to code, "name" to name, "nameEn" to nameEn, "order" to order)
}

/** A block of shelving on a floor. */
data class Block(
    /** Short code, unique on its floor, e.g. "A". */
    val code: String = "",
    val name: String = "",
    val nameEn: String = "",
    /** Grid row on the floor plan, 0 = furthest from the entrance. */
    val row: Int = 0,
    /** Grid column, 0 = the start edge (right-hand side in Arabic). */
    val column: Int = 0,
    val aisles: List<Aisle> = emptyList()
) {
    fun displayName(english: Boolean): String =
        if (english) nameEn.ifBlank { code } else name.ifBlank { code }

    fun aisle(code: String): Aisle? = aisles.firstOrNull { it.code == code }

    fun toMap(): Map<String, Any> = mapOf(
        "code" to code,
        "name" to name,
        "nameEn" to nameEn,
        "row" to row,
        "column" to column,
        "aisles" to aisles.sortedBy { it.order }.map { it.toMap() }
    )
}

/** One floor of the library. */
data class Floor(
    /** Stable document id, e.g. "ground". Shelves and books point at this. */
    val id: String = "",
    val name: String = "",
    val nameEn: String = "",
    /** Height in the building, 0 = ground. Drives the order everywhere. */
    val order: Int = 0,
    val blocks: List<Block> = emptyList()
) {
    fun displayName(english: Boolean): String =
        if (english) nameEn.ifBlank { name } else name

    fun block(code: String): Block? = blocks.firstOrNull { it.code == code }

    /** Grid size of this floor's plan, at least 1×1 so it is always drawable. */
    val rows: Int get() = (blocks.maxOfOrNull { it.row }?.plus(1) ?: 1).coerceAtLeast(1)
    val columns: Int get() = (blocks.maxOfOrNull { it.column }?.plus(1) ?: 1).coerceAtLeast(1)

    fun toMap(): Map<String, Any> = mapOf(
        "name" to name,
        "nameEn" to nameEn,
        "order" to order,
        "blocks" to blocks.sortedWith(compareBy({ it.row }, { it.column })).map { it.toMap() }
    )
}

/**
 * Where exactly one book is, with every part already resolved to a name.
 *
 * Built by [com.wujha.user.data.LibraryPlan.locate] from the live `floors`
 * and `shelves` collections, so it is never stale: move a bookcase to
 * another aisle and every book on it moves with it.
 */
data class BookLocation(
    val floor: Floor? = null,
    val block: Block? = null,
    val aisle: Aisle? = null,
    val shelf: Shelf? = null,
    /** The level of the bookcase, e.g. "الرف الأوسط". */
    val level: String = "",
    /** Free-text fallbacks kept on the book for anything not resolvable. */
    val floorFallback: String = "",
    val shelfFallback: String = ""
) {
    val isKnown: Boolean get() = shelf != null || shelfFallback.isNotBlank()

    fun floorName(english: Boolean): String =
        floor?.displayName(english) ?: floorFallback

    fun shelfCode(): String = shelf?.code ?: shelfFallback
}

package com.wujha.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.PreferencesProvider
import com.wujha.user.data.t
import com.wujha.user.ui.components.ScreenScaffold
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenLight
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

// ---------------------------------------------------------------------------
// الإشعارات
// ---------------------------------------------------------------------------

@Composable
fun UserNotificationSettingsScreen(onBack: () -> Unit) {
    val preferences = PreferencesProvider.preferences
    val settings by preferences.settings.collectAsState()

    ScreenScaffold(title = t("الإشعارات"), onBack = onBack) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Text(
                text = t("تُحفظ هذه الإعدادات على هذا الجهاز فقط."),
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column {
                    settings.forEachIndexed { index, setting ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    setting.label,
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    setting.detail,
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            Switch(
                                checked = setting.enabled,
                                onCheckedChange = { preferences.toggle(setting.key) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = ForestGreen
                                )
                            )
                        }
                        if (index != settings.lastIndex) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp)
                                    .height(1.dp)
                                    .background(BorderLight)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// المساعدة والدعم
// ---------------------------------------------------------------------------

private data class UserHelpItem(val question: String, val answer: String)

/**
 * Built once when the file loads, so the strings stay in Arabic here and are
 * translated where they are drawn.
 */
private val userHelpItems = listOf(
    UserHelpItem(
        "كيف أجد كتاباً؟",
        "استخدمي خانة البحث في الصفحة الرئيسية أو تبويب البحث. يمكنك البحث بالعنوان أو اسم المؤلف أو القسم."
    ),
    UserHelpItem(
        "كيف أصل إلى الكتاب داخل المكتبة؟",
        "افتحي صفحة الكتاب ثم اضغطي «اعرض الطريق إلى الكتاب»، وستظهر لك خريطة بالمسار إلى الرف الصحيح مع المسافة والوقت المتوقع."
    ),
    UserHelpItem(
        "أين تُحفظ مفضلاتي؟",
        "تُحفظ في حسابك، لذا ستجدينها على أي جهاز تسجّلين الدخول منه. أما في وضع الزائر فهي مرتبطة بالجلسة الحالية فقط."
    ),
    UserHelpItem(
        "كيف أستعير كتاباً؟",
        "افتحي صفحة الكتاب واضغطي «طلب إعارة هذا الكتاب»، ثم اكتبي اسمك ورقم هويتك وأرفقي صورة واضحة للهوية. يراجع الطلب أمين المكتبة، ولو وافق تُحجز النسخة باسمك لتستلميها من المكتبة. تتابعين كل ذلك من «إعاراتي» في حسابك."
    ),
    UserHelpItem(
        "لماذا تُطلب صورة الهوية؟",
        "لأن الكتاب يُسلَّم لشخص بعينه، فيقارن أمين المكتبة الاسم ورقم الهوية المكتوبين بالصورة قبل الموافقة. تُستخدم الصورة لهذه المطابقة فقط، وتُحذف تلقائياً بمجرد إغلاق الإعارة."
    ),
    UserHelpItem(
        "ماذا لو لم أستطع الإرجاع في الموعد؟",
        "اطلبي التجديد من «إعاراتي» قبل انتهاء المدة، وسيظهر الطلب لأمين المكتبة. بعد تجاوز الموعد لا يُقبل التجديد، ويُطلب إرجاع الكتاب أولاً، وقد تُوقف العضوية مع التأخير الطويل."
    ),
    UserHelpItem(
        "طلبت كتاباً وكل نسخه مُعارة، ماذا أفعل؟",
        "لا يُفتح الطلب إلا عند توفّر نسخة. أضيفي الكتاب إلى مفضلاتك وتابعي صفحته: يظهر عدد النسخ المتاحة فيها، وتعود «طلب إعارة» عند رجوع أي نسخة إلى الرف."
    ),
    UserHelpItem(
        "لماذا لا أستطيع طلب الإعارة في وضع الزائر؟",
        "لأن الإعارة تُسجَّل باسم شخص وحساب. أنشئي حساباً بالبريد الإلكتروني — دقيقة واحدة — ثم ستظهر لك خانة الطلب."
    ),
    UserHelpItem(
        "لماذا لا تظهر أي كتب؟",
        "قد لا تكون إدارة المكتبة أضافت كتباً بعد، أو أن جهازك غير متصل بالإنترنت. تحققي من الاتصال ثم أعيدي المحاولة."
    )
)

@Composable
fun UserHelpScreen(onBack: () -> Unit) {
    ScreenScaffold(title = t("المساعدة والدعم"), onBack = onBack) {
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(userHelpItems) { item ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            t(item.question),
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(t(item.answer), color = TextSecondary, fontSize = 12.5.sp, lineHeight = 19.sp)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// عن التطبيق
// ---------------------------------------------------------------------------

@Composable
fun AboutScreen(onBack: () -> Unit) {
    ScreenScaffold(title = t("عن التطبيق"), onBack = onBack) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(72.dp).clip(CircleShape).background(ForestGreenLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.MenuBook,
                    contentDescription = null,
                    tint = ForestGreen,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(t("وِجهة"), color = ForestGreen, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(t("الإصدار 1.0"), color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = t("تطبيق وِجهة يساعد زوّار المكتبة على العثور على الكتب وتحديد موقعها على الرفوف بدقة، بدل البحث اليدوي بين الأرفف."),
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 21.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    Text(
                        t("مشروع تخرج — تطبيق أندرويد بلغة Kotlin وواجهات Jetpack Compose، وقاعدة بيانات Cloud Firestore."),
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 19.sp
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

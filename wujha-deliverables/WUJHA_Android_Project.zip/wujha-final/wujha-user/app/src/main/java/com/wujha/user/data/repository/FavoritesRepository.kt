package com.wujha.user.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The visitor's saved books, stored at `users/{uid}/favorites/{bookId}`.
 *
 * Because they live under the signed-in user's own document, favourites
 * follow the person across devices and stay private to them — the security
 * rules only let a user read and write their own subtree.
 *
 * The listener is re-attached whenever the signed-in user changes, so
 * signing out clears the list and signing in as someone else loads theirs.
 */
class FavoritesRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val state = MutableStateFlow<Set<String>>(emptySet())
    val favorites: StateFlow<Set<String>> = state.asStateFlow()

    private var registration: ListenerRegistration? = null

    init {
        auth.addAuthStateListener { attach(it.currentUser?.uid) }
        attach(auth.currentUser?.uid)
    }

    private fun attach(uid: String?) {
        registration?.remove()
        registration = null
        state.value = emptySet()
        if (uid.isNullOrBlank()) return

        registration = db.collection("users").document(uid)
            .collection("favorites")
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                state.value = snap?.documents?.map { it.id }?.toSet().orEmpty()
            }
    }

    fun isFavorite(bookId: String): Boolean = state.value.contains(bookId)

    /**
     * Adds or removes the book. Optimistically updates local state so the
     * icon flips immediately, then lets the snapshot listener confirm.
     */
    fun toggle(bookId: String) {
        val uid = auth.currentUser?.uid ?: return
        val ref = db.collection("users").document(uid)
            .collection("favorites").document(bookId)

        if (state.value.contains(bookId)) {
            state.value = state.value - bookId
            ref.delete()
        } else {
            state.value = state.value + bookId
            ref.set(mapOf("addedAt" to FieldValue.serverTimestamp()))
        }
    }
}

object FavoritesProvider {

    @Volatile
    private var instance: FavoritesRepository? = null

    fun init() {
        if (instance == null) instance = FavoritesRepository()
    }

    val repository: FavoritesRepository
        get() = instance ?: FavoritesRepository().also { instance = it }
}

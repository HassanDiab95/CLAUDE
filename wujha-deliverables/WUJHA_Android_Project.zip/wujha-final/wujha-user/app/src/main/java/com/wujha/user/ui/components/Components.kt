package com.wujha.user.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.storage.ImageCodec
import com.wujha.user.data.t
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

/**
 * A book cover.
 *
 * Shows the stored photo when [coverBase64] is set, and falls back to a
 * tinted card bearing the title's first letter when it is not — so a book
 * added without a photo still looks deliberate rather than broken.
 */
@Composable
fun BookCover(
    title: String,
    colorHex: Long,
    modifier: Modifier = Modifier,
    coverBase64: String = ""
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(colorHex)),
        contentAlignment = Alignment.Center
    ) {
        val bitmap = remember(coverBase64) { ImageCodec.decode(coverBase64) }
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
        } else {
            Text(text = title.take(1), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun RatingRow(rating: Double, ratingCount: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Star, contentDescription = null, tint = AccentGold, modifier = Modifier.size(16.dp))
        androidx.compose.foundation.layout.Spacer(Modifier.width(4.dp))
        Text(text = rating.toString(), fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 13.sp)
        androidx.compose.foundation.layout.Spacer(Modifier.width(4.dp))
        val countText = if (ratingCount >= 1000) "(${(ratingCount / 1000.0).let { "%.1f".format(it) }}k)" else "($ratingCount)"
        Text(text = t("تقييم %s").format(countText), color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
fun SectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector? = null, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text = title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        if (icon != null) {
            androidx.compose.foundation.layout.Spacer(Modifier.width(6.dp))
            Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth().height(48.dp),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        tonalElevation = 0.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                if (value.isEmpty()) {
                    Text(text = placeholder, color = TextSecondary, fontSize = 14.sp)
                }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = TextPrimary, fontSize = 14.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(ForestGreen)
                )
            }
            Icon(Icons.Outlined.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
        }
    }
}

data class NavTab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

val userNavTabs = listOf(
    NavTab("account", t("حسابي"), Icons.Outlined.PersonOutline),
    NavTab("favorites", t("مفضلاتي"), Icons.Outlined.BookmarkBorder),
    NavTab("navigation", t("الوجهة"), Icons.Outlined.Place),
    NavTab("search", t("بحث"), Icons.Outlined.Search),
    NavTab("home", t("الرئيسية"), Icons.Outlined.Home)
)

@Composable
fun WujhaBottomBar(currentRoute: String?, onTabSelected: (String) -> Unit) {
    Surface(color = SurfaceWhite, tonalElevation = 4.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
        ) {
            userNavTabs.forEach { tab ->
                val selected = currentRoute == tab.route
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(4.dp)
                        .then(
                            Modifier.clip(RoundedCornerShape(10.dp))
                        )
                        .then(
                            if (selected) Modifier.background(ForestGreen.copy(alpha = 0.08f)) else Modifier
                        )
                        .padding(vertical = 6.dp)
                        .then(Modifier),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    androidx.compose.foundation.layout.Box(
                        modifier = Modifier.clip(CircleShape)
                    ) {
                        androidx.compose.material3.IconButton(onClick = { onTabSelected(tab.route) }) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = if (selected) ForestGreen else TextSecondary
                            )
                        }
                    }
                    Text(
                        text = tab.label,
                        fontSize = 11.sp,
                        color = if (selected) ForestGreen else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

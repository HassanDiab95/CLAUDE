package com.wujha.user.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Museum
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.model.Book
import com.wujha.user.data.repository.BookRepository
import com.wujha.user.data.repository.DataStatus
import com.wujha.user.data.t
import com.wujha.user.ui.components.BookCover
import com.wujha.user.ui.components.EmptyView
import com.wujha.user.ui.components.ErrorView
import com.wujha.user.data.notify.NotificationStoreProvider
import com.wujha.user.ui.components.LoadingView
import com.wujha.user.ui.components.NotificationBell
import com.wujha.user.ui.components.RatingRow
import com.wujha.user.ui.components.SearchField
import com.wujha.user.ui.components.SectionHeader
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackground
import com.wujha.user.ui.theme.CreamBackgroundAlt
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

private fun categoryIcon(key: String): ImageVector = when (key) {
    "growth" -> Icons.Filled.SelfImprovement
    "science" -> Icons.Filled.Science
    "history" -> Icons.Filled.Museum
    else -> Icons.Filled.MenuBook
}

@Composable
fun HomeScreen(
    repository: BookRepository,
    onBookClick: (String) -> Unit,
    onCategoryClick: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenAccount: () -> Unit,
    onOpenNotifications: () -> Unit
) {
    var query by remember { mutableStateOf("") }

    // The number on the bell: events this visitor has not opened the
    // notifications screen on yet.
    val unreadNotifications by NotificationStoreProvider.store.unread.collectAsState()

    val books by repository.books.collectAsState()
    val categories by repository.categories.collectAsState()
    val status by repository.status.collectAsState()

    val searchResults = remember(query, books) {
        if (query.isBlank()) emptyList() else repository.search(query)
    }
    val isSearching = query.isNotBlank()
    val suggested = remember(books) { repository.getSuggestedBooks() }

    if (status is DataStatus.Error) {
        ErrorView(
            message = (status as DataStatus.Error).message,
            modifier = Modifier.background(CreamBackground)
        )
        return
    }
    if (status is DataStatus.Loading && books.isEmpty()) {
        LoadingView(message = t("جارٍ تحميل المكتبة..."), modifier = Modifier.background(CreamBackground))
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    NotificationBell(
                        count = unreadNotifications,
                        onClick = onOpenNotifications
                    )
                    Text(t("وجهة"), color = ForestGreen, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    IconButton(onClick = onOpenAccount) {
                        Icon(Icons.Outlined.Menu, contentDescription = t("القائمة"), tint = TextPrimary)
                    }
                }
                Text(
                    text = t("مكتبتك.. بوجهة أسهل"),
                    color = TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Spacer(Modifier.height(16.dp))
                SearchField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = t("ابحثي عن كتاب، مُؤلف، أو قسم...")
                )
            }
        }

        if (books.isEmpty()) {
            item {
                EmptyView(
                    icon = Icons.Outlined.LibraryBooks,
                    title = t("المكتبة فارغة حالياً"),
                    detail = t("لم تُضف أي كتب إلى الفهرس بعد. تواصلي مع إدارة المكتبة.")
                )
            }
            return@LazyColumn
        }

        if (isSearching) {
            item {
                Text(
                    text = t("%s نتيجة لـ \"%s\"").format(searchResults.size, query),
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
            }
            if (searchResults.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            t("لا توجد نتائج مطابقة"),
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            t("جرّبي كلمات أخرى، أو تصفّحي الأقسام."),
                            color = TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            } else {
                items(searchResults) { book ->
                    SearchResultRow(book = book, onClick = { onBookClick(book.id) })
                }
            }
            return@LazyColumn
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(150.dp),
                shape = RoundedCornerShape(18.dp),
                color = CreamBackgroundAlt
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(18.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        t("اكتشفي مكتبتك بخطوة واحدة"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = TextPrimary
                    )
                    Text(
                        t("%s كتاب متاح للتصفح والبحث.").format(books.size),
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                    )
                    Surface(
                        onClick = onOpenSearch,
                        shape = RoundedCornerShape(10.dp),
                        color = ForestGreen
                    ) {
                        Text(
                            t("ابدئي الآن"),
                            color = SurfaceWhite,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 9.dp)
                        )
                    }
                }
            }
        }

        if (suggested.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 22.dp, bottom = 4.dp)) {
                    SectionHeader(
                        title = t("الأعلى تقييماً"),
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(suggested) { book ->
                            SuggestedBookCard(book = book, onClick = { onBookClick(book.id) })
                        }
                    }
                }
            }
        }

        if (categories.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 22.dp)) {
                    SectionHeader(
                        title = t("أقسام المكتبة"),
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(categories) { category ->
                            CategoryChip(
                                name = category.name,
                                icon = categoryIcon(category.iconKey),
                                count = books.count { it.category == category.id },
                                onClick = { onCategoryClick(category.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchResultRow(book: Book, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BookCover(
                title = book.title,
                colorHex = book.coverColor,
                coverBase64 = book.coverBase64,
                modifier = Modifier.width(44.dp).height(60.dp)
            )
            Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(
                    book.title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    book.author,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (book.shelf.isBlank()) t(book.statusLabel) else t("الرف %s • %s").format(book.shelf, t(book.statusLabel)),
                    color = TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            RatingRow(rating = book.rating, ratingCount = book.ratingCount)
        }
    }
}

@Composable
private fun SuggestedBookCard(book: Book, onClick: () -> Unit) {
    Column(modifier = Modifier.width(120.dp).clickable(onClick = onClick)) {
        BookCover(
            title = book.title,
            colorHex = book.coverColor,
            coverBase64 = book.coverBase64,
            modifier = Modifier.fillMaxWidth().aspectRatio(0.72f)
        )
        Text(
            book.title,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp)
        )
        Text(
            book.author,
            fontSize = 11.sp,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        RatingRow(
            rating = book.rating,
            ratingCount = book.ratingCount,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun CategoryChip(name: String, icon: ImageVector, count: Int, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.width(104.dp),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceWhite,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(34.dp).clip(CircleShape)
                    .background(AccentGold.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = AccentGold, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(6.dp))
            Text(
                name,
                fontSize = 11.sp,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(t("%s كتاب").format(count), fontSize = 10.sp, color = TextSecondary)
        }
    }
}

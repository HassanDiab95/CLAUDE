package com.wujha.user.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import com.wujha.user.data.FloorMap
import com.wujha.user.data.PlanRect
import com.wujha.user.data.t
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.BeigeSurface
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackgroundAlt
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenLight
import com.wujha.user.ui.theme.ForestGreenMid
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

/**
 * Draws one floor: its blocks, the corridors between them, the aisles inside
 * them, every bookcase, and the walk from the entrance to a chosen one.
 *
 * The plan is deliberately laid out left-to-right even while the rest of the
 * app is right-to-left. A floor plan is a picture of a building, not a
 * paragraph: mirroring it would put the door on the wrong wall. Arabic labels
 * inside it still shape and read correctly, because each label is its own
 * piece of text.
 *
 * Shapes are drawn on one canvas; labels are real composables positioned over
 * it, so the Arabic renders through the normal text stack rather than being
 * painted glyph by glyph.
 */
@Composable
fun FloorPlanView(
    map: FloorMap,
    modifier: Modifier = Modifier,
    english: Boolean = false,
    showBookcaseLabels: Boolean = true
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(modifier = modifier) {
            val planWidth = maxWidth
            val planHeight = maxHeight

            /** Turns a fraction of the plan into a real offset on screen. */
            fun at(x: Float, y: Float): Pair<Dp, Dp> = planWidth * x to planHeight * y

            Canvas(modifier = Modifier.fillMaxSize()) {
                fun rect(r: PlanRect) = Offset(r.x * size.width, r.y * size.height) to
                    Size(r.w * size.width, r.h * size.height)

                // The floor slab everything sits on.
                drawRoundRect(
                    color = CreamBackgroundAlt,
                    cornerRadius = corner(14f)
                )

                // Corridors first, so blocks sit on top of them.
                map.corridors.forEach { corridor ->
                    val (topLeft, boxSize) = rect(corridor.rect)
                    drawRoundRect(
                        color = if (corridor.isOnRoute) BeigeSurface else BeigeSurface.copy(alpha = 0.45f),
                        topLeft = topLeft,
                        size = boxSize,
                        cornerRadius = corner(6f)
                    )
                }

                // Blocks.
                map.blocks.forEach { shape ->
                    val (topLeft, boxSize) = rect(shape.rect)
                    drawRoundRect(
                        color = SurfaceWhite,
                        topLeft = topLeft,
                        size = boxSize,
                        cornerRadius = corner(10f)
                    )
                    drawRoundRect(
                        color = if (shape.isTarget) AccentGold else BorderLight,
                        topLeft = topLeft,
                        size = boxSize,
                        cornerRadius = corner(10f),
                        style = Stroke(width = if (shape.isTarget) 2.5f.dp.toPx() else 1f.dp.toPx())
                    )
                }

                // The walkway line a visitor stands on in each aisle.
                map.lanes.forEach { lane ->
                    drawLine(
                        color = if (lane.isTarget) AccentGold.copy(alpha = 0.55f)
                        else BorderLight.copy(alpha = 0.7f),
                        start = Offset(lane.rect.x * size.width, lane.walkwayY * size.height),
                        end = Offset(lane.rect.endX * size.width, lane.walkwayY * size.height),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                // Bookcases, with a fill bar showing how full each one is.
                map.markers.forEach { marker ->
                    val (topLeft, boxSize) = rect(marker.rect)
                    drawRoundRect(
                        color = if (marker.isTarget) AccentGold else ForestGreenLight,
                        topLeft = topLeft,
                        size = boxSize,
                        cornerRadius = corner(4f)
                    )
                    if (marker.fill > 0f && !marker.isTarget) {
                        drawRoundRect(
                            color = ForestGreenMid.copy(alpha = 0.55f),
                            topLeft = Offset(topLeft.x, topLeft.y + boxSize.height * (1f - marker.fill)),
                            size = Size(boxSize.width, boxSize.height * marker.fill),
                            cornerRadius = corner(4f)
                        )
                    }
                }

                // The walk itself.
                if (map.hasRoute) {
                    val path = Path()
                    map.route.forEachIndexed { index, point ->
                        val x = point.x * size.width
                        val y = point.y * size.height
                        if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = ForestGreen,
                        style = Stroke(
                            width = 2.5f.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(
                                floatArrayOf(9f.dp.toPx(), 6f.dp.toPx())
                            )
                        )
                    )
                }

                // Where the visitor starts: their bookcase if they named one,
                // otherwise the entrance.
                val start = Offset(map.routeStart.x * size.width, map.routeStart.y * size.height)
                drawCircle(color = ForestGreen, radius = 7f.dp.toPx(), center = start)
                drawCircle(color = SurfaceWhite, radius = 3f.dp.toPx(), center = start)

                // Where they are going.
                map.destination?.let { dest ->
                    val point = Offset(dest.x * size.width, dest.y * size.height)
                    drawCircle(
                        color = AccentGold.copy(alpha = 0.28f),
                        radius = 15f.dp.toPx(),
                        center = point
                    )
                    drawCircle(color = AccentGold, radius = 8f.dp.toPx(), center = point)
                    drawCircle(color = SurfaceWhite, radius = 3.5f.dp.toPx(), center = point)
                }
            }

            // ---- labels -------------------------------------------------
            map.blocks.forEach { shape ->
                val (x, y) = at(shape.rect.x, shape.rect.y)
                Text(
                    text = shape.block.displayName(english),
                    color = if (shape.isTarget) AccentGold else TextPrimary,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .offset(x = x, y = y)
                        .width(planWidth * shape.rect.w)
                        .padding(top = 3.dp, start = 2.dp, end = 2.dp)
                )
            }

            map.lanes.forEach { lane ->
                if (lane.aisle.code.isBlank()) return@forEach
                val (x, y) = at(lane.rect.x, lane.rect.y)
                Text(
                    text = lane.aisle.code,
                    color = if (lane.isTarget) AccentGold else TextSecondary,
                    fontSize = 7.sp,
                    fontWeight = if (lane.isTarget) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    modifier = Modifier.offset(x = x + 2.dp, y = y + planHeight * lane.rect.h * 0.30f)
                )
            }

            if (showBookcaseLabels) {
                map.markers.forEach { marker ->
                    val (x, y) = at(marker.rect.x, marker.rect.y)
                    Text(
                        text = marker.label.substringAfterLast('-'),
                        color = if (marker.isTarget) SurfaceWhite else ForestGreen,
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .offset(x = x, y = y + planHeight * marker.rect.h * 0.20f)
                            .width(planWidth * marker.rect.w)
                    )
                }
            }

            map.start?.let { here ->
                val (hereX, hereY) = at(here.x, here.y)
                Text(
                    text = t("أنت هنا"),
                    color = ForestGreen,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .offset(x = hereX - 30.dp, y = hereY + 8.dp)
                        .width(60.dp)
                )
            }

            val (entranceX, entranceY) = at(map.entrance.x, map.entrance.y)
            Text(
                text = t(map.entranceLabel),
                color = ForestGreen,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .offset(x = entranceX - 30.dp, y = entranceY + 8.dp)
                    .width(60.dp)
            )
        }
    }
}

/** A uniform corner radius in dp, for the canvas's pixel space. */
private fun DrawScope.corner(dp: Float) =
    androidx.compose.ui.geometry.CornerRadius(dp.dp.toPx(), dp.dp.toPx())

/** A small key explaining the colours, shown under a plan. */
@Composable
fun FloorPlanLegend(
    shelfLabel: String,
    targetLabel: String,
    corridorLabel: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LegendDot(ForestGreenLight, shelfLabel)
        LegendDot(AccentGold, targetLabel)
        LegendDot(BeigeSurface, corridorLabel)
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
        Text(label, color = TextSecondary, fontSize = 10.sp, modifier = Modifier.padding(start = 5.dp))
    }
}

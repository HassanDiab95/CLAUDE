package com.wujha.user.ui.screens

import com.wujha.user.ui.theme.TextOnPrimary
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.Localization
import com.wujha.user.data.repository.BookRepository
import com.wujha.user.data.repository.FavoritesProvider
import com.wujha.user.data.repository.LoansProvider
import com.wujha.user.data.LoanDates
import com.wujha.user.data.t
import com.wujha.user.ui.components.BookCover
import com.wujha.user.ui.components.LoadingView
import com.wujha.user.ui.components.RatingRow
import com.wujha.user.ui.components.SectionHeader
import com.wujha.user.ui.components.VisitorLoanBadge
import com.wujha.user.ui.theme.AccentGold
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackground
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.ForestGreenLight
import com.wujha.user.ui.theme.ForestGreenMid
import com.wujha.user.ui.theme.SignalRed
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary

@Composable
fun BookDetailScreen(
    bookId: String,
    repository: BookRepository,
    onBack: () -> Unit,
    onLocateBook: () -> Unit,
    onSimilarBookClick: (String) -> Unit,
    onBorrow: (String) -> Unit,
    onOpenMyLoans: () -> Unit
) {
    // Every state read happens before the early return below, so the set of
    // composable calls is the same whether or not the book has loaded yet.
    val allBooks by repository.books.collectAsState()
    val shelves by repository.shelves.collectAsState()
    val floors by repository.floors.collectAsState()
    val favoritesRepo = FavoritesProvider.repository
    val favoriteIds by favoritesRepo.favorites.collectAsState()
    val loansRepository = LoansProvider.repository
    // Collected, not just read, so the borrowing card answers correctly the
    // moment a request of this visitor's is approved or refused.
    val myLoans by loansRepository.myLoans.collectAsState()
    val loanPolicy by loansRepository.policy.collectAsState()
    val english = Localization.isEnglish

    val book = allBooks.find { it.id == bookId }
    if (book == null) {
        LoadingView(message = t("جارٍ تحميل الكتاب..."), modifier = Modifier.background(CreamBackground))
        return
    }

    val isFavorite = favoriteIds.contains(bookId)
    val location = remember(book, shelves, floors) { repository.locate(book) }
    val similar = repository.getSimilarBooks(bookId)
    val categoryName = repository.categoryName(book.category)

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CreamBackground),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Outlined.ArrowForward, contentDescription = t("رجوع"), tint = TextPrimary)
                }
                IconButton(onClick = { favoritesRepo.toggle(bookId) }) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = if (isFavorite) t("إزالة من المفضلة") else t("حفظ في المفضلة"),
                        tint = if (isFavorite) AccentGold else TextPrimary
                    )
                }
            }
        }

        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
            ) {
                BookCover(
                    title = book.title,
                    colorHex = book.coverColor,
                    coverBase64 = book.coverBase64,
                    modifier = Modifier.width(150.dp).aspectRatio(0.72f)
                )
                Spacer(Modifier.height(16.dp))
                Text(book.title, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = TextPrimary)
                Text(
                    book.author,
                    color = TextSecondary,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Spacer(Modifier.height(8.dp))
                RatingRow(rating = book.rating, ratingCount = book.ratingCount)
                Spacer(Modifier.height(12.dp))
                if (book.tags.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        book.tags.take(3).forEach { tag -> TagChip(tag) }
                    }
                }
            }
        }

        if (book.description.isNotBlank()) {
            item {
                Text(
                    text = book.description,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 21.sp,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)
                )
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.LocationOn,
                            contentDescription = null,
                            tint = ForestGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (book.shelf.isBlank()) t("الموقع غير محدد") else t("الرف %s").format(book.shelf),
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    // Resolved against the live building rather than read off
                    // the book, so a bookcase that has been moved since the
                    // book was catalogued reports where it is now.
                    Text(
                        text = listOfNotNull(
                            location.floorName(english).takeIf { it.isNotBlank() },
                            location.block?.displayName(english),
                            location.aisle?.displayName(english),
                            location.level.takeIf { it.isNotBlank() }?.let { t(it) },
                            location.shelf?.side?.takeIf { it.isNotBlank() }?.let { t(it) }
                        ).joinToString(" • ").ifBlank { t("تواصلي مع موظف المكتبة") },
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp, start = 24.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onLocateBook,
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ForestGreen,
                            contentColor = TextOnPrimary
                        )
                    ) {
                        Text(t("اعرض الطريق إلى الكتاب"), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // ---- Borrowing --------------------------------------------------
        item {
            val existing = myLoans.firstOrNull { it.bookId == bookId && it.status.isOpen }
            val blocked = loansRepository.blockedReason(book)
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Outlined.SwapHoriz,
                            contentDescription = null,
                            tint = ForestGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = t("الإعارة"),
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = if (book.isBorrowable) {
                                t("%s متاحة من %s").format(book.availableCopies, book.copies)
                            } else {
                                t("كل النسخ مُعارة")
                            },
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (book.isBorrowable) ForestGreenMid else SignalRed
                        )
                    }
                    Spacer(Modifier.height(10.dp))

                    if (existing != null) {
                        // Already in the cycle: what this visitor needs is the
                        // state of their own loan, not another request button.
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            VisitorLoanBadge(loan = existing)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = if (existing.dueAt > 0L) {
                                    LoanDates.remainingLabel(existing.dueAt)
                                } else {
                                    t("أُرسل الطلب %s").format(LoanDates.format(existing.requestedAt))
                                },
                                fontSize = 11.5.sp,
                                color = TextSecondary
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onOpenMyLoans,
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ForestGreenLight,
                                contentColor = ForestGreen
                            )
                        ) {
                            Text(t("عرض إعاراتي"), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Text(
                            text = blocked ?: t("مدة الإعارة %s يوماً، ويمكن تجديدها عند الحاجة.")
                                .format(loanPolicy.loanDays),
                            color = if (blocked == null) TextSecondary else SignalRed,
                            fontSize = 11.5.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { onBorrow(bookId) },
                            enabled = blocked == null,
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ForestGreen,
                                contentColor = TextOnPrimary
                            )
                        ) {
                            Text(t("طلب إعارة هذا الكتاب"), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column {
                    InfoRow(t("التصنيف"), categoryName.ifBlank { t("غير مصنّف") })
                    InfoRow(t("الحالة"), t(book.availabilityLabel))
                    InfoRow(t("عدد النسخ"), book.copies.toString())
                    InfoRow(t("دار النشر"), book.publisher.ifBlank { "—" })
                    InfoRow(t("اللغة"), book.language)
                    InfoRow(t("عدد الصفحات"), if (book.pageCount > 0) book.pageCount.toString() else "—")
                }
            }
        }

        if (similar.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    SectionHeader(title = t("كتب مشابهة"), modifier = Modifier.padding(horizontal = 20.dp))
                    Spacer(Modifier.height(10.dp))
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(similar) { other ->
                            Column(
                                modifier = Modifier
                                    .width(100.dp)
                                    .clickable { onSimilarBookClick(other.id) }
                            ) {
                                BookCover(
                                    title = other.title,
                                    colorHex = other.coverColor,
                                    coverBase64 = other.coverBase64,
                                    modifier = Modifier.fillMaxWidth().aspectRatio(0.72f)
                                )
                                Text(
                                    other.title,
                                    fontSize = 12.sp,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 11.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 12.sp)
        Text(value, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TagChip(tag: String) {
    Surface(shape = RoundedCornerShape(20.dp), color = ForestGreenLight) {
        Text(
            text = tag,
            color = ForestGreen,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
        )
    }
}

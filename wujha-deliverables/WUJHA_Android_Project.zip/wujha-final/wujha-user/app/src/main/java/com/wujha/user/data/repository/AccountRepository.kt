package com.wujha.user.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.wujha.user.data.model.AppAccount
import com.wujha.user.data.t
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * The signed-in person's own `users/{uid}` document.
 *
 * Every sign-in registers the account — name, email, which app, when — so
 * that an administrator can later grant the admin role by picking a person
 * off a list. The same document holds the profile photo, as Base64 rather
 * than a Storage URL, so the whole app needs no storage bucket at all.
 *
 * The registering write is a merge: it refreshes the name and timestamp and
 * leaves the photo alone. Failures are silent by design — not being able to
 * write your own profile row is not a reason to block you from reading the
 * catalog.
 */
class AccountRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val profileState = MutableStateFlow<AppAccount?>(null)
    val profile: StateFlow<AppAccount?> = profileState.asStateFlow()

    private var registration: ListenerRegistration? = null
    private var boundUid: String? = null

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user?.uid == boundUid) return@addAuthStateListener
            boundUid = user?.uid
            registration?.remove()
            registration = null
            profileState.value = null
            if (user != null) bind(user)
        }
    }

    private fun bind(user: FirebaseUser) {
        val ref = db.collection(USERS).document(user.uid)

        scope.launch {
            runCatching {
                ref.set(
                    mapOf(
                        "uid" to user.uid,
                        "name" to (user.displayName?.takeIf { it.isNotBlank() }
                            ?: user.email?.substringBefore("@").orEmpty()),
                        "email" to user.email.orEmpty(),
                        "app" to APP,
                        "anonymous" to user.isAnonymous,
                        "lastSeenAt" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                ).await()
            }
        }

        registration = ref.addSnapshotListener { snap, error ->
            if (error != null || snap == null) return@addSnapshotListener
            profileState.value = AppAccount(
                uid = user.uid,
                name = snap.getString("name")
                    ?: user.displayName.orEmpty(),
                email = snap.getString("email") ?: user.email.orEmpty(),
                photoBase64 = snap.getString("photoBase64").orEmpty(),
                app = snap.getString("app").orEmpty(),
                anonymous = snap.getBoolean("anonymous") ?: user.isAnonymous,
                lastSeenMillis = snap.getTimestamp("lastSeenAt")?.toDate()?.time ?: 0L
            )
        }
    }

    /** Saves a new profile photo. Returns an Arabic error, or null on success. */
    suspend fun setPhoto(base64: String): String? = update("photoBase64" to base64)

    /** Clears the profile photo; the UI falls back to the person's initial. */
    suspend fun clearPhoto(): String? = update("photoBase64" to "")

    /** Renames the account, in Firestore and on the Firebase Auth profile. */
    suspend fun setName(name: String): String? {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return t("الرجاء إدخال الاسم")
        val error = update("name" to trimmed)
        if (error == null) {
            runCatching {
                auth.currentUser?.updateProfile(
                    com.google.firebase.auth.UserProfileChangeRequest.Builder()
                        .setDisplayName(trimmed)
                        .build()
                )?.await()
            }
        }
        return error
    }

    private suspend fun update(vararg fields: Pair<String, Any>): String? {
        val uid = auth.currentUser?.uid ?: return t("لم يتم تسجيل الدخول")
        return try {
            db.collection(USERS).document(uid).set(fields.toMap(), SetOptions.merge()).await()
            null
        } catch (e: Exception) {
            val raw = e.message.orEmpty()
            when {
                raw.contains("PERMISSION_DENIED", true) -> t("لا تملك صلاحية تعديل ملفك الشخصي.")
                raw.contains("UNAVAILABLE", true) || raw.contains("network", true) ->
                    t("تعذّر الاتصال بالخادم، تحقق من الإنترنت.")
                else -> t("تعذّر الحفظ: %s").format(raw.take(120))
            }
        }
    }

    private companion object {
        const val USERS = "users"
        const val APP = "user"
    }
}

object AccountProvider {

    @Volatile
    private var instance: AccountRepository? = null

    /** Called once from MainActivity, after Firebase has initialised. */
    fun init() {
        if (instance == null) instance = AccountRepository()
    }

    val repository: AccountRepository
        get() = instance ?: AccountRepository().also { instance = it }
}

package com.wujha.user.data.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.wujha.user.MainActivity
import com.wujha.user.R
import com.wujha.user.data.t

/**
 * The phone's own notification tray.
 *
 * What this is and is not: the app posts these itself, from the live
 * listener, while it is running. There is no push server in this project —
 * nothing can wake a closed app — so a change that happens overnight is
 * waiting in «الإشعارات» when the app is opened rather than buzzing at
 * three in the morning. That is a real limitation and the settings screen
 * says so out loud rather than leaving the switch looking broken.
 */
object Notifier {

    private const val CHANNEL_ID = "wujha_loans"

    /** Android 13 and up refuse to show anything without the user's consent. */
    val permission: String = Manifest.permission.POST_NOTIFICATIONS

    fun needsPermission(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    fun hasPermission(context: Context): Boolean =
        !needsPermission() || ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Creates the channel. Safe to call on every launch — Android keeps the
     * first definition and ignores the rest, which is why the name is set
     * from the current language each time rather than once ever.
     */
    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            t("الإعارة"),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = t("حالة طلبات الإعارة ومواعيد الإرجاع")
        }
        manager.createNotificationChannel(channel)
    }

    /**
     * Posts one event, and opens the app on «إعاراتي» when it is tapped.
     *
     * The notification id is derived from the event's own key, so the same
     * event can never stack up twice in the tray.
     */
    // The permission is checked on the line below, but lint cannot follow a
    // check that lives in another function — hence the suppression rather
    // than a second, redundant check here.
    @SuppressLint("MissingPermission")
    fun post(context: Context, event: LoanEvent) {
        if (!hasPermission(context)) return
        ensureChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_OPEN_LOANS, true)
        }
        val pending = PendingIntent.getActivity(
            context,
            event.key.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(event.title)
            .setContentText(event.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(event.body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()

        // A refused post is not worth crashing over: the event is still in
        // the in-app list, which is the copy that matters.
        runCatching {
            NotificationManagerCompat.from(context).notify(event.key.hashCode(), notification)
        }
    }

    const val EXTRA_OPEN_LOANS = "com.wujha.user.OPEN_LOANS"
}

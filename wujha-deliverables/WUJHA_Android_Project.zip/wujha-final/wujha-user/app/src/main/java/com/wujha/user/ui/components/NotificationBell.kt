package com.wujha.user.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.t
import com.wujha.user.ui.theme.SignalRed
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary

/**
 * The bell, with the number of things waiting behind it.
 *
 * The count is drawn by hand rather than with Material's `BadgedBox`, which
 * is still an experimental API in this version of Compose and would make
 * every screen that shows a bell carry an opt-in annotation for one circle.
 *
 * Above nine it reads «+9»: the exact number stops being useful long before
 * that, and a three-digit badge no longer fits over the icon.
 */
@Composable
fun NotificationBell(
    count: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier, contentAlignment = Alignment.TopEnd) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = Icons.Outlined.NotificationsNone,
                contentDescription = if (count > 0) {
                    t("الإشعارات — %s جديد").format(count)
                } else {
                    t("الإشعارات")
                },
                tint = TextPrimary
            )
        }
        if (count > 0) {
            Box(
                modifier = Modifier
                    // Pulled onto the bell's shoulder: the icon button pads
                    // itself to a 48dp touch target, so the badge would
                    // otherwise float in the corner of empty space.
                    .offset(x = (-6).dp, y = 6.dp)
                    .defaultMinSize(minWidth = 17.dp, minHeight = 17.dp)
                    .clip(CircleShape)
                    .background(SignalRed),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (count > 9) t("+9") else count.toString(),
                    color = SurfaceWhite,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
    }
}

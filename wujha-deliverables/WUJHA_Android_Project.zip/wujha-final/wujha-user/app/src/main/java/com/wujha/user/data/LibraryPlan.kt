package com.wujha.user.data

import androidx.compose.ui.geometry.Offset
import com.wujha.user.data.model.Aisle
import com.wujha.user.data.model.Block
import com.wujha.user.data.model.BookLocation
import com.wujha.user.data.model.Floor
import com.wujha.user.data.model.Shelf
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * A rectangle on the plan, in fractions of the map (0f..1f).
 *
 * x is measured from the **start** edge — the right-hand side while the app
 * is in Arabic — so the drawing code never has to know which way round the
 * screen is: Compose mirrors it for us.
 */
data class PlanRect(val x: Float, val y: Float, val w: Float, val h: Float) {
    val centerX: Float get() = x + w / 2f
    val centerY: Float get() = y + h / 2f
    val endX: Float get() = x + w
    val endY: Float get() = y + h
    val center: Offset get() = Offset(centerX, centerY)
}

/** A block of shelving drawn on the plan. */
data class BlockShape(
    val block: Block,
    val rect: PlanRect,
    val isTarget: Boolean = false
)

/** A corridor between blocks, or the one along the entrance wall. */
data class CorridorShape(
    val rect: PlanRect,
    val label: String,
    val isVertical: Boolean,
    /** True when the route walks down this corridor. */
    val isOnRoute: Boolean = false
)

/** One aisle inside a block: a walkway with bookcases along it. */
data class AisleLane(
    val aisle: Aisle,
    val blockCode: String,
    val rect: PlanRect,
    /** y of the walkway a visitor stands on while scanning this aisle. */
    val walkwayY: Float,
    val isTarget: Boolean = false
)

/** One bookcase drawn on the plan. */
data class ShelfMarker(
    val label: String,
    val rect: PlanRect,
    val isTarget: Boolean = false,
    /** Fill strength 0f..1f — how full the bookcase is against its capacity. */
    val fill: Float = 0f
)

/** Everything one floor needs in order to be drawn, route included. */
data class FloorMap(
    val floor: Floor?,
    val blocks: List<BlockShape> = emptyList(),
    val corridors: List<CorridorShape> = emptyList(),
    val lanes: List<AisleLane> = emptyList(),
    val markers: List<ShelfMarker> = emptyList(),
    val entrance: Offset = Offset(0.5f, 0.96f),
    val entranceLabel: String = "المدخل",
    /** The walking route, start first. Empty when there is nothing to reach. */
    val route: List<Offset> = emptyList(),
    /**
     * Where the walk begins when the visitor has said which bookcase they are
     * standing at. Null means they start at [entrance].
     */
    val start: Offset? = null,
    val destination: Offset? = null,
    val distanceMeters: Int = 0,
    val etaMinutes: Int = 0,
    /** Plain directions, one line per turn. */
    val steps: List<String> = emptyList()
) {
    val hasRoute: Boolean get() = route.size >= 2 && destination != null

    /** The first point of the walk: the visitor's bookcase, or the entrance. */
    val routeStart: Offset get() = start ?: entrance
    val isEmpty: Boolean get() = blocks.isEmpty() && markers.isEmpty()
}

/**
 * Turns the `floors` and `shelves` collections into something drawable, and
 * works out the walk from the door to a particular book.
 *
 * Nothing here is hard-coded about any specific library: change the floors
 * in the admin app and every map in both apps follows.
 */
object LibraryPlan {

    // ---- Geometry ------------------------------------------------------
    /** Perimeter corridor, wide enough to walk down on the plan. */
    private const val MARGIN = 0.07f

    /** The corridor between two neighbouring blocks. */
    private const val CORRIDOR = 0.075f

    /** The corridor along the wall the entrance is in. */
    private const val ENTRY_BAND = 0.10f

    /** Space kept above each aisle's bookcases for the walkway itself. */
    private const val WALKWAY_SHARE = 0.42f

    private const val BLOCK_PAD = 0.012f

    /** Rough real-world scale: the plan is about this many metres across. */
    private const val PLAN_METERS = 42f

    /** Climbing one floor is worth about this much walking. */
    private const val METERS_PER_FLOOR = 14f

    /** An unhurried indoor walking pace. */
    private const val METERS_PER_MINUTE = 55f

    // ---- Resolution ----------------------------------------------------

    /**
     * Where a book is, with every part resolved against the live building.
     *
     * The bookcase is the source of truth: if a bookcase has been moved to a
     * different block since the book was catalogued, this follows the move.
     * The values stored on the book are used only when its bookcase is gone.
     */
    fun locate(
        shelfCode: String,
        level: String,
        floors: List<Floor>,
        shelves: List<Shelf>,
        floorFallback: String = ""
    ): BookLocation {
        val shelf = shelves.firstOrNull { it.code.equals(shelfCode.trim(), ignoreCase = true) }
            ?: return BookLocation(
                level = level,
                floorFallback = floorFallback,
                shelfFallback = shelfCode.trim()
            )

        val floor = floors.firstOrNull { it.id == shelf.floorId }
            ?: floors.firstOrNull { it.name == shelf.floor }
        val block = floor?.block(shelf.block)
        val aisle = block?.aisle(shelf.aisle)

        return BookLocation(
            floor = floor,
            block = block,
            aisle = aisle,
            shelf = shelf,
            level = level.ifBlank { shelf.section },
            floorFallback = shelf.floor.ifBlank { floorFallback },
            shelfFallback = shelf.code
        )
    }

    /** Floors in building order, lowest first. */
    fun ordered(floors: List<Floor>): List<Floor> =
        floors.sortedWith(compareBy({ it.order }, { it.name }))

    /** Bookcases in the order a visitor would walk past them. */
    fun shelfOrder(floors: List<Floor>): Comparator<Shelf> {
        val rank = ordered(floors).withIndex().associate { (i, f) -> f.id to i }
        return compareBy(
            { rank[it.floorId] ?: Int.MAX_VALUE },
            { it.block },
            { it.aisle },
            { if (it.position <= 0) Int.MAX_VALUE else it.position },
            { it.code }
        )
    }

    // ---- The plan ------------------------------------------------------

    /**
     * Lays out one floor.
     *
     * [target] is the bookcase the route leads to; pass null for a plain plan
     * with no route. [fromFloorIndex] is the floor the visitor starts on, so
     * the directions can say "take the stairs up two floors" before the walk.
     *
     * [startShelf] is the bookcase the visitor says they are standing at. The
     * app has no indoor positioning, so without it every walk starts at the
     * entrance (or at the stairs on an upper floor). With it, and on the same
     * floor as the book, the walk starts at that bookcase; on another floor
     * it starts at the stairs and the directions say how to reach them.
     */
    fun floorMap(
        floor: Floor?,
        shelves: List<Shelf>,
        bookCounts: Map<String, Int> = emptyMap(),
        target: Shelf? = null,
        fromFloorIndex: Int = 0,
        floorIndex: Int = 0,
        english: Boolean = false,
        startShelf: Shelf? = null
    ): FloorMap {
        if (floor == null) return FloorMap(floor = null)

        val onFloor = shelves.filter { it.floorId == floor.id || (it.floorId.isBlank() && it.floor == floor.name) }
        val blocks = floor.blocks.sortedWith(compareBy({ it.row }, { it.column }))
        if (blocks.isEmpty()) return FloorMap(floor = floor)

        val rows = floor.rows
        val columns = floor.columns

        val gridTop = MARGIN
        val gridBottom = 1f - MARGIN - ENTRY_BAND
        val gridLeft = MARGIN
        val gridRight = 1f - MARGIN

        val blockH = ((gridBottom - gridTop) - CORRIDOR * (rows - 1)) / rows
        val blockW = ((gridRight - gridLeft) - CORRIDOR * (columns - 1)) / columns

        fun blockRect(b: Block) = PlanRect(
            x = gridLeft + b.column * (blockW + CORRIDOR),
            y = gridTop + b.row * (blockH + CORRIDOR),
            w = blockW,
            h = blockH
        )

        // -- corridors ---------------------------------------------------
        val corridors = mutableListOf<CorridorShape>()
        val entryRect = PlanRect(0.02f, gridBottom, 0.96f, ENTRY_BAND)
        val entrance = Offset(0.5f, entryRect.centerY)
        val entranceLabel = if (floorIndex == 0 && fromFloorIndex == 0) "المدخل" else "الدرج"

        corridors += CorridorShape(entryRect, if (english) "Main corridor" else "الممر الرئيسي", isVertical = false)

        /** Centre x of the corridor running along the start side of [column]. */
        fun laneX(column: Int): Float =
            if (column == 0) MARGIN / 2f
            else gridLeft + column * blockW + (column - 1) * CORRIDOR + CORRIDOR / 2f

        for (c in 0 until columns) {
            val x = laneX(c)
            val half = (if (c == 0) MARGIN else CORRIDOR) / 2f
            corridors += CorridorShape(
                rect = PlanRect(x - half, gridTop, half * 2f, gridBottom - gridTop),
                label = "",
                isVertical = true
            )
        }
        for (r in 0 until rows - 1) {
            corridors += CorridorShape(
                rect = PlanRect(
                    x = gridLeft,
                    y = gridTop + (r + 1) * blockH + r * CORRIDOR,
                    w = gridRight - gridLeft,
                    h = CORRIDOR
                ),
                label = "",
                isVertical = false
            )
        }

        // -- blocks, aisles, bookcases -----------------------------------
        val shapes = mutableListOf<BlockShape>()
        val lanes = mutableListOf<AisleLane>()
        val markers = mutableListOf<ShelfMarker>()

        blocks.forEach { block ->
            val rect = blockRect(block)
            val isTargetBlock = target != null && target.block == block.code
            shapes += BlockShape(block, rect, isTargetBlock)

            val blockShelves = onFloor.filter { it.block == block.code }
            val aisles = block.aisles.sortedBy { it.order }.ifEmpty {
                // A block with no aisles declared still draws its bookcases,
                // gathered into one unnamed lane, rather than losing them.
                listOf(Aisle(code = "", name = if (english) "Shelving" else "رفوف", order = 0))
            }

            val laneH = (rect.h - BLOCK_PAD * 2f) / aisles.size
            aisles.forEachIndexed { index, aisle ->
                val laneRect = PlanRect(
                    x = rect.x + BLOCK_PAD,
                    y = rect.y + BLOCK_PAD + index * laneH,
                    w = rect.w - BLOCK_PAD * 2f,
                    h = laneH
                )
                val walkwayY = laneRect.y + laneRect.h * WALKWAY_SHARE / 2f
                val isTargetLane = target != null && isTargetBlock && target.aisle == aisle.code
                lanes += AisleLane(aisle, block.code, laneRect, walkwayY, isTargetLane)

                val inAisle = blockShelves
                    .filter { it.aisle == aisle.code || (aisle.code.isEmpty() && it.aisle.isBlank()) }
                    .sortedWith(compareBy({ if (it.position <= 0) Int.MAX_VALUE else it.position }, { it.code }))
                if (inAisle.isEmpty()) return@forEachIndexed

                val gap = 0.006f
                val cellW = (laneRect.w - gap * (inAisle.size - 1)) / inAisle.size
                val cellH = laneRect.h * (1f - WALKWAY_SHARE) * 0.82f
                val cellY = laneRect.y + laneRect.h * WALKWAY_SHARE

                inAisle.forEachIndexed { i, shelf ->
                    val used = bookCounts[shelf.code] ?: 0
                    markers += ShelfMarker(
                        label = shelf.code,
                        rect = PlanRect(laneRect.x + i * (cellW + gap), cellY, cellW, cellH),
                        isTarget = target != null && shelf.code == target.code,
                        fill = if (shelf.capacity > 0) (used.toFloat() / shelf.capacity).coerceIn(0f, 1f) else 0f
                    )
                }
            }
        }

        // -- the walk ----------------------------------------------------
        if (target == null) {
            return FloorMap(
                floor = floor,
                blocks = shapes,
                corridors = corridors,
                lanes = lanes,
                markers = markers,
                entrance = entrance,
                entranceLabel = entranceLabel
            )
        }

        val destMarker = markers.firstOrNull { it.isTarget }
        val targetBlock = blocks.firstOrNull { it.code == target.block }
        if (destMarker == null || targetBlock == null) {
            return FloorMap(
                floor = floor,
                blocks = shapes,
                corridors = corridors,
                lanes = lanes,
                markers = markers,
                entrance = entrance,
                entranceLabel = entranceLabel
            )
        }

        val lane = lanes.firstOrNull { it.isTarget && it.blockCode == targetBlock.code }
            ?: lanes.firstOrNull { it.blockCode == targetBlock.code }
        val walkwayY = lane?.walkwayY ?: destMarker.rect.y - 0.01f
        val corridorX = laneX(targetBlock.column)

        // The visitor's own bookcase, when they gave one on this floor.
        val startMarker = startShelf
            ?.takeIf { s -> s.code != target.code && onFloor.any { it.code == s.code } }
            ?.let { s -> markers.firstOrNull { it.label == s.code } }
        val startBlock = startShelf?.let { s -> blocks.firstOrNull { it.code == s.block } }
            ?.takeIf { startMarker != null }
        val startLane = startBlock?.let { b ->
            lanes.firstOrNull { it.blockCode == b.code && it.aisle.code == startShelf?.aisle }
                ?: lanes.firstOrNull { it.blockCode == b.code }
        }
        val startCorridorX = startBlock?.let { laneX(it.column) }
        // Same block and the same aisle: walk straight along its walkway.
        val sameWalkway = startBlock != null && startBlock.code == targetBlock.code &&
            startLane?.aisle?.code == lane?.aisle?.code
        // Different columns: the walk has to cross the main corridor.
        val usesMainCorridor = startBlock == null || startBlock.column != targetBlock.column

        val path = if (startMarker != null && startBlock != null && startCorridorX != null) {
            val startWalkwayY = startLane?.walkwayY ?: (startMarker.rect.y - 0.01f)
            buildList {
                add(startMarker.rect.center)
                add(Offset(startMarker.rect.centerX, startWalkwayY))
                if (!sameWalkway) {
                    add(Offset(startCorridorX, startWalkwayY))
                    if (usesMainCorridor) {
                        add(Offset(startCorridorX, entrance.y))
                        add(Offset(corridorX, entrance.y))
                    }
                    add(Offset(corridorX, walkwayY))
                }
                add(Offset(destMarker.rect.centerX, walkwayY))
                add(Offset(destMarker.rect.centerX, destMarker.rect.centerY))
            }.dedupe()
        } else {
            listOf(
                entrance,
                Offset(corridorX, entrance.y),
                Offset(corridorX, walkwayY),
                Offset(destMarker.rect.centerX, walkwayY),
                Offset(destMarker.rect.centerX, destMarker.rect.centerY)
            ).dedupe()
        }

        val onRoute = corridors.map { corridor ->
            val touched = if (startMarker != null && startCorridorX != null) {
                !sameWalkway && (
                    !corridor.isVertical && corridor.rect.y >= gridBottom && usesMainCorridor ||
                        corridor.isVertical && abs(corridor.rect.centerX - corridorX) < 0.001f ||
                        corridor.isVertical && abs(corridor.rect.centerX - startCorridorX) < 0.001f
                    )
            } else {
                !corridor.isVertical && corridor.rect.y >= gridBottom ||
                    corridor.isVertical && abs(corridor.rect.centerX - corridorX) < 0.001f
            }
            corridor.copy(isOnRoute = touched)
        }

        val floorsClimbed = abs(floorIndex - fromFloorIndex)
        val metres = (path.length() * PLAN_METERS + floorsClimbed * METERS_PER_FLOOR).roundToInt()
        val minutes = (metres / METERS_PER_MINUTE).roundToInt().coerceAtLeast(1)

        return FloorMap(
            floor = floor,
            blocks = shapes,
            corridors = onRoute,
            lanes = lanes,
            markers = markers,
            entrance = entrance,
            entranceLabel = entranceLabel,
            route = path,
            start = startMarker?.rect?.center,
            destination = destMarker.rect.center,
            distanceMeters = metres,
            etaMinutes = minutes,
            steps = directions(
                floor = floor,
                block = targetBlock,
                aisle = lane?.aisle,
                shelf = target,
                floorsClimbed = floorsClimbed,
                goingUp = floorIndex > fromFloorIndex,
                english = english,
                startShelf = startShelf?.takeIf { it.code != target.code },
                startOnFloor = startMarker != null,
                startBlock = startBlock,
                sameWalkway = sameWalkway,
                usesMainCorridor = usesMainCorridor
            )
        )
    }

    /**
     * The walk in words.
     *
     * Each line is one thing to do, in the order it is done, and every line
     * names something the visitor can actually see: a floor, a block sign, an
     * aisle sign, the code printed on the bookcase.
     */
    private fun directions(
        floor: Floor,
        block: Block,
        aisle: Aisle?,
        shelf: Shelf,
        floorsClimbed: Int,
        goingUp: Boolean,
        english: Boolean,
        startShelf: Shelf? = null,
        startOnFloor: Boolean = false,
        startBlock: Block? = null,
        sameWalkway: Boolean = false,
        usesMainCorridor: Boolean = true
    ): List<String> = buildList {
        if (startShelf != null && !startOnFloor) {
            // They are on another floor: get them to the stairs first.
            add(
                if (english) "From bookcase ${startShelf.code}, walk out to the main corridor and on to the stairs."
                else "من الرف ${startShelf.code} اخرج إلى الممر الرئيسي ثم اتجه إلى الدرج."
            )
        }
        if (floorsClimbed > 0) {
            add(
                when {
                    english -> "Take the stairs ${if (goingUp) "up" else "down"} $floorsClimbed floor(s) to ${floor.displayName(true)}."
                    goingUp -> "اصعد بالدرج $floorsClimbed ${if (floorsClimbed == 1) "دوراً" else "أدوار"} إلى ${floor.displayName(false)}."
                    else -> "انزل بالدرج $floorsClimbed ${if (floorsClimbed == 1) "دوراً" else "أدوار"} إلى ${floor.displayName(false)}."
                }
            )
        } else if (startShelf != null && startOnFloor) {
            add(
                if (english) "Start at bookcase ${startShelf.code}, where you are standing now."
                else "ابدأ من الرف ${startShelf.code} حيث تقف الآن."
            )
        } else {
            add(
                if (english) "Start at the entrance of ${floor.displayName(true)}."
                else "ابدأ من مدخل ${floor.displayName(false)}."
            )
        }

        val sameBlock = startOnFloor && startBlock?.code == block.code
        when {
            sameWalkway -> add(
                if (english) "Stay in this aisle and walk along it."
                else "ابقَ في الممر نفسه وامشِ بمحاذاة الرفوف."
            )
            sameBlock -> add(
                if (english) "Step out to the corridor beside ${block.displayName(true)}."
                else "اخرج إلى الممر المجاور لـ${block.displayName(false)}."
            )
            startOnFloor && !usesMainCorridor -> add(
                if (english) "Step out to the corridor and follow it to ${block.displayName(true)}."
                else "اخرج إلى الممر الجانبي وامشِ فيه حتى ${block.displayName(false)}."
            )
            startOnFloor -> add(
                if (english) "Step out to the main corridor and follow it to ${block.displayName(true)}."
                else "اخرج إلى الممر الرئيسي وامشِ فيه حتى ${block.displayName(false)}."
            )
            else -> add(
                if (english) "Walk along the main corridor to ${block.displayName(true)}."
                else "امشِ في الممر الرئيسي حتى ${block.displayName(false)}."
            )
        }

        if (!sameWalkway && aisle != null && aisle.code.isNotBlank()) {
            add(
                if (english) "Turn into ${aisle.displayName(true)}."
                else "ادخل إلى ${aisle.displayName(false)}."
            )
        }

        val sideText = shelf.side.takeIf { it.isNotBlank() }
        val position = if (shelf.position > 0) shelf.position else null
        add(
            when {
                english && position != null ->
                    "The bookcase ${shelf.code} is number $position along the aisle" +
                        (if (sideText != null) ", on the $sideText." else ".")
                english -> "Look for bookcase ${shelf.code}."
                position != null ->
                    "الرف ${shelf.code} هو رقم $position على الممر" +
                        (if (sideText != null) "، على $sideText." else ".")
                else -> "ابحث عن الرف ${shelf.code}."
            }
        )

        if (shelf.zone.isNotBlank()) {
            add(if (english) "Section: ${shelf.zone}." else "القسم: ${shelf.zone}.")
        }
    }

    // ---- small helpers -------------------------------------------------

    /** Drops points that repeat the previous one, which draw as a dead pixel. */
    private fun List<Offset>.dedupe(): List<Offset> =
        filterIndexed { i, p -> i == 0 || (p - this[i - 1]).getDistance() > 0.001f }

    private fun List<Offset>.length(): Float =
        zipWithNext { a, b -> (b - a).getDistance() }.sum()
}

package com.wujha.user.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wujha.user.data.AppLanguage
import com.wujha.user.data.Localization
import com.wujha.user.data.t
import com.wujha.user.ui.components.ScreenScaffold
import com.wujha.user.ui.theme.BorderLight
import com.wujha.user.ui.theme.CreamBackgroundAlt
import com.wujha.user.ui.theme.ForestGreen
import com.wujha.user.ui.theme.SurfaceWhite
import com.wujha.user.ui.theme.TextPrimary
import com.wujha.user.ui.theme.TextSecondary
import com.wujha.user.ui.theme.ThemeMode
import com.wujha.user.ui.theme.WujhaThemeState

/**
 * Choosing the interface language.
 *
 * The choice takes effect on the tap: reading direction, every label and
 * every message change together, because the language is Compose state that
 * the whole tree is subscribed to. It is remembered across launches.
 *
 * What does not change is the library's own data. A book's title, a
 * category's name and a floor's name are what the librarian typed, and they
 * are shown as they were written — translating a catalog would be inventing
 * one.
 *
 * The same screen chooses the appearance: light, dark, or whatever the phone
 * is set to. That too takes effect on the tap and is remembered.
 */
@Composable
fun LanguageScreen(onBack: () -> Unit) {
    val current = Localization.language

    ScreenScaffold(title = t("اللغة والمظهر"), onBack = onBack) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            AppLanguage.entries.forEach { option ->
                LanguageRow(
                    title = option.label(Localization.isEnglish),
                    subtitle = if (option == AppLanguage.AR) "العربية" else "English",
                    selected = option == current,
                    onClick = { Localization.setLanguage(option) }
                )
                Spacer(Modifier.height(10.dp))
            }

            Spacer(Modifier.height(6.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = CreamBackgroundAlt
            ) {
                Text(
                    text = t("تتغيّر لغة الواجهة واتجاه القراءة فوراً. أما محتوى المكتبة — عناوين الكتب وأسماء التصنيفات والأدوار — فيظهر كما أدخله أمين المكتبة."),
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }

            Spacer(Modifier.height(22.dp))
            Text(
                text = t("المظهر"),
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(10.dp))
            val appearance = WujhaThemeState.current
            ThemeMode.entries.forEach { option ->
                LanguageRow(
                    title = option.label(Localization.isEnglish),
                    subtitle = when (option) {
                        ThemeMode.SYSTEM -> t("يتبع الوضع الليلي في هاتفك")
                        ThemeMode.LIGHT -> t("خلفية فاتحة ونص داكن")
                        ThemeMode.DARK -> t("خلفية داكنة مريحة للعين في الإضاءة الخافتة")
                    },
                    selected = option == appearance,
                    onClick = { WujhaThemeState.select(option) }
                )
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun LanguageRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = SurfaceWhite,
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) ForestGreen else BorderLight)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = TextSecondary, fontSize = 12.sp)
            }
            if (selected) {
                Icon(
                    Icons.Outlined.Check,
                    contentDescription = null,
                    tint = ForestGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

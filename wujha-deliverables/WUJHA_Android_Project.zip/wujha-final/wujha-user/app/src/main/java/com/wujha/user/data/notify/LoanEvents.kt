package com.wujha.user.data.notify

import com.wujha.user.data.LoanDates
import com.wujha.user.data.model.Loan
import com.wujha.user.data.model.LoanPolicy
import com.wujha.user.data.model.LoanStatus
import com.wujha.user.data.t

/** What happened to a borrowing, from the borrower's point of view. */
enum class LoanEventKind {
    APPROVED,
    REJECTED,
    CANCELLED,
    ISSUED,
    RENEWED,
    DUE_SOON,
    OVERDUE,
    RETURNED
}

/**
 * One line in «الإشعارات».
 *
 * [key] is what makes a notification arrive once and stay arrived. It is
 * built from the loan, the kind of event and the stamp that caused it — so
 * the same approval has the same key on every launch, on every device, and
 * the app can tell "already told them" from "new" without storing a copy of
 * the notification anywhere.
 */
data class LoanEvent(
    val key: String,
    val loanId: String,
    val bookId: String,
    val bookTitle: String,
    val kind: LoanEventKind,
    val atMillis: Long,
    val title: String,
    val body: String
)

/**
 * Turns the visitor's own loans into the events worth telling them about.
 *
 * This is derived, not stored, and that is the whole design. The project has
 * no server that could push a message when a librarian taps «موافقة» — so
 * instead the app works out what it would have been told by looking at the
 * loans themselves, which it already receives live. The consequence is
 * honest and worth knowing: a notification appears the moment the app is
 * open, and the event is still waiting in the list if it was closed.
 */
object LoanEvents {

    fun from(loans: List<Loan>, policy: LoanPolicy): List<LoanEvent> {
        val events = mutableListOf<LoanEvent>()
        loans.forEach { loan -> events += eventsFor(loan, policy) }
        return events.sortedByDescending { it.atMillis }
    }

    private fun eventsFor(loan: Loan, policy: LoanPolicy): List<LoanEvent> {
        val out = mutableListOf<LoanEvent>()
        val title = loan.bookTitle

        when (loan.status) {
            LoanStatus.APPROVED -> {
                val deadline = LoanDates.dueDate(policy.pickupWindowDays, loan.decidedAt)
                out += event(
                    loan, LoanEventKind.APPROVED, loan.decidedAt,
                    t("تمت الموافقة على طلبك"),
                    t("«%s» محجوز باسمك. استلمه من المكتبة قبل %s.")
                        .format(title, LoanDates.format(deadline))
                )
            }

            LoanStatus.REJECTED -> out += event(
                loan, LoanEventKind.REJECTED, loan.decidedAt,
                t("لم تُقبل طلب الإعارة"),
                if (loan.rejectReason.isBlank()) {
                    t("طلب إعارة «%s» لم يُقبل.").format(title)
                } else {
                    t("«%s»: %s").format(title, loan.rejectReason)
                }
            )

            LoanStatus.CANCELLED -> out += event(
                loan, LoanEventKind.CANCELLED, loan.decidedAt,
                t("أُلغي الطلب"),
                if (loan.rejectReason.isBlank()) {
                    t("أُلغي طلب إعارة «%s».").format(title)
                } else {
                    t("«%s»: %s").format(title, loan.rejectReason)
                }
            )

            LoanStatus.ACTIVE -> {
                out += event(
                    loan, LoanEventKind.ISSUED, loan.issuedAt,
                    t("استلمت الكتاب"),
                    t("موعد إرجاع «%s» هو %s.").format(title, LoanDates.format(loan.dueAt))
                )
                // A renewal is announced by the count going up, so the key
                // carries the count and each renewal is its own event.
                if (loan.renewals > 0) {
                    out += event(
                        loan, LoanEventKind.RENEWED, loan.dueAt,
                        t("تم تجديد المدة"),
                        t("موعد إرجاع «%s» الجديد هو %s.").format(title, LoanDates.format(loan.dueAt)),
                        stamp = loan.renewals.toLong()
                    )
                }
                if (loan.isOverdue) {
                    out += event(
                        loan, LoanEventKind.OVERDUE, loan.dueAt,
                        t("تأخّر إرجاع الكتاب"),
                        t("كان موعد إرجاع «%s» في %s. أعِده إلى المكتبة.")
                            .format(title, LoanDates.format(loan.dueAt))
                    )
                } else if (loan.isDueSoon) {
                    out += event(
                        loan, LoanEventKind.DUE_SOON, loan.dueAt,
                        t("اقترب موعد الإرجاع"),
                        t("%s لإرجاع «%s». يمكنك طلب التجديد قبل انتهاء المدة.")
                            .format(LoanDates.remainingLabel(loan.dueAt), title)
                    )
                }
            }

            LoanStatus.RETURNED -> out += event(
                loan, LoanEventKind.RETURNED, loan.returnedAt,
                t("تم استرجاع الكتاب"),
                t("سُجّل إرجاع «%s». شكراً لالتزامك.").format(title)
            )

            LoanStatus.LOST -> out += event(
                loan, LoanEventKind.CANCELLED, loan.returnedAt,
                t("سُجّلت النسخة كمفقودة"),
                t("راجع أمينة المكتبة بخصوص «%s».").format(title)
            )

            // A request nobody has answered yet is not news.
            LoanStatus.REQUESTED -> Unit
        }

        return out.filter { it.atMillis > 0L }
    }

    private fun event(
        loan: Loan,
        kind: LoanEventKind,
        atMillis: Long,
        title: String,
        body: String,
        stamp: Long = atMillis
    ): LoanEvent = LoanEvent(
        key = "${loan.id}:${kind.name}:$stamp",
        loanId = loan.id,
        bookId = loan.bookId,
        bookTitle = loan.bookTitle,
        kind = kind,
        atMillis = atMillis,
        title = title,
        body = body
    )
}

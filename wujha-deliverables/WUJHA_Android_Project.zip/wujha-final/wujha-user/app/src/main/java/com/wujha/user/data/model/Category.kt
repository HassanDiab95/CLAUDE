package com.wujha.user.data.model

/** A browsable library section, e.g. "الأدب" or "العلوم". */
data class Category(
    val id: String = "",
    val name: String = "",
    val iconKey: String = "book"
)

package com.wujha.user.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** A single on/off app setting. */
data class ToggleSetting(val key: String, val label: String, val detail: String, val enabled: Boolean)

/** Device-local preferences — notification switches and similar. */
class AppPreferences(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("wujha_user_prefs", Context.MODE_PRIVATE)

    private val state = MutableStateFlow(load())
    val settings: StateFlow<List<ToggleSetting>> = state.asStateFlow()

    private fun load(): List<ToggleSetting> = DEFAULTS.map { d ->
        d.copy(enabled = prefs.getBoolean(d.key, d.enabled))
    }

    fun toggle(key: String) {
        val updated = state.value.map { s -> if (s.key == key) s.copy(enabled = !s.enabled) else s }
        state.value = updated
        updated.firstOrNull { it.key == key }?.let {
            prefs.edit().putBoolean(it.key, it.enabled).apply()
        }
    }

    private companion object {
        val DEFAULTS = listOf(
            ToggleSetting("notify_loans", "حالة طلبات الإعارة",
                "إشعار عند الموافقة على طلبك أو رفضه، وعند تسليم الكتاب واسترجاعه", true),
            ToggleSetting("notify_new_books", "كتب جديدة",
                "إشعار عند إضافة كتب جديدة إلى المكتبة", true),
            ToggleSetting("notify_favorite_available", "توفّر كتاب مفضّل",
                "إشعار عندما يصبح كتاب في مفضلاتك متوفراً", true),
            ToggleSetting("notify_reminders", "تذكيرات الإرجاع",
                "تنبيه قبل موعد الإرجاع بثلاثة أيام، وعند تجاوزه", true)
        )
    }
}

object PreferencesProvider {

    @Volatile
    private var instance: AppPreferences? = null

    fun init(context: Context) {
        if (instance == null) instance = AppPreferences(context)
    }

    val preferences: AppPreferences
        get() = instance ?: error("PreferencesProvider.init(context) must be called first")
}

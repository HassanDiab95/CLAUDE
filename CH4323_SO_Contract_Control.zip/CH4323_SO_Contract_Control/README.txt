CH4323 - Sales Order with reference to Contract: filter table + VA01 field lock

START HERE: docs/CH4323_creation_guide.md
  Step-by-step creation of every object (domains, data elements, table,
  table maintenance, range table types, structure, table type, class,
  enhancements, transaction) with the full code included.

src/ddic/zsd_so_con_flt.tabl.ddl              Filter table ZSD_SO_CON_FLT (ACTIVE = XFELD checkbox)
src/ddic/zssd_so_con_filter.stru.ddl          Filter structure ZSSD_SO_CON_FILTER
src/ddic/zsd_so_con_flt_tmg_events.abap       SM30 save checks (TMG event 01)
src/class/zcl_sd_so_contract_ctrl.clas.abap   Filter logic class
src/enhancement/mv45afzz_userexit_field_modification.abap   VA01 field lock
src/enhancement/lv69afzz_userexit_field_modification.abap   Optional price lock
docs/CH4323_filter_table_and_va01_lock.md     Technical design
docs/CH4323- TSD ... .docx                    Original TSD

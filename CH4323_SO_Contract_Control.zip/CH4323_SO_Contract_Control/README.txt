CH4323 - Sales Order with reference to Contract: filter table + VA01 field lock

START HERE: docs/CH4323_creation_guide.md
  Step-by-step creation of every object (domains, data elements, table,
  table maintenance, class, enhancements, transaction) with the full code included.

src/ddic/zsd_so_con_flt.tabl.ddl              Filter table ZSD_SO_CON_FLT (PROCESS VA01/VA02/BOTH, ACTIVE = XFELD)
src/ddic/zssd_so_con_filter.stru.ddl          Filter structure (optional)
src/ddic/zsd_so_con_flt_tmg_events.abap       SM30 save checks (TMG event 01)
src/class/zcl_sd_so_contract_ctrl.clas.abap   Filter logic class
src/enhancement/mv45afzz_userexit_field_modification.abap      VA01 field lock
src/enhancement/mv45af0c_cua_setzen.abap                       VA01 disable Insert Row / Delete Item
src/enhancement/mv45afzb_userexit_check_vbap.abap              VA01 reject new items (safety net)
src/enhancement/mv45afzb_userexit_check_xvbap_for_delet.abap   VA01 reject item deletion (safety net)
src/enhancement/ce_c_processing_display.abap                   VA01 characteristic values display-only
src/enhancement/lv69afzz_userexit_field_modification.abap      Optional price lock
docs/CH4323_filter_table_and_va01_lock.md     Technical design
docs/CH4323- TSD ... .docx                    Original TSD

PART 2 - VA02 change approval (design: docs/CH4323_VA02_change_approval_design.md)
src/ddic/zsd_so_appr_cfg.tabl.ddl                              Approver table (levels)
src/ddic/zsd_so_appr_log.tabl.ddl                              Approval requests / status
src/class/zcl_sd_so_chg_monitor.clas.abap                      Snapshot, change detection, start approval
src/class/zcl_sd_so_chg_wf.clas.abap                           Workflow object (IF_WORKFLOW) + step methods
src/enhancement/mv45afzz_userexit_read_document.abap           VA02 snapshot
src/enhancement/mv45afzz_userexit_save_document_prepare.abap   VA02 detect changes, set/keep delivery block
src/enhancement/mv45afzz_userexit_save_document.abap           VA02 log + workflow event
src/enhancement/mv45afzz_userexit_field_modification.abap      (+ VA02 lock of delivery block while pending)

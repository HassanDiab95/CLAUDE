/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: rayy
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `rayy`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `rayy` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `rayy`;

--
-- Table structure for table `api_tokens`
--

DROP TABLE IF EXISTS `api_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_tokens` (
  `token_hash` char(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`token_hash`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `api_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_tokens`
--

LOCK TABLES `api_tokens` WRITE;
/*!40000 ALTER TABLE `api_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crop_types`
--

DROP TABLE IF EXISTS `crop_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crop_types` (
  `type_code` varchar(20) NOT NULL,
  `name_ar` varchar(40) NOT NULL,
  `name_en` varchar(40) NOT NULL,
  `emoji` varchar(8) NOT NULL,
  `moisture_min` tinyint(3) unsigned NOT NULL,
  `moisture_max` tinyint(3) unsigned NOT NULL,
  `temp_min` decimal(4,1) NOT NULL,
  `temp_max` decimal(4,1) NOT NULL,
  `lux_min` int(10) unsigned NOT NULL,
  PRIMARY KEY (`type_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crop_types`
--

LOCK TABLES `crop_types` WRITE;
/*!40000 ALTER TABLE `crop_types` DISABLE KEYS */;
INSERT INTO `crop_types` VALUES
('basil','ريحان','Basil','🌱',45,80,15.0,32.0,3000),
('cactus','صبار','Cactus','🌵',10,40,10.0,40.0,5000),
('cucumber','خيار','Cucumber','🥒',60,85,18.0,32.0,6000),
('date_palm','نخيل (فسائل)','Date palm (young)','🌴',30,70,15.0,45.0,10000),
('indoor','نبات داخلي','Indoor plant','🪴',40,80,15.0,30.0,200),
('lettuce','خس','Lettuce','🥬',60,85,7.0,24.0,3000),
('mint','نعناع','Mint','🌿',55,85,10.0,30.0,2000),
('other','أخرى','Other','🌾',30,85,10.0,35.0,200),
('pepper','فلفل','Pepper','🫑',50,80,18.0,32.0,7000),
('rose','ورد','Rose','🌹',45,75,12.0,30.0,5000),
('strawberry','فراولة','Strawberry','🍓',60,85,10.0,28.0,5000),
('tomato','طماطم','Tomato','🍅',50,80,15.0,32.0,8000);
/*!40000 ALTER TABLE `crop_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crops`
--

DROP TABLE IF EXISTS `crops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crops` (
  `crop_id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `type_code` varchar(20) NOT NULL,
  `name` varchar(60) NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  `moisture_min` tinyint(3) unsigned NOT NULL,
  `moisture_max` tinyint(3) unsigned NOT NULL,
  `temp_min` decimal(4,1) NOT NULL,
  `temp_max` decimal(4,1) NOT NULL,
  `lux_min` int(10) unsigned NOT NULL,
  `quiet_start` tinyint(3) unsigned NOT NULL DEFAULT 22,
  `quiet_end` tinyint(3) unsigned NOT NULL DEFAULT 7,
  `muted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`crop_id`),
  KEY `idx_owner` (`owner_id`),
  KEY `type_code` (`type_code`),
  CONSTRAINT `crops_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `crops_ibfk_2` FOREIGN KEY (`type_code`) REFERENCES `crop_types` (`type_code`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`moisture_min` <= 100 and `moisture_max` <= 100 and `quiet_start` < 24 and `quiet_end` < 24)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crops`
--

LOCK TABLES `crops` WRITE;
/*!40000 ALTER TABLE `crops` DISABLE KEYS */;
INSERT INTO `crops` VALUES
(1,1,'strawberry','فراولة البيت المحمي','Greenhouse 1',60,85,10.0,28.0,5000,22,7,0,'2026-10-19 15:14:25'),
(2,1,'mint','نعناع الحديقة','Garden',55,85,10.0,30.0,2000,22,7,0,'2026-10-19 15:14:25');
/*!40000 ALTER TABLE `crops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_assignments`
--

DROP TABLE IF EXISTS `device_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_assignments` (
  `assignment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `device_id` varchar(20) NOT NULL,
  `crop_id` int(11) NOT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `removed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`assignment_id`),
  KEY `idx_device` (`device_id`,`assigned_at`),
  KEY `crop_id` (`crop_id`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `device_assignments_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`device_id`) ON DELETE CASCADE,
  CONSTRAINT `device_assignments_ibfk_2` FOREIGN KEY (`crop_id`) REFERENCES `crops` (`crop_id`) ON DELETE CASCADE,
  CONSTRAINT `device_assignments_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_assignments`
--

LOCK TABLES `device_assignments` WRITE;
/*!40000 ALTER TABLE `device_assignments` DISABLE KEYS */;
INSERT INTO `device_assignments` VALUES
(1,'rayy-01',1,1,'2026-10-19 15:14:25',NULL);
/*!40000 ALTER TABLE `device_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `device_id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `device_key_hash` char(64) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `crop_id` int(11) DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  PRIMARY KEY (`device_id`),
  KEY `owner_id` (`owner_id`),
  KEY `crop_id` (`crop_id`),
  CONSTRAINT `devices_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `devices_ibfk_2` FOREIGN KEY (`crop_id`) REFERENCES `crops` (`crop_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES
('rayy-01','Rayy sensor 1','7cc45b29246c98c39e61887cdf874d7dccbbe3607daa498bbcad2cf9b975debf',1,1,'2026-10-19 18:14:26');
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `live_status`
--

DROP TABLE IF EXISTS `live_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_status` (
  `crop_id` int(11) NOT NULL,
  `device_id` varchar(20) NOT NULL,
  `moisture` decimal(5,1) DEFAULT NULL,
  `temperature` decimal(4,1) DEFAULT NULL,
  `humidity` decimal(5,1) DEFAULT NULL,
  `lux` int(10) unsigned DEFAULT NULL,
  `mood_code` varchar(20) NOT NULL,
  `soil_raw` smallint(5) unsigned DEFAULT NULL,
  `rssi` smallint(6) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `uptime_s` int(10) unsigned DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`crop_id`),
  KEY `device_id` (`device_id`),
  KEY `mood_code` (`mood_code`),
  CONSTRAINT `live_status_ibfk_1` FOREIGN KEY (`crop_id`) REFERENCES `crops` (`crop_id`) ON DELETE CASCADE,
  CONSTRAINT `live_status_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `devices` (`device_id`) ON DELETE CASCADE,
  CONSTRAINT `live_status_ibfk_3` FOREIGN KEY (`mood_code`) REFERENCES `moods` (`mood_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `live_status`
--

LOCK TABLES `live_status` WRITE;
/*!40000 ALTER TABLE `live_status` DISABLE KEYS */;
INSERT INTO `live_status` VALUES
(1,'rayy-01',72.0,24.5,48.0,6800,'happy',NULL,-57,'',NULL,'2026-10-19 18:14:26');
/*!40000 ALTER TABLE `live_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `melodies`
--

DROP TABLE IF EXISTS `melodies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `melodies` (
  `melody_no` tinyint(3) unsigned NOT NULL,
  `name_en` varchar(30) NOT NULL,
  `name_ar` varchar(30) NOT NULL,
  `description` varchar(120) NOT NULL,
  PRIMARY KEY (`melody_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `melodies`
--

LOCK TABLES `melodies` WRITE;
/*!40000 ALTER TABLE `melodies` DISABLE KEYS */;
INSERT INTO `melodies` VALUES
(1,'Thirsty','عطشانة','Sad \"help!\" notes, played twice'),
(2,'Too wet','غرقانة','Fast bubbling notes'),
(3,'Hot','حرّانة','Alarm beeps'),
(4,'Cold','بردانة','Shivering trill'),
(5,'Needs light','تحتاج ضوء','Rising notes then a low note'),
(6,'Happy','سعيدة','Happy arpeggio'),
(7,'Thank you','شكراً','Joyful melody after watering'),
(8,'Good night','تصبحون على خير','Slow lullaby'),
(9,'Hello','مرحباً','Short start-up melody');
/*!40000 ALTER TABLE `melodies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mood_events`
--

DROP TABLE IF EXISTS `mood_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mood_events` (
  `event_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `crop_id` int(11) NOT NULL,
  `device_id` varchar(20) NOT NULL,
  `mood_code` varchar(20) NOT NULL,
  `occurred_at` datetime NOT NULL DEFAULT current_timestamp(),
  `message` varchar(200) NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `idx_crop_time` (`crop_id`,`occurred_at`),
  KEY `device_id` (`device_id`),
  KEY `mood_code` (`mood_code`),
  CONSTRAINT `mood_events_ibfk_1` FOREIGN KEY (`crop_id`) REFERENCES `crops` (`crop_id`) ON DELETE CASCADE,
  CONSTRAINT `mood_events_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `devices` (`device_id`) ON DELETE CASCADE,
  CONSTRAINT `mood_events_ibfk_3` FOREIGN KEY (`mood_code`) REFERENCES `moods` (`mood_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mood_events`
--

LOCK TABLES `mood_events` WRITE;
/*!40000 ALTER TABLE `mood_events` DISABLE KEYS */;
INSERT INTO `mood_events` VALUES
(1,1,'rayy-01','thirsty','2026-10-19 07:14:26','I am thirsty, please water me!'),
(2,1,'rayy-01','happy','2026-10-19 11:14:26','I am happy, everything is perfect!');
/*!40000 ALTER TABLE `mood_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moods`
--

DROP TABLE IF EXISTS `moods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `moods` (
  `mood_code` varchar(20) NOT NULL,
  `name_ar` varchar(30) NOT NULL,
  `name_en` varchar(30) NOT NULL,
  `emoji` varchar(8) NOT NULL,
  `melody_no` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`mood_code`),
  KEY `melody_no` (`melody_no`),
  CONSTRAINT `moods_ibfk_1` FOREIGN KEY (`melody_no`) REFERENCES `melodies` (`melody_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moods`
--

LOCK TABLES `moods` WRITE;
/*!40000 ALTER TABLE `moods` DISABLE KEYS */;
INSERT INTO `moods` VALUES
('cold','بردانة','Cold','🥶',4),
('drowning','غرقانة','Too wet','🥴',2),
('happy','سعيدة','Happy','😊',6),
('hot','حرّانة','Too hot','🥵',3),
('need_light','تحتاج ضوء','Needs light','😞',5),
('sleepy','نائمة','Sleeping','😴',8),
('thirsty','عطشانة','Thirsty','😫',1);
/*!40000 ALTER TABLE `moods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `play_commands`
--

DROP TABLE IF EXISTS `play_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `play_commands` (
  `command_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `crop_id` int(11) NOT NULL,
  `device_id` varchar(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `melody_no` tinyint(3) unsigned NOT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','played') NOT NULL DEFAULT 'pending',
  `played_at` datetime DEFAULT NULL,
  PRIMARY KEY (`command_id`),
  KEY `idx_pending` (`device_id`,`status`),
  KEY `crop_id` (`crop_id`),
  KEY `user_id` (`user_id`),
  KEY `melody_no` (`melody_no`),
  CONSTRAINT `play_commands_ibfk_1` FOREIGN KEY (`crop_id`) REFERENCES `crops` (`crop_id`) ON DELETE CASCADE,
  CONSTRAINT `play_commands_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `devices` (`device_id`) ON DELETE CASCADE,
  CONSTRAINT `play_commands_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `play_commands_ibfk_4` FOREIGN KEY (`melody_no`) REFERENCES `melodies` (`melody_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `play_commands`
--

LOCK TABLES `play_commands` WRITE;
/*!40000 ALTER TABLE `play_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `play_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `readings`
--

DROP TABLE IF EXISTS `readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `readings` (
  `reading_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `crop_id` int(11) NOT NULL,
  `device_id` varchar(20) NOT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `moisture` decimal(5,1) DEFAULT NULL,
  `temperature` decimal(4,1) DEFAULT NULL,
  `humidity` decimal(5,1) DEFAULT NULL,
  `lux` int(10) unsigned DEFAULT NULL,
  `mood_code` varchar(20) NOT NULL,
  PRIMARY KEY (`reading_id`),
  KEY `idx_crop_time` (`crop_id`,`recorded_at`),
  KEY `device_id` (`device_id`),
  KEY `mood_code` (`mood_code`),
  CONSTRAINT `readings_ibfk_1` FOREIGN KEY (`crop_id`) REFERENCES `crops` (`crop_id`) ON DELETE CASCADE,
  CONSTRAINT `readings_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `devices` (`device_id`) ON DELETE CASCADE,
  CONSTRAINT `readings_ibfk_3` FOREIGN KEY (`mood_code`) REFERENCES `moods` (`mood_code`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `readings`
--

LOCK TABLES `readings` WRITE;
/*!40000 ALTER TABLE `readings` DISABLE KEYS */;
INSERT INTO `readings` VALUES
(1,1,'rayy-01','2026-10-18 19:14:26',56.0,21.5,45.0,3150,'happy'),
(2,1,'rayy-01','2026-10-18 19:44:26',57.0,22.5,45.0,3300,'happy'),
(3,1,'rayy-01','2026-10-18 20:14:26',58.0,23.5,45.0,3450,'happy'),
(4,1,'rayy-01','2026-10-18 20:44:26',59.0,24.5,45.0,3600,'happy'),
(5,1,'rayy-01','2026-10-18 21:14:26',60.0,25.5,45.0,3750,'happy'),
(6,1,'rayy-01','2026-10-18 21:44:26',61.0,26.5,45.0,3900,'happy'),
(7,1,'rayy-01','2026-10-18 22:14:26',62.0,27.5,45.0,4050,'happy'),
(8,1,'rayy-01','2026-10-18 22:44:26',63.0,28.5,45.0,4200,'happy'),
(9,1,'rayy-01','2026-10-18 23:14:26',64.0,20.5,45.0,4350,'happy'),
(10,1,'rayy-01','2026-10-18 23:44:26',65.0,21.5,45.0,4500,'happy'),
(11,1,'rayy-01','2026-10-19 00:14:26',66.0,22.5,45.0,4650,'happy'),
(12,1,'rayy-01','2026-10-19 00:44:26',67.0,23.5,45.0,4800,'happy'),
(13,1,'rayy-01','2026-10-19 01:14:26',68.0,24.5,45.0,4950,'happy'),
(14,1,'rayy-01','2026-10-19 01:44:26',69.0,25.5,45.0,5100,'happy'),
(15,1,'rayy-01','2026-10-19 02:14:26',70.0,26.5,45.0,5250,'happy'),
(16,1,'rayy-01','2026-10-19 02:44:26',71.0,27.5,45.0,5400,'happy'),
(17,1,'rayy-01','2026-10-19 03:14:26',72.0,28.5,45.0,5550,'happy'),
(18,1,'rayy-01','2026-10-19 03:44:26',73.0,20.5,45.0,5700,'happy'),
(19,1,'rayy-01','2026-10-19 04:14:26',74.0,21.5,45.0,5850,'happy'),
(20,1,'rayy-01','2026-10-19 04:44:26',75.0,22.5,45.0,6000,'happy'),
(21,1,'rayy-01','2026-10-19 05:14:26',76.0,23.5,45.0,6150,'happy'),
(22,1,'rayy-01','2026-10-19 05:44:26',77.0,24.5,45.0,6300,'happy'),
(23,1,'rayy-01','2026-10-19 06:14:26',78.0,25.5,45.0,6450,'happy'),
(24,1,'rayy-01','2026-10-19 06:44:26',79.0,26.5,45.0,6600,'happy'),
(25,1,'rayy-01','2026-10-19 07:14:26',55.0,27.5,45.0,6750,'happy'),
(26,1,'rayy-01','2026-10-19 07:44:26',56.0,28.5,45.0,6900,'happy'),
(27,1,'rayy-01','2026-10-19 08:14:26',57.0,20.5,45.0,7050,'happy'),
(28,1,'rayy-01','2026-10-19 08:44:26',58.0,21.5,45.0,7200,'happy'),
(29,1,'rayy-01','2026-10-19 09:14:26',59.0,22.5,45.0,7350,'happy'),
(30,1,'rayy-01','2026-10-19 09:44:26',60.0,23.5,45.0,7500,'happy'),
(31,1,'rayy-01','2026-10-19 10:14:26',61.0,24.5,45.0,7650,'happy'),
(32,1,'rayy-01','2026-10-19 10:44:26',62.0,25.5,45.0,7800,'happy'),
(33,1,'rayy-01','2026-10-19 11:14:26',63.0,26.5,45.0,7950,'happy'),
(34,1,'rayy-01','2026-10-19 11:44:26',64.0,27.5,45.0,8100,'happy'),
(35,1,'rayy-01','2026-10-19 12:14:26',65.0,28.5,45.0,8250,'happy'),
(36,1,'rayy-01','2026-10-19 12:44:26',66.0,20.5,45.0,8400,'happy'),
(37,1,'rayy-01','2026-10-19 13:14:26',67.0,21.5,45.0,8550,'happy'),
(38,1,'rayy-01','2026-10-19 13:44:26',68.0,22.5,45.0,8700,'happy'),
(39,1,'rayy-01','2026-10-19 14:14:26',69.0,23.5,45.0,8850,'happy'),
(40,1,'rayy-01','2026-10-19 14:44:26',70.0,24.5,45.0,9000,'happy');
/*!40000 ALTER TABLE `readings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(120) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin@rayy.app','Rayy Admin','$2y$10$8cCB8IHP5z8vJdECFK.w2uClgv1ruEhKQVEG9BDSXUeu6W1VoWMVy','admin','2026-10-19 15:14:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'rayy'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
